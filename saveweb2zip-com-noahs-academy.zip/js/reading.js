(function () {
  "use strict";

  var CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  var BASE = 0xe000;
  var SKIP = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEXTAREA: 1, TITLE: 1 };
  var PATTERN = /[A-Za-z0-9]/g;
  var MAP = {};

  for (var index = 0; index < CHARS.length; index++) {
    MAP[CHARS.charAt(index)] = String.fromCharCode(BASE + index);
  }

  function encode(value) {
    return value.replace(PATTERN, function (character) {
      return MAP[character] || character;
    });
  }

  function skip(node) {
    var element = node.parentNode;
    while (element && element.nodeType === 1) {
      if (SKIP[element.tagName] || element.hasAttribute("data-plain")) return true;
      element = element.parentNode;
    }
    return false;
  }

  function processText(node) {
    if (!node.nodeValue || skip(node)) return;
    var next = encode(node.nodeValue);
    if (next !== node.nodeValue) node.nodeValue = next;
  }

  function processTree(root) {
    if (!root) return;
    if (root.nodeType === 3) {
      processText(root);
      return;
    }
    if (root.nodeType !== 1 && root.nodeType !== 9) return;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    var nodes = [];
    var current;
    while ((current = walker.nextNode())) nodes.push(current);
    for (var i = 0; i < nodes.length; i++) processText(nodes[i]);
  }

  function injectStyle() {
    var style = document.createElement("style");
    style.id = "study-reading";
    style.textContent =
      '@font-face{font-family:"StudySans";font-weight:400;font-style:normal;font-display:swap;' +
      'src:url("/study/lib/study-400.woff2") format("woff2")}' +
      '@font-face{font-family:"StudySans";font-weight:600;font-style:normal;font-display:swap;' +
      'src:url("/study/lib/study-600.woff2") format("woff2")}' +
      'body,body *{font-family:"StudySans",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif!important}';
    (document.head || document.documentElement).appendChild(style);
  }

  function start() {
    injectStyle();
    processTree(document.body);
    var observer = new MutationObserver(function (records) {
      for (var i = 0; i < records.length; i++) {
        var record = records[i];
        if (record.type === "characterData") {
          processText(record.target);
        } else {
          for (var j = 0; j < record.addedNodes.length; j++) processTree(record.addedNodes[j]);
        }
      }
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
