(function () {
  "use strict";

  var pill = document.getElementById("homeOnline");
  var label = document.getElementById("homeOnlineText");
  if (!pill || !label) return;

  var timer = null;

  function paint(count) {
    if (typeof count !== "number" || count < 1) {
      pill.hidden = true;
      return;
    }
    label.textContent = count + " online now";
    pill.hidden = false;
  }

  function load() {
    fetch("/api/live", { cache: "no-store" })
      .then(function (res) {
        return res.ok ? res.json() : null;
      })
      .then(function (data) {
        if (data && typeof data.online === "number") paint(data.online);
      })
      .catch(function () {});
  }

  function start() {
    load();
    clearInterval(timer);
    timer = setInterval(function () {
      if (!document.hidden) load();
    }, 30000);
  }

  document.addEventListener("visibilitychange", function () {
    if (!document.hidden) load();
  });

  start();
})();
