(function () {
  "use strict";

  var bar = null;
  var mini = null;
  var minimized = false;
  var self = false;
  var dragging = null;

  var ICON_COLLAPSE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 3v4a2 2 0 0 1-2 2H3"/><path d="M15 3v4a2 2 0 0 0 2 2h4"/><path d="M9 21v-4a2 2 0 0 0-2-2H3"/><path d="M15 21v-4a2 2 0 0 1 2-2h4"/></svg>';
  var ICON_EXPAND = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 9V7a2 2 0 0 1 2-2h2"/><path d="M21 9V7a2 2 0 0 0-2-2h-2"/><path d="M3 15v2a2 2 0 0 0 2 2h2"/><path d="M21 15v2a2 2 0 0 1-2 2h-2"/></svg>';
  var ICON_STOP = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  var ICON_PLAY = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7.5 5.14v13.72c0 .79.87 1.27 1.54.84l10.78-6.86a1 1 0 0 0 0-1.68L9.04 4.3A1 1 0 0 0 7.5 5.14z"/></svg>';
  var ICON_PAUSE = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="4.5" width="4" height="15" rx="1.4"/><rect x="14" y="4.5" width="4" height="15" rx="1.4"/></svg>';

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = text;
    return node;
  }

  function isPlaying() {
    var toggle = document.getElementById("musicBarToggle");
    var label = toggle ? String(toggle.getAttribute("aria-label") || "") : "";
    return label === "Pause";
  }

  function coverSrc() {
    var art = document.getElementById("musicBarArt");
    var img = art ? art.querySelector("img") : null;
    return img ? img.getAttribute("src") : "";
  }

  function currentArtist() {
    try {
      var now = window.hubMusic && window.hubMusic.now ? window.hubMusic.now() : null;
      if (now && now.artist) return String(now.artist);
    } catch (e) {}
    var stateEl = document.getElementById("musicBarState");
    return stateEl ? String(stateEl.textContent || "") : "";
  }

  function gotoArtist() {
    var name = currentArtist();
    if (!name) return;
    window.dispatchEvent(new CustomEvent("mx:artist", { detail: { name: name } }));
  }

  function glow() {
    if (!bar) return null;
    var node = bar.querySelector(".mbar-glow");
    if (node) return node;
    node = el("div", "mbar-glow");
    bar.insertBefore(node, bar.firstChild);
    return node;
  }

  function paintGlow() {
    var node = glow();
    if (!node) return;
    var src = coverSrc();
    if (src) node.style.backgroundImage = "url('" + src + "')";
    else node.style.backgroundImage = "";
  }

  function sync() {
    paintGlow();
    if (!mini) return;
    var name = (document.getElementById("musicBarName") || {}).textContent || "";
    var artist = (document.getElementById("musicBarState") || {}).textContent || "";
    mini.querySelector(".mbar-mini-name").textContent = name;
    mini.querySelector(".mbar-mini-artist").textContent = artist;
    var art = mini.querySelector(".mbar-mini-art");
    var src = coverSrc();
    var img = art.querySelector("img");
    if (src) {
      if (!img) {
        img = el("img");
        img.alt = "";
        art.appendChild(img);
      }
      if (img.getAttribute("src") !== src) img.src = src;
    } else if (img) {
      art.removeChild(img);
    }
    var play = mini.querySelector(".mbar-mini-play");
    if (play) {
      play.innerHTML = isPlaying() ? ICON_PAUSE : ICON_PLAY;
      play.setAttribute("aria-label", isPlaying() ? "Pause" : "Play");
    }
  }

  function savedPos() {
    try {
      var raw = localStorage.getItem("hub_mini_pos");
      if (!raw) return null;
      var pos = JSON.parse(raw);
      if (typeof pos.left !== "number" || typeof pos.top !== "number") return null;
      return pos;
    } catch (e) {
      return null;
    }
  }

  function storePos(left, top) {
    try {
      localStorage.setItem("hub_mini_pos", JSON.stringify({ left: Math.round(left), top: Math.round(top) }));
    } catch (e) {}
  }

  function placeMini() {
    if (!mini) return;
    var pos = savedPos();
    if (!pos) {
      mini.style.left = "";
      mini.style.top = "";
      mini.style.right = "";
      mini.style.bottom = "";
      return;
    }
    var maxLeft = Math.max(6, window.innerWidth - mini.offsetWidth - 6);
    var maxTop = Math.max(6, window.innerHeight - mini.offsetHeight - 6);
    mini.style.left = Math.min(Math.max(6, pos.left), maxLeft) + "px";
    mini.style.top = Math.min(Math.max(6, pos.top), maxTop) + "px";
    mini.style.right = "auto";
    mini.style.bottom = "auto";
  }

  function dragStart(ev) {
    if (!mini || ev.button !== 0) return;
    var t = ev.target;
    if (t && t.closest && t.closest("button")) return;
    var rect = mini.getBoundingClientRect();
    dragging = {
      dx: ev.clientX - rect.left,
      dy: ev.clientY - rect.top
    };
    mini.classList.add("is-dragging");
    try {
      mini.setPointerCapture(ev.pointerId);
    } catch (e) {}
    ev.preventDefault();
  }

  function dragMove(ev) {
    if (!dragging || !mini) return;
    var maxLeft = Math.max(6, window.innerWidth - mini.offsetWidth - 6);
    var maxTop = Math.max(6, window.innerHeight - mini.offsetHeight - 6);
    var left = Math.min(Math.max(6, ev.clientX - dragging.dx), maxLeft);
    var top = Math.min(Math.max(6, ev.clientY - dragging.dy), maxTop);
    mini.style.left = left + "px";
    mini.style.top = top + "px";
    mini.style.right = "auto";
    mini.style.bottom = "auto";
  }

  function dragEnd() {
    if (!dragging || !mini) return;
    dragging = null;
    mini.classList.remove("is-dragging");
    var rect = mini.getBoundingClientRect();
    storePos(rect.left, rect.top);
  }

  function buildMini() {
    mini = el("div", "mbar-mini");
    mini.id = "mbarMini";
    mini.setAttribute("role", "region");
    mini.setAttribute("aria-label", "Now playing, minimized");
    mini.hidden = true;

    var art = el("span", "mbar-mini-art");
    mini.appendChild(art);

    var info = el("span", "mbar-mini-info");
    info.appendChild(el("span", "mbar-mini-name"));
    var miniArtist = el("span", "mbar-mini-artist");
    info.appendChild(miniArtist);
    miniArtist.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      gotoArtist();
    });
    mini.appendChild(info);

    var play = el("button", "mbar-mini-btn mbar-mini-play");
    play.type = "button";
    play.innerHTML = ICON_PLAY;
    play.setAttribute("aria-label", "Play");
    play.addEventListener("click", function () {
      if (window.hubMusic && window.hubMusic.toggle) window.hubMusic.toggle();
      setTimeout(sync, 120);
    });
    mini.appendChild(play);

    var stop = el("button", "mbar-mini-btn mbar-mini-stop");
    stop.type = "button";
    stop.innerHTML = ICON_STOP;
    stop.title = "Stop playback";
    stop.setAttribute("aria-label", "Stop playback");
    stop.addEventListener("click", function () {
      if (window.hubMusic && window.hubMusic.stop) window.hubMusic.stop();
    });
    mini.appendChild(stop);

    var up = el("button", "mbar-mini-btn mbar-mini-up");
    up.type = "button";
    up.innerHTML = ICON_EXPAND;
    up.title = "Expand player";
    up.setAttribute("aria-label", "Expand player");
    up.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      expand();
    });
    mini.appendChild(up);

    mini.addEventListener("pointerdown", dragStart);
    window.addEventListener("pointermove", dragMove);
    window.addEventListener("pointerup", dragEnd);
    window.addEventListener("pointercancel", dragEnd);

    document.body.appendChild(mini);
    placeMini();
  }

  function anim(host, cls) {
    if (!host) return;
    host.classList.remove(cls);
    void host.offsetWidth;
    host.classList.add(cls);
    setTimeout(function () {
      host.classList.remove(cls);
    }, 420);
  }

  function hideBar() {
    if (!bar) return;
    self = true;
    bar.setAttribute("hidden", "");
    self = false;
  }

  function showBar() {
    if (!bar) return;
    self = true;
    bar.removeAttribute("hidden");
    self = false;
  }

  function minimize() {
    if (!bar || bar.hasAttribute("hidden")) return;
    minimized = true;
    hideBar();
    sync();
    if (mini) {
      mini.hidden = false;
      placeMini();
      anim(mini, "is-in");
    }
  }

  function expand() {
    minimized = false;
    if (mini) mini.hidden = true;
    showBar();
    sync();
    anim(bar, "is-in");
  }

  function teardown() {
    minimized = false;
    if (mini) mini.hidden = true;
  }

  function onBarMutation() {
    if (!bar) return;
    if (self) return;
    var visible = !bar.hasAttribute("hidden");
    if (visible) {
      if (minimized) {
        hideBar();
        sync();
        if (mini) mini.hidden = false;
      } else if (mini) {
        mini.hidden = true;
      }
    } else if (minimized) {
      sync();
      if (mini) mini.hidden = false;
    } else if (mini) {
      mini.hidden = true;
    }
  }

  function addMinimizeButton() {
    var right = document.querySelector("#musicBar .mbar-right");
    if (!right || document.getElementById("mbarMin")) return;
    var btn = el("button", "mbar-icon mbar-min");
    btn.id = "mbarMin";
    btn.type = "button";
    btn.innerHTML = ICON_COLLAPSE;
    btn.title = "Minimize player";
    btn.setAttribute("aria-label", "Minimize player");
    btn.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      minimize();
    });
    var vol = right.querySelector(".music-vol");
    if (vol && vol.nextSibling) right.insertBefore(btn, vol.nextSibling);
    else right.appendChild(btn);
  }

  function stripOldStop() {
    var old = document.getElementById("mbarStop");
    if (old && old.parentNode) old.parentNode.removeChild(old);
  }

  function restyleStop() {
    var stop = document.getElementById("musicClose");
    if (!stop) return;
    stop.classList.add("mbar-icon", "mbar-stop");
    stop.innerHTML = ICON_STOP;
    stop.title = "Stop playback";
    stop.setAttribute("aria-label", "Stop playback");
  }

  function onDocClick(ev) {
    var t = ev.target;
    if (!t || !t.closest) return;
    if (t.closest("#musicClose")) {
      setTimeout(teardown, 60);
    }
  }

  function mount() {
    bar = document.getElementById("musicBar");
    if (!bar) {
      setTimeout(mount, 400);
      return;
    }
    if (!mini) buildMini();
    stripOldStop();
    restyleStop();
    addMinimizeButton();
    paintGlow();
    document.addEventListener("click", onDocClick, true);
    var observer = new MutationObserver(onBarMutation);
    observer.observe(bar, { attributes: true, attributeFilter: ["hidden"], childList: true, subtree: true, characterData: true });
    var toggle = document.getElementById("musicBarToggle");
    if (toggle) {
      var tObs = new MutationObserver(sync);
      tObs.observe(toggle, { attributes: true, attributeFilter: ["aria-label"] });
    }
    var art = document.getElementById("musicBarArt");
    if (art) {
      var aObs = new MutationObserver(paintGlow);
      aObs.observe(art, { childList: true, subtree: true, attributes: true, attributeFilter: ["src"] });
    }
    var nameEl = document.getElementById("musicBarName");
    if (nameEl) {
      var nObs = new MutationObserver(function () {
        paintGlow();
        if (mini) sync();
      });
      nObs.observe(nameEl, { childList: true, characterData: true, subtree: true });
    }
    var stateEl = document.getElementById("musicBarState");
    if (stateEl && !stateEl.__link) {
      stateEl.__link = true;
      stateEl.classList.add("is-link");
      stateEl.title = "Go to artist";
      stateEl.addEventListener("click", function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        gotoArtist();
      });
    }
    window.addEventListener("resize", function () {
      if (mini && !mini.hidden) placeMini();
    });
    sync();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
})();
