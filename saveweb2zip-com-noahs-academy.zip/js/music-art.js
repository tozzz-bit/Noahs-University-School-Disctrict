(function () {
  "use strict";

  var API = location.pathname.indexOf("/new/") === 0 ? "/papi" : "/api";
  var BLANK = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";

  function inMusic(node) {
    return Boolean(node.closest && node.closest("#musicView, #musicBar, .music-side, .mx-view"));
  }

  document.addEventListener("error", function (ev) {
    var img = ev.target;
    if (!img || img.tagName !== "IMG" || !inMusic(img)) return;
    var src = img.getAttribute("src") || "";
    if (!/^https?:\/\//i.test(src)) {
      img.removeAttribute("src");
      img.src = BLANK;
      return;
    }
    if (img.getAttribute("data-art-retry") === "1") {
      img.removeAttribute("data-art-retry");
      img.src = BLANK;
      return;
    }
    img.setAttribute("data-art-retry", "1");
    img.src = API + "/music/bin?url=" + encodeURIComponent(src);
  }, true);
})();
