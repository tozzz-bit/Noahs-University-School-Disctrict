(function () {
  "use strict";

  var VIEWS = [
    "homeView", "gamesView", "aiView", "webView", "musicView", "lbView",
    "shopView", "accountView", "supportView", "settingsView", "modView", "adminView"
  ];

  function gameOpen() {
    var page = document.getElementById("gamePage");
    return !!(page && page.classList.contains("active"));
  }

  function watch(id) {
    var el = document.getElementById(id);
    if (!el || !el.hasAttribute) return;
    var observer = new MutationObserver(function (records) {
      for (var i = 0; i < records.length; i += 1) {
        if (records[i].attributeName !== "hidden") continue;
        if (el.hasAttribute("hidden")) return;
        if (id === "gamesView" && !gameOpen()) window.scrollTo(0, 0);
        return;
      }
    });
    observer.observe(el, { attributes: true, attributeFilter: ["hidden"] });
  }

  for (var i = 0; i < VIEWS.length; i += 1) watch(VIEWS[i]);
})();
