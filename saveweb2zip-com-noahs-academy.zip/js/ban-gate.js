(function () {
  var CHECKED = 'hub_ban_checked';

  function render(message) {
    document.documentElement.classList.add('hub-device-banned');
    var bar = document.createElement('div');
    bar.className = 'ban-bar';
    bar.setAttribute('role', 'alert');

    var text = document.createElement('p');
    text.className = 'ban-bar-text';
    text.textContent = message;

    var close = document.createElement('button');
    close.type = 'button';
    close.className = 'ban-bar-close';
    close.setAttribute('aria-label', 'Hide notice');
    close.textContent = 'Hide';
    close.addEventListener('click', function () {
      bar.remove();
    });

    bar.appendChild(text);
    bar.appendChild(close);
    document.body.appendChild(bar);
  }

  function gate() {
    fetch('/api/ban-status', { credentials: 'same-origin', cache: 'no-store' })
      .then(function (res) {
        return res.ok ? res.json() : null;
      })
      .then(function (data) {
        if (!data || !data.banned) return;
        try {
          sessionStorage.setItem(CHECKED, '1');
        } catch (error) {
        }
        render(data.message || 'This device is banned.');
      })
      .catch(function () {
      });
  }

  function blockChat(event) {
    if (!document.documentElement.classList.contains('hub-device-banned')) return;
    event.preventDefault();
    event.stopPropagation();
    var existing = document.querySelector('.ban-bar');
    if (existing) {
      existing.scrollIntoView({ block: 'nearest' });
      return;
    }
    render('This device is banned.');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', gate);
  } else {
    gate();
  }

  document.addEventListener('click', function (event) {
    var target = event.target;
    if (!target || !target.closest) return;
    var entry = target.closest('#navChat, #railSignin, #ptAccount');
    if (entry) blockChat(event);
  }, true);
})();
