(function () {
  "use strict";

  var KEY = "hub_bg";
  var KEY_MOTION = "hub_bg_motion";
  var KEY_QUALITY = "hub_bg_quality";
  var SEPIA_HUE = 39;
  var FADE = 420;
  var FREEZE_AFTER = 900;

  var REGISTRY = {
    amber: { name: "Amber", canvas: amberEffect },
    aurora: { name: "Aurora", file: "aurora-veil.html", brightness: 0.88, scrim: 0.22 },
    ribbons: { name: "Ribbons", canvas: ribbonsEffect },
    silk: { name: "Silk", file: "silk-groove.html", brightness: 0.54, scrim: 0.42 },
    contour: { name: "Contour", file: "topographic.html", brightness: 0.9, scrim: 0.18 },
    flow: { name: "Flow field", file: "flow-field.html", brightness: 0.72, scrim: 0.28 }
  };

  var DEFAULT_ID = "amber";
  var ORDER = ["amber", "aurora", "ribbons", "silk", "contour", "flow"];

  var current = null;
  var stopCanvas = null;
  var stage = null;
  var layer = null;
  var fadeTimer = 0;
  var freezeTimer = 0;
  var base = { r: 255, g: 122, b: 26 };
  var motionQuery = window.matchMedia ? window.matchMedia("(prefers-reduced-motion: reduce)") : null;

  function read(key) {
    try {
      return localStorage.getItem(key);
    } catch (error) {
      return null;
    }
  }

  function write(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch (error) {}
  }

  function chosen() {
    var value = read(KEY);
    return value && REGISTRY[value] ? value : DEFAULT_ID;
  }

  function animating() {
    var value = read(KEY_MOTION);
    if (value === "0") return false;
    if (value === "1") return true;
    return !(motionQuery && motionQuery.matches);
  }

  function quality() {
    var value = read(KEY_QUALITY);
    if (value === "low" || value === "high") return value;
    var memory = navigator.deviceMemory || 4;
    var cores = navigator.hardwareConcurrency || 4;
    return memory <= 2 || cores <= 2 ? "low" : "high";
  }

  function dprCap() {
    return Math.min(quality() === "low" ? 1 : 1.5, window.devicePixelRatio || 1);
  }

  function densityScale() {
    return quality() === "low" ? 0.4 : 1;
  }

  function frameBudget() {
    return quality() === "low" ? 33 : 0;
  }

  function clamp(value) {
    return Math.max(0, Math.min(255, Math.round(value)));
  }

  function mix(target, weight) {
    return {
      r: clamp(base.r + (target - base.r) * weight),
      g: clamp(base.g + (target - base.g) * weight),
      b: clamp(base.b + (target - base.b) * weight)
    };
  }

  function rgba(colour, alpha) {
    return "rgba(" + colour.r + "," + colour.g + "," + colour.b + "," + alpha + ")";
  }

  function tone(amount, alpha) {
    return rgba(amount >= 0 ? mix(255, amount) : mix(0, Math.abs(amount)), alpha);
  }

  function readAccent() {
    var raw = getComputedStyle(document.documentElement).getPropertyValue("--accent-rgb").trim();
    var parts = raw.split(",").map(function (value) {
      return Number(value.trim());
    });
    if (parts.length === 3 && parts.every(function (value) {
      return Number.isFinite(value);
    })) {
      base = { r: parts[0], g: parts[1], b: parts[2] };
    }
  }

  function toHSL(colour) {
    var r = colour.r / 255;
    var g = colour.g / 255;
    var b = colour.b / 255;
    var max = Math.max(r, g, b);
    var min = Math.min(r, g, b);
    var l = (max + min) / 2;
    var h = 0;
    var s = 0;
    if (max !== min) {
      var delta = max - min;
      s = l > 0.5 ? delta / (2 - max - min) : delta / (max + min);
      if (max === r) h = ((g - b) / delta + (g < b ? 6 : 0)) / 6;
      else if (max === g) h = ((b - r) / delta + 2) / 6;
      else h = ((r - g) / delta + 4) / 6;
    }
    return { h: h * 360, s: s };
  }

  function themeFilter(brightness) {
    var hsl = toHSL(base);
    var shift = Math.round(hsl.h - SEPIA_HUE);
    var saturation = Math.max(1.1, Math.min(6, 1.3 + hsl.s * 3.6));
    return "sepia(1) saturate(" + saturation.toFixed(2) + ") hue-rotate(" + shift + "deg) brightness(" + brightness + ")";
  }

  function canvasLoop(canvas, draw, onReady) {
    var width = 0;
    var height = 0;
    var ctx = null;
    var dpr = 1;
    var raf = 0;
    var last = performance.now();
    var lastPaint = 0;
    var time = 0;
    var alive = true;
    var paused = false;
    var still = !animating();
    var budget = frameBudget();
    var announced = false;

    function announce() {
      if (announced || !onReady) return;
      announced = true;
      onReady();
    }

    function paintStill() {
      draw.paint(ctx, width, height, time, 0);
      announce();
    }

    function resize() {
      dpr = dprCap();
      width = canvas.clientWidth || window.innerWidth;
      height = canvas.clientHeight || window.innerHeight;
      canvas.width = Math.max(1, Math.round(width * dpr));
      canvas.height = Math.max(1, Math.round(height * dpr));
      ctx = canvas.getContext("2d");
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      draw.resize(width, height);
      if (still) paintStill();
    }

    function frame(now) {
      if (!alive) return;
      if (paused) {
        raf = requestAnimationFrame(frame);
        return;
      }
      if (budget && now - lastPaint < budget) {
        raf = requestAnimationFrame(frame);
        return;
      }
      lastPaint = now;
      var delta = Math.min(50, now - last) / 1000;
      last = now;
      time += delta;
      draw.paint(ctx, width, height, time, delta);
      announce();
      raf = requestAnimationFrame(frame);
    }

    function onVisibility() {
      paused = document.hidden;
      if (!paused) last = performance.now();
    }

    resize();
    if (still) {
      announce();
    } else {
      raf = requestAnimationFrame(frame);
      document.addEventListener("visibilitychange", onVisibility);
    }
    window.addEventListener("resize", resize);

    return {
      stop: function () {
        alive = false;
        cancelAnimationFrame(raf);
        window.removeEventListener("resize", resize);
        document.removeEventListener("visibilitychange", onVisibility);
      }
    };
  }

  function amberEffect(canvas, onReady) {
    var hot = mix(255, 0.55);
    var deep = mix(0, 0.35);
    var sprite = function (stops, size) {
      var node = document.createElement("canvas");
      node.width = node.height = size;
      var ctx = node.getContext("2d");
      var gradient = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
      for (var index = 0; index < stops.length; index += 1) {
        gradient.addColorStop(stops[index][0], stops[index][1]);
      }
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, size, size);
      return node;
    };
    var cores = sprite([
      [0, rgba(hot, 1)],
      [0.22, rgba(base, 0.72)],
      [0.55, rgba(deep, 0.2)],
      [1, rgba(deep, 0)]
    ], 96);
    var bokeh = sprite([
      [0, rgba(base, 0.5)],
      [0.45, rgba(base, 0.34)],
      [0.75, rgba(deep, 0.12)],
      [1, rgba(deep, 0)]
    ], 128);
    var layers = [
      { count: 90, rMin: 0.8, rMax: 2.4, vMin: 20, vMax: 44, aMin: 0.28, aMax: 0.6, sway: 11, image: cores, scale: 4.4 },
      { count: 44, rMin: 1.8, rMax: 4.0, vMin: 30, vMax: 62, aMin: 0.38, aMax: 0.78, sway: 17, image: cores, scale: 5.2 },
      { count: 22, rMin: 5, rMax: 14, vMin: 36, vMax: 72, aMin: 0.16, aMax: 0.38, sway: 26, image: bokeh, scale: 3.6 }
    ];
    var parts = [];

    function seed(width, height) {
      parts.length = 0;
      var scale = Math.max(0.5, Math.min(1.5, (width * height) / 1400000)) * densityScale();
      for (var index = 0; index < layers.length; index += 1) {
        var layerSpec = layers[index];
        var count = Math.round(layerSpec.count * scale);
        for (var i = 0; i < count; i += 1) {
          parts.push({
            layer: layerSpec,
            x: Math.random() * width,
            y: Math.random() * height,
            r: layerSpec.rMin + Math.random() * (layerSpec.rMax - layerSpec.rMin),
            v: layerSpec.vMin + Math.random() * (layerSpec.vMax - layerSpec.vMin),
            a: layerSpec.aMin + Math.random() * (layerSpec.aMax - layerSpec.aMin),
            swayAmp: layerSpec.sway * (0.6 + Math.random() * 0.8),
            swayFreq: 0.2 + Math.random() * 0.5,
            phase: Math.random() * Math.PI * 2
          });
        }
      }
    }

    return canvasLoop(canvas, {
      resize: function (width, height) {
        seed(width, height);
      },
      paint: function (ctx, width, height, time, delta) {
        if (!parts.length) seed(width, height);
        ctx.clearRect(0, 0, width, height);

        var glow = ctx.createLinearGradient(0, height, 0, height * 0.45);
        glow.addColorStop(0, rgba(base, 0.2));
        glow.addColorStop(1, rgba(base, 0));
        ctx.fillStyle = glow;
        ctx.fillRect(0, height * 0.45, width, height * 0.55);

        ctx.globalCompositeOperation = "lighter";
        for (var index = 0; index < parts.length; index += 1) {
          var part = parts[index];
          part.y -= part.v * delta;
          part.x += Math.sin(time * part.swayFreq + part.phase) * part.swayAmp * delta;
          if (part.y < -40) {
            part.y = height + 40;
            part.x = Math.random() * width;
          }
          if (part.x < -40) part.x = width + 40;
          if (part.x > width + 40) part.x = -40;
          var heat = 0.75 + 0.25 * Math.sin(time * 1.6 + part.phase);
          var size = part.r * part.layer.scale * 2;
          ctx.globalAlpha = Math.min(1, part.a * heat);
          ctx.drawImage(part.layer.image, part.x - size / 2, part.y - size / 2, size, size);
        }
        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = "source-over";
      }
    }, onReady);
  }

  function ribbonsEffect(canvas, onReady) {
    var bands = [
      { amount: 0.62, y: 0.22, amp: 0.075, width: 44, alpha: 0.07, speed: 0.55 },
      { amount: 0.2, y: 0.35, amp: 0.095, width: 58, alpha: 0.085, speed: 0.42 },
      { amount: -0.18, y: 0.48, amp: 0.12, width: 68, alpha: 0.07, speed: 0.34 },
      { amount: -0.55, y: 0.61, amp: 0.14, width: 78, alpha: 0.055, speed: 0.28 }
    ];

    function ridge(ctx, width, height, band, index, time) {
      var step = Math.max(8, Math.round(width / 110));
      ctx.beginPath();
      for (var x = -step; x <= width + step; x += step) {
        var t = x / width;
        var wave =
          Math.sin(t * 5.4 + time * band.speed + index * 1.9) * band.amp +
          Math.sin(t * 11.7 - time * band.speed * 0.72 + index * 0.8) * band.amp * 0.4 +
          Math.sin(t * 2.1 + time * 0.16) * band.amp * 0.55;
        var y = height * (band.y + wave);
        if (x === -step) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }

    return canvasLoop(canvas, {
      resize: function () {},
      paint: function (ctx, width, height, time) {
        ctx.clearRect(0, 0, width, height);
        ctx.lineJoin = "round";
        ctx.lineCap = "round";
        ctx.globalCompositeOperation = "lighter";

        var haze = ctx.createLinearGradient(0, height * 0.12, 0, height * 0.92);
        haze.addColorStop(0, tone(-0.2, 0));
        haze.addColorStop(0.45, tone(-0.05, 0.02));
        haze.addColorStop(1, tone(-0.2, 0));
        ctx.fillStyle = haze;
        ctx.fillRect(0, 0, width, height);

        for (var index = 0; index < bands.length; index += 1) {
          var band = bands[index];
          ctx.strokeStyle = tone(band.amount, band.alpha * 0.4);
          ctx.lineWidth = band.width * 3.4;
          ridge(ctx, width, height, band, index, time);
          ctx.strokeStyle = tone(band.amount, band.alpha * 0.72);
          ctx.lineWidth = band.width * 1.6;
          ridge(ctx, width, height, band, index, time);
          ctx.strokeStyle = tone(band.amount, band.alpha);
          ctx.lineWidth = Math.max(1.4, band.width * 0.32);
          ridge(ctx, width, height, band, index, time);
        }

        ctx.globalCompositeOperation = "source-over";
      }
    }, onReady);
  }

  function ensureStage() {
    if (stage && stage.isConnected) return stage;
    stage = document.createElement("div");
    stage.id = "hub-bg-stage";
    stage.setAttribute("aria-hidden", "true");
    stage.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:-1;overflow:hidden";
    document.body.appendChild(stage);
    return stage;
  }

  function teardown() {
    clearTimeout(fadeTimer);
    clearTimeout(freezeTimer);
    if (stopCanvas) {
      stopCanvas.stop();
      stopCanvas = null;
    }
    if (stage) {
      while (stage.firstChild) stage.removeChild(stage.firstChild);
    }
    layer = null;
  }

  function freezeFrame(frame) {
    try {
      var win = frame.contentWindow;
      win.requestAnimationFrame = function () {
        return 0;
      };
      win.cancelAnimationFrame = function () {};
    } catch (error) {}
  }

  function buildLayer(id, instant) {
    var entry = REGISTRY[id];
    var moving = animating();
    var node = document.createElement("div");
    node.className = "hub-bg-layer";
    node.style.cssText = "position:absolute;inset:0;opacity:" + (instant ? 1 : 0) + ";transition:opacity " + FADE + "ms ease";

    var reveal = function () {
      if (instant) return;
      requestAnimationFrame(function () {
        node.style.opacity = "1";
      });
    };

    if (entry.canvas) {
      var canvas = document.createElement("canvas");
      canvas.style.cssText = "position:absolute;inset:0;width:100%;height:100%;display:block";
      node.appendChild(canvas);
      ensureStage().appendChild(node);
      stopCanvas = entry.canvas(canvas, reveal);
      if (!moving) reveal();
      return node;
    }

    var frame = document.createElement("iframe");
    frame.setAttribute("scrolling", "no");
    frame.setAttribute("tabindex", "-1");
    frame.src = "bg/" + entry.file + (quality() === "low" ? "?p=3" : "");
    frame.style.cssText = "position:absolute;inset:0;width:100%;height:100%;border:0";
    frame.style.filter = themeFilter(entry.brightness);
    frame.addEventListener("load", function () {
      try {
        var label = frame.contentDocument && frame.contentDocument.querySelector(".label");
        if (label) label.remove();
      } catch (error) {}
      if (moving) {
        reveal();
        return;
      }
      clearTimeout(freezeTimer);
      freezeTimer = setTimeout(function () {
        freezeFrame(frame);
        reveal();
      }, FREEZE_AFTER);
    });
    node.appendChild(frame);

    var scrim = document.createElement("div");
    scrim.style.cssText =
      "position:absolute;inset:0;pointer-events:none;" +
      "background:radial-gradient(120% 120% at 50% 40%,rgba(8,6,10," + entry.scrim * 0.55 + ") 0%,rgba(6,5,8," + entry.scrim + ") 60%,rgba(5,4,7," + Math.min(0.9, entry.scrim + 0.2) + ") 100%)";
    node.appendChild(scrim);

    ensureStage().appendChild(node);
    if (moving) setTimeout(reveal, 600);
    return node;
  }

  function mount(id) {
    if (!REGISTRY[id]) id = DEFAULT_ID;
    current = id;
    readAccent();

    var snow = document.getElementById("snowfall");
    if (snow) snow.style.display = "none";

    var still = !animating();
    var previous = stage ? Array.prototype.slice.call(stage.children) : [];
    if (stopCanvas) {
      stopCanvas.stop();
      stopCanvas = null;
    }

    layer = buildLayer(id, still);

    clearTimeout(fadeTimer);
    fadeTimer = setTimeout(function () {
      for (var index = 0; index < previous.length; index += 1) {
        if (previous[index].parentNode) previous[index].parentNode.removeChild(previous[index]);
      }
    }, still ? 0 : FADE + 60);
  }

  function set(id) {
    if (!REGISTRY[id]) return;
    write(KEY, id);
    mount(id);
    document.dispatchEvent(new CustomEvent("hub:bgchange", { detail: { background: id } }));
  }

  window.hubBackground = {
    set: set,
    get: function () {
      return current;
    },
    list: function () {
      return ORDER.map(function (key) {
        return { id: key, name: REGISTRY[key].name };
      });
    }
  };

  window.addEventListener("hub:theme", function () {
    teardown();
    mount(current || chosen());
  });

  document.addEventListener("hub:bg", function (event) {
    if (event.detail && event.detail.background) mount(event.detail.background);
  });

  window.addEventListener("storage", function (event) {
    if (event.key === KEY) mount(chosen());
    if (event.key === KEY_MOTION || event.key === KEY_QUALITY) {
      teardown();
      mount(current || chosen());
    }
  });

  if (motionQuery && motionQuery.addEventListener) {
    motionQuery.addEventListener("change", function () {
      teardown();
      mount(current || chosen());
    });
  }

  mount(chosen());
})();
