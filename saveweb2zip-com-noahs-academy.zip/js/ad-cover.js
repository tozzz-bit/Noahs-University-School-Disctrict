(function () {
  "use strict";

  var KEY = "hub_ads_hidden";
  var SELECTOR = [".home-ad", ".home-ad-frame", ".ad-slot", ".ad-slot-frame", "ins.adsbygoogle", "iframe[id^=aswift]", ".google-auto-placed", "[data-ad-slot]"].join(",");
  var entries = [];
  var frame = null;

  function read() {
    try {
      var list = JSON.parse(sessionStorage.getItem(KEY) || "[]");
      return Array.isArray(list) ? list : [];
    } catch (error) {
      return [];
    }
  }

  function write(list) {
    try { sessionStorage.setItem(KEY, JSON.stringify(list)); } catch (error) {}
  }

  function reportIcon() {
    var ns = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    var first = document.createElementNS(ns, "line");
    first.setAttribute("x1", "6");
    first.setAttribute("y1", "6");
    first.setAttribute("x2", "18");
    first.setAttribute("y2", "18");
    first.setAttribute("stroke", "currentColor");
    first.setAttribute("stroke-width", "2.2");
    first.setAttribute("stroke-linecap", "round");
    var second = document.createElementNS(ns, "line");
    second.setAttribute("x1", "18");
    second.setAttribute("y1", "6");
    second.setAttribute("x2", "6");
    second.setAttribute("y2", "18");
    second.setAttribute("stroke", "currentColor");
    second.setAttribute("stroke-width", "2.2");
    second.setAttribute("stroke-linecap", "round");
    svg.appendChild(first);
    svg.appendChild(second);
    return svg;
  }

  function build(entry) {
    var button = document.createElement("button");
    button.type = "button";
    button.className = "ad-report";
    button.title = "Hide ad";
    button.setAttribute("aria-label", "Hide ad");
    button.appendChild(reportIcon());

    var cover = document.createElement("div");
    cover.className = "ad-block";
    cover.setAttribute("role", "status");

    var inner = document.createElement("div");
    inner.className = "ad-block-inner";

    var face = document.createElement("span");
    face.className = "ad-block-face";
    face.textContent = ":(";

    var body = document.createElement("div");
    body.className = "ad-block-body";

    var text = document.createElement("p");
    text.className = "ad-block-text";
    text.textContent = "Ad blocked";

    var hint = document.createElement("p");
    hint.className = "ad-block-hint";
    hint.textContent = "Tap to show it again";

    body.appendChild(text);
    body.appendChild(hint);
    inner.appendChild(face);
    inner.appendChild(body);
    cover.appendChild(inner);

    button.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      toggle(entry, true);
    });
    cover.addEventListener("click", function () {
      toggle(entry, false);
    });

    if (entry.element.tagName !== "IFRAME") {
      entry.embedded = true;
      if (getComputedStyle(entry.element).position === "static") entry.element.classList.add("ad-cover-host");
      cover.classList.add("embedded");
      button.classList.add("embedded");
      entry.element.appendChild(cover);
      entry.element.appendChild(button);
    } else {
      var host = entry.element.parentElement;
      if (host && getComputedStyle(host).position === "static") host.classList.add("ad-cover-host");
      cover.classList.add("embedded");
      button.classList.add("embedded");
      document.body.appendChild(cover);
      document.body.appendChild(button);
    }

    entry.button = button;
    entry.cover = cover;
  }

  function toggle(entry, value) {
    entry.hidden = value;
    var list = read().filter(function (key) { return key !== entry.key; });
    if (value) list.push(entry.key);
    write(list);
    place(entry);
    schedule();
  }

  function place(entry) {
    var rect = entry.element.getBoundingClientRect();
    var visible = rect.width > 40 && rect.height > 24 && rect.bottom > 0 && rect.top < window.innerHeight;
    if (!visible) {
      entry.button.classList.remove("show");
      entry.cover.classList.remove("show");
      return false;
    }
    if (entry.hidden) {
      entry.cover.classList.add("show");
      entry.button.classList.remove("show");
    } else {
      entry.button.classList.add("show");
      entry.cover.classList.remove("show");
    }
    entry.cover.classList.toggle("wide", rect.width > rect.height * 2.4);
    return true;
  }

  function tick() {
    frame = null;
    var live = 0;
    for (var i = 0; i < entries.length; i += 1) {
      if (place(entries[i])) live += 1;
    }
    if (live) frame = requestAnimationFrame(tick);
  }

  function schedule() {
    if (!frame) frame = requestAnimationFrame(tick);
  }

  function scan() {
    var nodes = document.querySelectorAll(SELECTOR);
    var stored = read();
    var added = false;
    var seen = {};
    for (var i = 0; i < nodes.length; i += 1) {
      var element = nodes[i];
      if (element.dataset.adCoverBound === "1") continue;
      var parent = element.parentElement;
      if (parent && parent.closest(SELECTOR)) continue;
      var signature = element.tagName.toLowerCase() + "." + String(element.className || "").trim().replace(/\s+/g, ".");
      seen[signature] = (seen[signature] || 0) + 1;
      var key = "ad:" + signature + "#" + seen[signature];
      element.dataset.adCoverBound = "1";
      element.dataset.adCoverKey = key;
      var entry = { element: element, key: key, hidden: stored.indexOf(key) > -1, embedded: false };
      build(entry);
      entries.push(entry);
      added = true;
    }
    for (var j = 0; j < entries.length; j += 1) entries[j].hidden = stored.indexOf(entries[j].key) > -1;
    if (added) schedule();
  }

  function start() {
    if (!document.body) return;
    scan();
    var observer = new MutationObserver(function () { scan(); });
    observer.observe(document.body, { childList: true, subtree: true });
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
