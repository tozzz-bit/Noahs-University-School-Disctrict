(function () {
  "use strict";

  var API = "/api/chat";
  var state = { tab: "friends", data: null, busy: false, loaded: 0 };

  function token() {
    try { return localStorage.getItem("hub_token") || ""; } catch (e) { return ""; }
  }

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = text;
    return node;
  }

  function api(path, body, method) {
    var headers = { "Content-Type": "application/json" };
    var t = token();
    if (t) headers.Authorization = t;
    return fetch(API + path, {
      method: method || (body ? "POST" : "GET"),
      headers: headers,
      body: body ? JSON.stringify(body) : undefined
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (!res.ok) throw new Error((data && data.message) || "Something went wrong.");
        return data;
      });
    });
  }

  function note(text) {
    var box = document.getElementById("fxNote");
    if (!box) {
      box = el("div", "fx-note");
      box.id = "fxNote";
      document.body.appendChild(box);
    }
    box.textContent = text;
    box.classList.add("is-on");
    clearTimeout(box.__t);
    box.__t = setTimeout(function () { box.classList.remove("is-on"); }, 2400);
  }

  function initials(name) {
    return String(name || "?").charAt(0).toUpperCase();
  }

  function avatar(user, cls) {
    var box = el("span", cls || "fx-avatar");
    if (user && user.avatar) {
      var img = el("img");
      img.src = user.avatar;
      img.alt = "";
      img.loading = "lazy";
      img.addEventListener("error", function () {
        img.remove();
        box.textContent = initials(user.username);
      });
      box.appendChild(img);
    } else {
      box.textContent = initials(user && user.username);
    }
    return box;
  }

  function online(user) {
    var at = user && user.lastSeenAt ? Date.parse(String(user.lastSeenAt).replace(" ", "T")) : NaN;
    if (!Number.isFinite(at)) return false;
    return Date.now() - at < 5 * 60 * 1000;
  }

  function load(force) {
    if (!token()) {
      state.data = { friends: [], incoming: [], outgoing: [], allowRequests: true, count: 0 };
      return Promise.resolve(state.data);
    }
    if (!force && state.data && Date.now() - state.loaded < 20000) return Promise.resolve(state.data);
    return api("/friends").then(function (data) {
      state.data = data || { friends: [], incoming: [], outgoing: [], allowRequests: true, count: 0 };
      state.loaded = Date.now();
      paintBadge();
      return state.data;
    }).catch(function (err) {
      state.data = { friends: [], incoming: [], outgoing: [], allowRequests: true, count: 0 };
      return state.data;
    });
  }

  function paintBadge() {
    var badge = document.getElementById("fxBadge");
    if (!badge) return;
    var n = (state.data && state.data.incoming ? state.data.incoming.length : 0);
    badge.textContent = n > 9 ? "9+" : String(n);
    badge.hidden = !n;
  }

  function overlay() {
    var node = document.getElementById("fxOverlay");
    if (node) return node;
    node = el("div", "fx-overlay");
    node.id = "fxOverlay";
    node.hidden = true;

    var panel = el("div", "fx-panel");
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "Friends");

    var head = el("header", "fx-head");
    head.appendChild(el("h2", "fx-title", "Friends"));
    var actions = el("div", "fx-head-actions");
    var gear = el("button", "fx-icon-btn", "⚙");
    gear.type = "button";
    gear.id = "fxSettingsBtn";
    gear.title = "Friend request settings";
    gear.setAttribute("aria-label", "Friend request settings");
    actions.appendChild(gear);
    var closeBtn = el("button", "fx-icon-btn", "✕");
    closeBtn.type = "button";
    closeBtn.id = "fxClose";
    closeBtn.title = "Close";
    closeBtn.setAttribute("aria-label", "Close friends");
    actions.appendChild(closeBtn);
    head.appendChild(actions);
    panel.appendChild(head);

    var tabs = el("div", "fx-tabs");
    tabs.id = "fxTabs";
    var defs = [["friends", "Friends"], ["requests", "Requests"], ["add", "Add friend"]];
    for (var i = 0; i < defs.length; i += 1) {
      (function (def) {
        var tab = el("button", "fx-tab", def[1]);
        tab.type = "button";
        tab.setAttribute("data-tab", def[0]);
        tab.addEventListener("click", function () {
          state.tab = def[0];
          paint();
        });
        tabs.appendChild(tab);
      })(defs[i]);
    }
    panel.appendChild(tabs);

    var body = el("div", "fx-body");
    body.id = "fxBody";
    panel.appendChild(body);

    var settings = el("div", "fx-settings");
    settings.id = "fxSettings";
    settings.hidden = true;
    var label = el("label", "fx-toggle");
    var check = document.createElement("input");
    check.type = "checkbox";
    check.id = "fxAllow";
    label.appendChild(check);
    label.appendChild(el("span", "", "Allow friend requests"));
    settings.appendChild(label);
    settings.appendChild(el("p", "fx-hint", "Turn this off and nobody new can send you a request. Existing friends stay."));
    panel.appendChild(settings);

    node.appendChild(panel);
    document.body.appendChild(node);

    node.addEventListener("click", function (ev) {
      if (ev.target === node) close();
    });
    closeBtn.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      close();
    });
    gear.addEventListener("click", function () {
      var box = document.getElementById("fxSettings");
      var show = box.hasAttribute("hidden");
      if (show) box.removeAttribute("hidden");
      else box.setAttribute("hidden", "");
    });
    check.addEventListener("change", function () {
      api("/friend/settings", { allowRequests: check.checked }).then(function (res) {
        if (state.data) state.data.allowRequests = Boolean(res && res.allowRequests);
        note(check.checked ? "Friend requests on" : "Friend requests off");
      }).catch(function (err) {
        check.checked = !check.checked;
        note(err.message || "Couldn't save that");
      });
    });
    document.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape" && !node.hidden) close();
    });
    return node;
  }

  function close() {
    var node = document.getElementById("fxOverlay");
    if (node) node.hidden = true;
  }

  function open() {
    var node = overlay();
    node.hidden = false;
    state.tab = state.tab || "friends";
    paint();
    load(true).then(paint);
  }

  function paint() {
    var body = document.getElementById("fxBody");
    if (!body) return;
    var tabs = document.querySelectorAll("#fxTabs .fx-tab");
    for (var t = 0; t < tabs.length; t += 1) {
      tabs[t].classList.toggle("is-active", tabs[t].getAttribute("data-tab") === state.tab);
    }
    var data = state.data || { friends: [], incoming: [], outgoing: [] };
    var check = document.getElementById("fxAllow");
    if (check) check.checked = data.allowRequests !== false;

    while (body.firstChild) body.removeChild(body.firstChild);

    if (!token()) {
      body.appendChild(el("p", "fx-empty", "Sign in to add friends."));
      return;
    }

    if (state.tab === "friends") paintFriends(body, data);
    else if (state.tab === "requests") paintRequests(body, data);
    else paintAdd(body);
  }

  function paintFriends(body, data) {
    var list = data.friends || [];
    if (!list.length) {
      body.appendChild(el("p", "fx-empty", "No friends yet. Hit “Add friend” to find someone."));
      return;
    }
    var wrap = el("div", "fx-list");
    for (var i = 0; i < list.length; i += 1) {
      (function (user) {
        var row = el("div", "fx-row");
        var av = avatar(user);
        if (online(user)) av.classList.add("is-online");
        row.appendChild(av);
        var info = el("div", "fx-info");
        info.appendChild(el("span", "fx-name", user.username || "Unknown"));
        info.appendChild(el("span", "fx-sub", online(user) ? "online" : (user.customStatus || "friend")));
        row.appendChild(info);
        var acts = el("div", "fx-row-actions");
        var msg = el("button", "fx-btn fx-btn-primary", "Message");
        msg.type = "button";
        msg.addEventListener("click", function () { message(user); });
        acts.appendChild(msg);
        var remove = el("button", "fx-icon-btn fx-danger", "✕");
        remove.type = "button";
        remove.title = "Remove friend";
        remove.setAttribute("aria-label", "Remove " + (user.username || "friend"));
        remove.addEventListener("click", function () {
          if (!window.confirm("Remove " + (user.username || "this person") + " from your friends?")) return;
          api("/friend/remove", { userId: user.id }).then(function () {
            note("Removed");
            load(true).then(paint);
          }).catch(function (err) { note(err.message || "Couldn't remove"); });
        });
        acts.appendChild(remove);
        row.appendChild(acts);
        wrap.appendChild(row);
      })(list[i]);
    }
    body.appendChild(wrap);
  }

  function paintRequests(body, data) {
    var incoming = data.incoming || [];
    var outgoing = data.outgoing || [];
    if (incoming.length) {
      body.appendChild(el("p", "fx-section", "Waiting for you"));
      var wrap = el("div", "fx-list");
      for (var i = 0; i < incoming.length; i += 1) {
        (function (user) {
          var row = el("div", "fx-row");
          row.appendChild(avatar(user));
          var info = el("div", "fx-info");
          info.appendChild(el("span", "fx-name", user.username || "Unknown"));
          info.appendChild(el("span", "fx-sub", "wants to be friends"));
          row.appendChild(info);
          var acts = el("div", "fx-row-actions");
          var yes = el("button", "fx-btn fx-btn-primary", "Accept");
          yes.type = "button";
          yes.addEventListener("click", function () {
            api("/friend/accept", { userId: user.id }).then(function () {
              note("You and " + (user.username || "them") + " are friends");
              load(true).then(paint);
            }).catch(function (err) { note(err.message || "Couldn't accept"); });
          });
          acts.appendChild(yes);
          var no = el("button", "fx-btn", "Decline");
          no.type = "button";
          no.addEventListener("click", function () {
            api("/friend/decline", { userId: user.id }).then(function () {
              load(true).then(paint);
            }).catch(function (err) { note(err.message || "Couldn't decline"); });
          });
          acts.appendChild(no);
          row.appendChild(acts);
          wrap.appendChild(row);
        })(incoming[i]);
      }
      body.appendChild(wrap);
    }
    if (outgoing.length) {
      body.appendChild(el("p", "fx-section", "Sent"));
      var wrap2 = el("div", "fx-list");
      for (var j = 0; j < outgoing.length; j += 1) {
        (function (user) {
          var row = el("div", "fx-row is-muted");
          row.appendChild(avatar(user));
          var info = el("div", "fx-info");
          info.appendChild(el("span", "fx-name", user.username || "Unknown"));
          info.appendChild(el("span", "fx-sub", "waiting for them to accept"));
          row.appendChild(info);
          var acts = el("div", "fx-row-actions");
          var cancel = el("button", "fx-btn", "Cancel");
          cancel.type = "button";
          cancel.addEventListener("click", function () {
            api("/friend/remove", { userId: user.id }).then(function () {
              load(true).then(paint);
            }).catch(function (err) { note(err.message || "Couldn't cancel"); });
          });
          acts.appendChild(cancel);
          row.appendChild(acts);
          wrap2.appendChild(row);
        })(outgoing[j]);
      }
      body.appendChild(wrap2);
    }
    if (!incoming.length && !outgoing.length) {
      body.appendChild(el("p", "fx-empty", "No requests right now."));
    }
  }

  function paintAdd(body) {
    var form = el("form", "fx-add");
    var input = el("input", "fx-input");
    input.type = "text";
    input.placeholder = "username";
    input.autocomplete = "off";
    input.spellcheck = false;
    input.maxLength = 16;
    form.appendChild(input);
    var go = el("button", "fx-btn fx-btn-primary", "Add friend");
    go.type = "submit";
    form.appendChild(go);
    var result = el("p", "fx-result");
    form.addEventListener("submit", function (ev) {
      ev.preventDefault();
      var name = String(input.value || "").trim().toLowerCase();
      if (name.length < 2) {
        result.textContent = "Type a username.";
        return;
      }
      go.disabled = true;
      api("/friend/request", { username: name }).then(function (res) {
        if (res && res.accepted) {
          result.textContent = "You and " + (res.user ? res.user.username : name) + " are friends now.";
          input.value = "";
          load(true);
        } else if (res && res.pending) {
          result.textContent = "Request sent to " + (res.user ? res.user.username : name) + ".";
          input.value = "";
          load(true);
        } else {
          result.textContent = "Done.";
        }
        load(true);
      }).catch(function (err) {
        result.textContent = err.message || "Couldn't send that.";
      }).then(function () {
        go.disabled = false;
      });
    });
    body.appendChild(form);
    body.appendChild(result);
    body.appendChild(el("p", "fx-hint", "They need to accept before you show up in each other's friends list. Nobody can see anyone else's list."));
    setTimeout(function () { input.focus(); }, 30);
  }

  function message(user) {
    if (!user || !user.id) return;
    api("/dm/open", { userId: user.id }).then(function () {
      close();
      var rail = document.getElementById("dmRailBtn");
      if (rail) rail.click();
      var name = String(user.username || "").toLowerCase();
      var tries = 0;
      var timer = setInterval(function () {
        tries += 1;
        var items = document.querySelectorAll("#channelList .dm-item");
        for (var i = 0; i < items.length; i += 1) {
          var label = items[i].querySelector(".dm-item-name");
          if (label && String(label.textContent || "").trim().toLowerCase() === name) {
            clearInterval(timer);
            items[i].click();
            return;
          }
        }
        if (tries > 20) clearInterval(timer);
      }, 250);
    }).catch(function (err) {
      note(err.message || "Couldn't open that conversation");
    });
  }

  function mountButton() {
    var rail = document.getElementById("dmRailBtn");
    if (!rail || !rail.parentNode) return false;
    if (document.getElementById("fxOpen")) return true;
    var btn = el("button", "ss-item fx-open");
    btn.id = "fxOpen";
    btn.type = "button";
    var ico = el("span", "ss-ico");
    ico.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></svg>';
    btn.appendChild(ico);
    btn.appendChild(el("span", "fx-open-label", "Friends"));
    var badge = el("span", "fx-badge");
    badge.id = "fxBadge";
    badge.hidden = true;
    btn.appendChild(badge);
    btn.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      var menu = document.getElementById("serverSwitch");
      if (menu) menu.setAttribute("hidden", "");
      open();
    });
    rail.parentNode.insertBefore(btn, rail.nextSibling);
    return true;
  }

  function wrapProfile() {
    var chat = window.hubChat;
    if (!chat || typeof chat.profile !== "function" || chat.__fxProfile) return;
    var original = chat.profile;
    chat.__fxProfile = true;
    chat.profile = function () {
      var args = Array.prototype.slice.call(arguments);
      var userId = args[0];
      var result = original.apply(chat, args);
      if (userId) setTimeout(function () { decorateProfile(userId); }, 220);
      return result;
    };
  }

  function decorateProfile(userId) {
    var card = document.getElementById("chatModalCard");
    if (!card || !userId) return;
    var existing = card.querySelector(".fx-profile");
    if (existing) existing.remove();
    api("/friend/count?userId=" + encodeURIComponent(userId)).then(function (res) {
      if (!card || !card.isConnected) return;
      var box = el("div", "fx-profile");
      var count = Number(res && res.count) || 0;
      box.appendChild(el("span", "fx-profile-count", count + (count === 1 ? " friend" : " friends")));
      if (!res || !res.isFriend) {
        var add = el("button", "fx-btn fx-btn-primary fx-profile-add", "Add friend");
        add.type = "button";
        add.addEventListener("click", function () {
          api("/friend/request", { userId: userId }).then(function (out) {
            if (out && out.accepted) note("You're friends now");
            else note("Friend request sent");
            add.textContent = "Request sent";
            add.disabled = true;
            load(true);
          }).catch(function (err) {
            note(err.message || "Couldn't send that");
          });
        });
        box.appendChild(add);
      } else {
        box.appendChild(el("span", "fx-profile-tag", "Friend"));
      }
      card.appendChild(box);
    }).catch(function () {});
  }

  function poll() {
    if (!token()) return;
    load(true).then(function (data) {
      var n = (data && data.incoming) ? data.incoming.length : 0;
      if (n) paintBadge();
    });
  }

  function mount() {
    if (!mountButton()) {
      setTimeout(mount, 400);
      return;
    }
    wrapProfile();
    if (!window.__fxTimer) {
      window.__fxTimer = setInterval(function () { poll(); wrapProfile(); }, 90000);
      setTimeout(poll, 4000);
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
  [800, 2500, 6000, 15000, 40000].forEach(function (ms) { setTimeout(wrapProfile, ms); });
})();
