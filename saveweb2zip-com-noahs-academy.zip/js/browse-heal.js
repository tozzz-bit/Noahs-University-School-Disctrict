(function () {
  var KEY = "hub_sw_cleanup_v3";
  try {
    if (localStorage.getItem(KEY) === "1") return;
    localStorage.setItem(KEY, "1");
  } catch (e) {
    return;
  }
  if (!navigator.serviceWorker || !navigator.serviceWorker.getRegistrations) return;

  function retryLater() {
    try {
      localStorage.removeItem(KEY);
    } catch (e) {}
  }

  navigator.serviceWorker
    .getRegistrations()
    .then(function (regs) {
      return Promise.all(
        regs.map(function (reg) {
          return reg.unregister().catch(function () {});
        })
      );
    })
    .then(function () {
      if (!window.caches || !caches.keys) return null;
      return caches.keys().then(function (keys) {
        return Promise.all(
          keys.map(function (key) {
            return caches.delete(key).catch(function () {});
          })
        );
      });
    })
    .catch(retryLater);
})();
