(function () {
  'use strict';

  if (window.__memberSearch) return;
  window.__memberSearch = true;

  var LIST_CLASS = 'member-list-body';
  var ROW_CLASS = 'member-row';
  var EMPTY_CLASS = 'member-search-empty';
  var STATE = '__memberSearchState';

  var timer = 0;
  var busy = false;

  function build(container) {
    var wrap = document.createElement('div');
    wrap.className = 'member-search';

    var input = document.createElement('input');
    input.type = 'text';
    input.className = 'member-search-input';
    input.placeholder = 'Search members';
    input.autocomplete = 'off';
    input.spellcheck = false;
    input.setAttribute('aria-label', 'Search members');

    var count = document.createElement('span');
    count.className = 'member-search-count';
    count.setAttribute('aria-live', 'polite');

    wrap.appendChild(input);
    wrap.appendChild(count);

    var state = {
      container: container,
      wrap: wrap,
      input: input,
      count: count,
      empty: null,
      query: '',
      rows: -1
    };

    input.addEventListener('input', function () {
      apply(state);
    });

    input.addEventListener('keydown', function (event) {
      event.stopPropagation();
      if (event.key === 'Escape') {
        if (input.value) {
          input.value = '';
          apply(state);
        } else {
          input.blur();
        }
      }
    });

    input.addEventListener('keypress', function (event) {
      event.stopPropagation();
    });

    container.insertBefore(wrap, container.firstChild);
    return state;
  }

  function apply(state) {
    var container = state.container;
    if (!container || !container.isConnected) return;

    if (!container.contains(state.wrap)) container.insertBefore(state.wrap, container.firstChild);

    var query = (state.input.value || '').trim().toLowerCase();
    var tokens = query ? query.split(/\s+/) : [];
    var rows = container.querySelectorAll('.' + ROW_CLASS);
    var visible = 0;

    busy = true;

    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      var match = true;
      if (tokens.length) {
        var text = (row.textContent || '').toLowerCase();
        for (var t = 0; t < tokens.length; t++) {
          if (text.indexOf(tokens[t]) === -1) {
            match = false;
            break;
          }
        }
      }
      row.style.display = match ? '' : 'none';
      if (match) visible += 1;
    }

    if (state.count) {
      state.count.textContent = tokens.length ? visible + ' / ' + rows.length : '';
    }

    if (!state.empty) {
      state.empty = document.createElement('div');
      state.empty.className = EMPTY_CLASS;
      state.empty.textContent = 'No members match that search.';
    }

    var needsEmpty = tokens.length > 0 && visible === 0;
    if (needsEmpty && !state.empty.parentNode) container.appendChild(state.empty);
    if (!needsEmpty && state.empty.parentNode) state.empty.parentNode.removeChild(state.empty);

    state.query = query;
    state.rows = rows.length;
    busy = false;
  }

  function enhance(container) {
    if (container[STATE]) return;
    if (!container.querySelector('.' + ROW_CLASS)) return;
    if (!container.querySelector('.member-actions')) return;
    container[STATE] = build(container);
    apply(container[STATE]);
  }

  function scan() {
    if (busy) return;
    var lists = document.querySelectorAll('.' + LIST_CLASS);
    for (var i = 0; i < lists.length; i++) {
      var list = lists[i];
      if (!list.isConnected) continue;
      var state = list[STATE];
      if (!state) {
        enhance(list);
        continue;
      }
      var rows = list.querySelectorAll('.' + ROW_CLASS).length;
      var query = (state.input.value || '').trim().toLowerCase();
      if (rows !== state.rows || query !== state.query || !list.contains(state.wrap)) apply(state);
    }
  }

  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(scan, 60);
  }

  new MutationObserver(schedule).observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  schedule();
})();
