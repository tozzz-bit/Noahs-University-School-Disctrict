(function () {
  "use strict";

  var GRID_ID = "allLessonsGrid";
  var observer = null;
  var grid = null;
  var lastY = window.scrollY || 0;
  var direction = "down";
  var ticking = false;
  var bound = false;

  function reduced() {
    return window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }

  function performanceMode() {
    var value = null;
    try {
      value = localStorage.getItem("hub_bg_quality");
    } catch (error) {}
    if (value === "high") return false;
    if (value === "low") return true;
    var memory = navigator.deviceMemory || 4;
    var cores = navigator.hardwareConcurrency || 4;
    return memory <= 2 || cores <= 2;
  }

  function cards() {
    return grid ? grid.querySelectorAll(".card") : [];
  }

  function columnsOf(node) {
    var template = getComputedStyle(node).gridTemplateColumns || "";
    var count = template.split(" ").filter(Boolean).length;
    return count > 0 ? count : 1;
  }

  function applyDirection() {
    if (!grid) return;
    grid.classList.toggle("dir-up", direction === "up");
    grid.classList.toggle("dir-down", direction === "down");
  }

  function onScroll() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () {
      ticking = false;
      var y = window.scrollY || 0;
      var delta = y - lastY;
      if (Math.abs(delta) > 6) {
        direction = delta > 0 ? "down" : "up";
        applyDirection();
      }
      lastY = y;
    });
  }

  function observe(card, index, columns) {
    card.style.setProperty("--reveal-delay", String(index % columns));
    observer.observe(card);
  }

  function disable() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (!grid) return;
    grid.classList.remove("grid-reveal", "dir-up", "dir-down");
    var all = cards();
    for (var index = 0; index < all.length; index += 1) all[index].classList.add("is-in");
  }

  function enable() {
    if (!grid || observer) return;
    grid.classList.add("grid-reveal");
    applyDirection();

    observer = new IntersectionObserver(function (entries) {
      for (var index = 0; index < entries.length; index += 1) {
        var entry = entries[index];
        if (entry.isIntersecting) entry.target.classList.add("is-in");
        else entry.target.classList.remove("is-in");
      }
    }, { threshold: 0.01, rootMargin: "0px 0px 12% 0px" });

    var all = cards();
    var columns = columnsOf(grid);
    for (var index = 0; index < all.length; index += 1) {
      all[index].classList.add("is-in");
      observe(all[index], index, columns);
    }

    if (!bound) {
      bound = true;
      window.addEventListener("scroll", onScroll, { passive: true });

      var mutations = new MutationObserver(function (records) {
        if (!observer || !grid) return;
        var cols = columnsOf(grid);
        var base = grid.querySelectorAll(".card").length;
        for (var r = 0; r < records.length; r += 1) {
          var added = records[r].addedNodes;
          for (var a = 0; a < added.length; a += 1) {
            var card = added[a];
            if (!card || card.nodeType !== 1 || !card.classList.contains("card")) continue;
            if (card.classList.contains("is-in")) continue;
            observe(card, base - added.length + a, cols);
          }
        }
      });
      mutations.observe(grid, { childList: true });
    }
  }

  function apply() {
    if (!grid) return;
    if (reduced() || performanceMode()) disable();
    else enable();
  }

  function boot() {
    var node = document.getElementById(GRID_ID);
    if (!node) {
      setTimeout(boot, 300);
      return;
    }
    grid = node;
    apply();
    document.addEventListener("hub:quality", apply);
    window.addEventListener("storage", function (event) {
      if (event.key === "hub_bg_quality") apply();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
