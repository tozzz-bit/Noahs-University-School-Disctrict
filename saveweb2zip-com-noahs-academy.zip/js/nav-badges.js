(function () {
  "use strict";

  var ITEMS = [
    { id: "navMusic", key: "hub_music_new_seen" },
    { id: "navMovies", key: "hub_movies_new_seen" }
  ];

  function userId() {
    try {
      var token = localStorage.getItem("hub_token") || "";
      var part = token.split(".")[1];
      if (!part) return "";
      var json = JSON.parse(atob(part.replace(/-/g, "+").replace(/_/g, "/")));
      return String(json.id || json.sub || "");
    } catch (e) {
      return "";
    }
  }

  function readSeen(key) {
    try {
      return localStorage.getItem(key) || "";
    } catch (e) {
      return "";
    }
  }

  function markSeen(key, who) {
    try {
      localStorage.setItem(key, who);
    } catch (e) {}
  }

  function mountOne(item, who) {
    var button = document.getElementById(item.id);
    if (!button || button.__newBadge) return;
    button.__newBadge = true;
    if (readSeen(item.key) === who) return;
    button.classList.add("has-dot");
    button.addEventListener("click", function () {
      button.classList.remove("has-dot");
      markSeen(item.key, who);
    });
  }

  function mount() {
    var who = userId() || "guest";
    ITEMS.forEach(function (item) {
      mountOne(item, who);
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();

  window.hubNewBadges = { mount: mount };
})();
