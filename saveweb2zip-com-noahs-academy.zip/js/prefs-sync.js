(function () {
  "use strict";

  var API = location.pathname.indexOf("/new/") === 0 ? "/papi" : "/api";
  var KEYS = [
    "hub_popunder",
    "hub_obfuscate",
    "hub_anti_close",
    "hub_grid_cols",
    "hub_music",
    "hub_ai_model",
    "hub_web_engine",
    "hub_web_home",
    "hub_web_keys",
    "hub_web_bookmarks",
    "hub_movies_tmdb",
    "hub_favs",
    "hub_movies_favs",
    "hub_emoji_recent",
    "hub_bg",
    "hub_bg_motion",
    "hub_bg_quality"
  ];
  var STAMP = "hub_prefs_pulled";
  var RELOADED = "hub_prefs_reloaded";
  var REFRESH_MS = 10 * 60 * 1000;

  var timer = null;
  var lastSynced = null;
  var ready = false;
  var pending = false;
  var setItem = Storage.prototype.setItem;

  function token() {
    try {
      return localStorage.getItem("hub_token") || "";
    } catch (e) {
      return "";
    }
  }

  function userId(auth) {
    try {
      var payload = JSON.parse(atob(auth.split(".")[1].replace(/-/g, "+").replace(/_/g, "/")));
      return (payload && payload.id) || "";
    } catch (e) {
      return "";
    }
  }

  function sessionGet(key) {
    try {
      return sessionStorage.getItem(key);
    } catch (e) {
      return null;
    }
  }

  function sessionSet(key, value) {
    try {
      sessionStorage.setItem(key, value);
    } catch (e) {}
  }

  function canonical(settings) {
    var keys = Object.keys(settings).sort();
    var ordered = {};
    for (var i = 0; i < keys.length; i += 1) ordered[keys[i]] = settings[keys[i]];
    return JSON.stringify({ settings: ordered });
  }

  function collect() {
    var out = {};
    for (var i = 0; i < KEYS.length; i += 1) {
      var value = localStorage.getItem(KEYS[i]);
      if (value !== null) out[KEYS[i]] = value;
    }
    return out;
  }

  function writeLocal(key, value) {
    setItem.call(localStorage, key, value);
  }

  function push(keepalive) {
    var auth = token();
    if (!auth) return;
    if (!ready) {
      pending = true;
      return;
    }
    var payload = canonical(collect());
    if (payload === lastSynced) return;
    lastSynced = payload;
    try {
      fetch(API + "/chat/prefs", {
        method: "POST",
        headers: { Authorization: auth, "Content-Type": "application/json" },
        body: payload,
        cache: "no-store",
        keepalive: !!keepalive
      }).catch(function () {});
    } catch (e) {}
  }

  function queue() {
    pending = true;
    clearTimeout(timer);
    timer = setTimeout(function () {
      push(false);
    }, 500);
  }

  Storage.prototype.setItem = function (key, value) {
    setItem.call(this, key, value);
    if (this === localStorage && KEYS.indexOf(key) >= 0) queue();
  };

  function applyRemote(remote) {
    var changed = false;
    for (var key in remote) {
      if (!Object.prototype.hasOwnProperty.call(remote, key)) continue;
      if (KEYS.indexOf(key) < 0) continue;
      var value = remote[key];
      if (typeof value !== "string") continue;
      if (localStorage.getItem(key) === value) continue;
      writeLocal(key, value);
      changed = true;
    }
    return changed;
  }

  function pull() {
    var auth = token();
    if (!auth) {
      ready = true;
      return;
    }
    var stamp = STAMP + ":" + (userId(auth) || "anon");
    var lastPull = Number(sessionGet(stamp) || 0);
    if (lastPull && Date.now() - lastPull < REFRESH_MS) {
      ready = true;
      lastSynced = canonical(collect());
      return;
    }
    sessionSet(stamp, String(Date.now()));
    fetch(API + "/chat/prefs", { headers: { Authorization: auth }, cache: "no-store" })
      .then(function (response) {
        return response.ok ? response.json() : null;
      })
      .then(function (data) {
        if (!data || !data.settings) {
          ready = true;
          lastSynced = canonical(collect());
          return;
        }
        var changed = applyRemote(data.settings);
        lastSynced = canonical(data.settings);
        ready = true;
        if (changed && sessionGet(RELOADED) !== "1") {
          sessionSet(RELOADED, "1");
          location.reload();
          return;
        }
        if (canonical(collect()) !== lastSynced) push(false);
      })
      .catch(function () {
        ready = true;
        lastSynced = canonical(collect());
      })
      .then(function () {
        if (pending) push(false);
      });
  }

  window.addEventListener("pagehide", function () {
    push(true);
  });

  document.addEventListener("visibilitychange", function () {
    if (document.hidden) push(true);
  });

  pull();
})();
