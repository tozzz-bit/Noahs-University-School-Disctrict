(function () {
  "use strict";

  var API = "/api";
  var GENRES = [
    { name: "Hip-hop", q: "hip hop", hue: 18 },
    { name: "Pop", q: "pop hits", hue: 320 },
    { name: "R&B", q: "rnb", hue: 268 },
    { name: "Rock", q: "rock", hue: 4 },
    { name: "Electronic", q: "electronic", hue: 190 },
    { name: "Lo-fi", q: "lofi", hue: 150 },
    { name: "Country", q: "country", hue: 42 },
    { name: "Latin", q: "latin", hue: 340 }
  ];

  var state = {
    view: "home", id: "", q: "", scope: "all", data: null, scroll: 0,
    plSort: "custom", clean: true, genre: "", order: "relevance", pubQ: "", pubSort: "new"
  };
  var root = null;
  var browse = null;
  var loadSeq = 0;
  var liked = {};
  var likedPlaylistId = "";
  var libraryCache = { at: 0, playlists: [], shared: [] };
  var friendsMount = null;
  var sidebarSig = "";
  var sidebarWriting = false;

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = text;
    return node;
  }

  function picUrl(src) {
    var value = String(src || "");
    if (!value || value.charAt(0) === "/") return value;
    if (/^https?:\/\//i.test(value)) return API + "/music/bin?url=" + encodeURIComponent(value);
    return value;
  }

  function token() {
    try { return localStorage.getItem("hub_token") || ""; } catch (e) { return ""; }
  }

  function signedIn() {
    return Boolean(token());
  }

  function apiUpload(path, form) {
    var headers = {};
    var t = token();
    if (t) headers.Authorization = t;
    return fetch(API + path, { method: "POST", headers: headers, body: form }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (!res.ok) throw new Error((data && data.message) || "Upload failed.");
        return data;
      });
    });
  }

  function apiGet(path) {
    var headers = {};
    var t = token();
    if (t) headers.Authorization = t;
    return fetch(API + path, { headers: headers }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (!res.ok) throw new Error((data && data.message) || "Request failed.");
        return data;
      });
    });
  }

  function apiPost(path, body, method) {
    var headers = { "Content-Type": "application/json" };
    var t = token();
    if (t) headers.Authorization = t;
    return fetch(API + path, { method: method || "POST", headers: headers, body: JSON.stringify(body) })
      .then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (data) {
          if (!res.ok) throw new Error((data && data.message) || "Request failed.");
          return data;
        });
      });
  }

  function fmt(n) {
    n = Number(n) || 0;
    if (n >= 1000000000) return (n / 1000000000).toFixed(1).replace(/\.0$/, "") + "B";
    if (n >= 1000000) return (n / 1000000).toFixed(1).replace(/\.0$/, "") + "M";
    if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
    return String(n);
  }

  function fmtDur(sec) {
    sec = Math.max(0, Math.round(Number(sec) || 0));
    var m = Math.floor(sec / 60);
    var s = sec % 60;
    if (m >= 60) {
      var h = Math.floor(m / 60);
      return h + ":" + String(m % 60).padStart(2, "0") + ":" + String(s).padStart(2, "0");
    }
    return m + ":" + String(s).padStart(2, "0");
  }

  function totalDur(list) {
    var secs = 0;
    for (var i = 0; i < (list || []).length; i += 1) secs += Number(list[i].duration) || 0;
    return secs;
  }

  function playable(t) {
    return {
      id: String(t.id),
      title: t.title || "Untitled",
      artist: t.artist || "Unknown artist",
      cover: t.cover || (t.album && t.album.cover) || "",
      duration: Number(t.duration) || 0,
      isrc: t.isrc || ""
    };
  }

  function playList(list, index) {
    if (!window.hubMusic || !window.hubMusic.play) return;
    var mapped = [];
    for (var i = 0; i < list.length; i += 1) mapped.push(playable(list[i]));
    window.hubMusic.play(mapped, index);
  }

  function record(track) {
    if (!track || !track.id) return;
    if (!token()) return;
    apiPost("/music/play", {
      trackId: String(track.id),
      title: track.title || "",
      artist: track.artist || "",
      artistId: track.artistId || "",
      album: track.album || "",
      cover: track.cover || "",
      duration: Number(track.duration) || 0
    }).catch(function () {});
  }

  var REPEAT_KEY = "hub_music_repeat";
  var radioOn = false;
  var radioSeed = null;
  var radioBusy = false;
  var radioStalls = 0;

  function repeatMode() {
    try { return localStorage.getItem(REPEAT_KEY) || ""; } catch (e) { return ""; }
  }

  function radioFetch(seed) {
    if (!seed || radioBusy) return;
    radioBusy = true;
    var st = window.hubMusic && window.hubMusic.queueState ? window.hubMusic.queueState() : { list: [] };
    var ids = [];
    for (var i = 0; i < st.list.length && ids.length < 60; i += 1) {
      if (st.list[i] && st.list[i].id) ids.push(String(st.list[i].id));
    }
    var query = "?id=" + encodeURIComponent(seed.id || "") +
      "&title=" + encodeURIComponent(seed.title || "") +
      "&artist=" + encodeURIComponent(seed.artist || "") +
      "&artistId=" + encodeURIComponent(seed.artistId || "") +
      "&skip=" + encodeURIComponent(ids.join(","));
    apiGet("/music/radio" + query).then(function (res) {
      var items = (res && res.data && res.data.items) || [];
      appendRadio(items);
    }).catch(function () {
      radioStalls += 1;
    }).then(function () {
      radioBusy = false;
    });
  }

  function appendRadio(items) {
    if (!items || !items.length || !window.hubMusic || !window.hubMusic.setQueue) return;
    var state = window.hubMusic.queueState();
    var list = (state.list || []).slice();
    if (list.length > 400) return;
    var seen = {};
    for (var i = 0; i < list.length; i += 1) seen[String(list[i].id)] = true;
    var added = 0;
    for (var j = 0; j < items.length && added < 25 && list.length < 400; j += 1) {
      var track = playable(items[j]);
      if (!track.id || seen[String(track.id)]) continue;
      seen[String(track.id)] = true;
      list.push(track);
      added += 1;
    }
    if (!added) {
      radioStalls += 1;
      return;
    }
    radioStalls = 0;
    window.hubMusic.setQueue(list, state.index);
  }

  function tickRadio() {
    if (!radioOn || radioBusy || radioStalls > 3) return;
    if (repeatMode() === "all") return;
    var hub = window.hubMusic;
    if (!hub || !hub.queueState || !hub.isPlaying || !hub.isPlaying()) return;
    var st = hub.queueState();
    if (!st.list || !st.list.length) return;
    var left = st.list.length - 1 - st.index;
    if (left > 2) return;
    radioFetch(st.list[st.list.length - 1] || radioSeed);
  }

  function hookPlayer() {
    if (!window.hubMusic || window.hubMusic.__radio) return;
    var original = window.hubMusic.play;
    if (typeof original !== "function") return;
    window.hubMusic.play = function (list, index) {
      var items = Array.isArray(list) ? list.slice() : [];
      var at = Math.max(0, Number(index) || 0);
      var single = items.length <= 1;
      original.call(window.hubMusic, items, at);
      try {
        if (items[at]) record(items[at]);
      } catch (e) {}
      radioOn = true;
      radioSeed = items[at] || items[0] || null;
      radioStalls = 0;
      if (single && radioSeed) radioFetch(radioSeed);
    };
    window.hubMusic.__radio = true;
    setInterval(tickRadio, 5000);
  }

  var trail = [];

  function go(view, id, viaHistory) {
    if (browse) state.scroll = browse.scrollTop || 0;
    var same = state.view === view && String(state.id || "") === String(id || "");
    if (!viaHistory && !same) {
      trail.push({ view: state.view, id: state.id || "", scroll: state.scroll || 0 });
      if (trail.length > 40) trail.shift();
    }
    state.view = view;
    state.id = id || "";
    render();
  }

  function back() {
    var prev = trail.pop();
    if (!prev) {
      go("home", "", true);
      return;
    }
    go(prev.view, prev.id, true);
    state.scroll = prev.scroll || 0;
    if (browse) browse.scrollTop = prev.scroll || 0;
  }

  function spinner() {
    var box = el("div", "mx-loading");
    for (var i = 0; i < 3; i += 1) box.appendChild(el("span", "mx-dot"));
    return box;
  }

  function section(title, action) {
    var head = el("div", "mx-section-head");
    head.appendChild(el("h2", "mx-section-title", title));
    if (action) head.appendChild(action);
    return head;
  }

  function scroller() {
    return el("div", "mx-rail");
  }

  var artistIndex = {};

  function remember(track) {
    if (!track) return;
    var name = String(track.artist || "").trim().toLowerCase();
    var id = String(track.artistId || "").trim();
    if (name && id && !artistIndex[name]) artistIndex[name] = id;
  }

  function artistIdFor(name) {
    return artistIndex[String(name || "").trim().toLowerCase()] || "";
  }

  function artistLink(name, cls) {
    var label = name || "Unknown artist";
    var id = artistIdFor(label);
    var node;
    if (id) {
      node = el("button", (cls || "mx-row-artist") + " is-link", label);
      node.type = "button";
      node.addEventListener("click", function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        go("artist", id);
      });
    } else {
      node = el("span", cls || "mx-row-artist", label);
    }
    return node;
  }

  function backButton(onClick) {
    var btn = el("button", "mx-btn mx-btn-ghost mx-back");
    btn.type = "button";
    var svg = el("span", "mx-back-ico");
    svg.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>';
    btn.appendChild(svg);
    btn.appendChild(el("span", "", "Back"));
    btn.addEventListener("click", onClick);
    return btn;
  }

  var rowMenu = null;
  var rowMenuAnchor = null;

  function closeRowMenu() {
    if (rowMenu && rowMenu.parentNode) rowMenu.parentNode.removeChild(rowMenu);
    rowMenu = null;
    rowMenuAnchor = null;
    document.removeEventListener("click", onMenuDocClick, true);
    document.removeEventListener("keydown", onMenuKey, true);
  }

  function onMenuDocClick(ev) {
    if (rowMenu && !rowMenu.contains(ev.target)) closeRowMenu();
  }

  function onMenuKey(ev) {
    if (ev.key === "Escape") closeRowMenu();
  }

  function menuItem(label, hint, onPick, danger) {
    var btn = el("button", "mx-menu-item" + (danger ? " is-danger" : ""));
    btn.type = "button";
    btn.appendChild(el("span", "mx-menu-label", label));
    if (hint) btn.appendChild(el("span", "mx-menu-hint", hint));
    btn.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      onPick(ev);
    });
    return btn;
  }

  function openMenuAt(anchor, nodes) {
    closeRowMenu();
    rowMenu = el("div", "mx-menu");
    rowMenu.setAttribute("role", "menu");
    for (var i = 0; i < nodes.length; i += 1) rowMenu.appendChild(nodes[i]);
    document.body.appendChild(rowMenu);
    var rect;
    if (anchor && anchor.getBoundingClientRect) rect = anchor.getBoundingClientRect();
    else rect = { left: anchor.x, right: anchor.x, top: anchor.y, bottom: anchor.y };
    var width = rowMenu.offsetWidth;
    var height = rowMenu.offsetHeight;
    var point = !(anchor && anchor.getBoundingClientRect);
    var left;
    if (point) left = Math.max(8, Math.min(rect.left, window.innerWidth - width - 10));
    else left = Math.max(8, Math.min(rect.right - width, window.innerWidth - width - 10));
    var top = rect.bottom + 6;
    if (top + height > window.innerHeight - 10) top = Math.max(10, rect.top - height - 6);
    rowMenu.style.left = Math.round(left) + "px";
    rowMenu.style.top = Math.round(top) + "px";
    rowMenuAnchor = anchor;
    setTimeout(function () {
      document.addEventListener("click", onMenuDocClick, true);
      document.addEventListener("keydown", onMenuKey, true);
    }, 0);
  }

  function openAlbumFor(track) {
    closeRowMenu();
    var album = track.album;
    var realId = track.albumId || (album && /^[0-9]{2,}$/.test(String(album.id || "")) ? String(album.id) : "");
    if (realId) {
      go("album", realId);
      return;
    }
    var title = (album && album.title) || "";
    var artist = track.artist || "";
    if (!title) {
      searchFor((track.title || "") + " " + artist);
      return;
    }
    apiGet("/music/search/all?q=" + encodeURIComponent(title + " " + artist)).then(function (res) {
      var albums = ((res.data && res.data.albums) || []);
      var want = title.toLowerCase();
      var pick = null;
      for (var i = 0; i < albums.length; i += 1) {
        var t = String(albums[i].title || "").toLowerCase();
        if (t === want || t.indexOf(want) >= 0) {
          pick = albums[i];
          break;
        }
      }
      if (pick) go("album", String(pick.id));
      else searchFor(title + " " + artist);
    }).catch(function () {
      searchFor(title + " " + artist);
    });
  }

  function searchFor(term) {
    state.q = String(term || "").trim();
    state.scope = "all";
    state.view = "search";
    state.id = "";
    render();
  }

  function playlistPicker(track, anchor) {
    var signed = Boolean(token());
    if (!signed) {
      openMenuAt(anchor, [menuItem("Sign in to use playlists", "", function () { closeRowMenu(); })]);
      return;
    }
    loadPlaylists(true).then(function (list) {
      var nodes = [];
      if (!list.length) {
        nodes.push(menuItem("No playlists yet", "", function () { closeRowMenu(); }));
      }
      for (var i = 0; i < list.length; i += 1) {
        (function (pl) {
          nodes.push(menuItem(pl.name || "Playlist", (pl.count || (pl.tracks || []).length) + " tracks", function () {
            addToPlaylist(pl, track);
          }));
        })(list[i]);
      }
      nodes.push(menuItem("New playlist…", "", function () {
        closeRowMenu();
        var name = window.prompt("Playlist name", "My Playlist");
        if (name == null) return;
        name = String(name).trim();
        if (!name) return;
        apiPost("/music/playlist", {
          name: name,
          tracks: [trackOf(track)]
        }).then(function () {
          libraryCache.at = 0;
          refreshSidebar();
          flashNote("Added to " + name);
        }).catch(function () {});
      }));
      openMenuAt(anchor, nodes);
    });
  }

  function trackOf(track) {
    return {
      id: String(track.id),
      title: track.title || "Untitled",
      artist: track.artist || "Unknown artist",
      artistId: String(track.artistId || ""),
      cover: track.cover || "",
      duration: Number(track.duration) || 0,
      isrc: track.isrc || "",
      added: Number(track.added) || Date.now()
    };
  }

  function addToPlaylist(pl, track) {
    closeRowMenu();
    if (pl.kind === "liked") {
      toggleLike(track);
      return;
    }
    var tracks = (pl.tracks || []).slice();
    var id = String(track.id);
    for (var i = 0; i < tracks.length; i += 1) {
      if (String(tracks[i].id) === id) {
        flashNote("Already in " + pl.name);
        return;
      }
    }
    tracks.push(trackOf(track));
    apiPost("/music/playlist/" + encodeURIComponent(pl.id) + "/tracks", { tracks: tracks }).then(function () {
      libraryCache.at = 0;
      refreshSidebar();
      flashNote("Added to " + pl.name);
    }).catch(function (err) {
      flashNote(err.message || "Couldn't add that track");
    });
  }

  function removeFromPlaylist(pl, track, after) {
    closeRowMenu();
    var tracks = (pl.tracks || []).filter(function (t) {
      return String(t.id) !== String(track.id);
    });
    apiPost("/music/playlist/" + encodeURIComponent(pl.id) + "/tracks", { tracks: tracks }).then(function () {
      libraryCache.at = 0;
      refreshSidebar();
      flashNote("Removed from " + pl.name);
      if (after) after();
    }).catch(function (err) {
      flashNote(err.message || "Couldn't remove that track");
    });
  }

  function openRowMenu(track, list, index, opts, anchor) {
    opts = opts || {};
    var nodes = [];
    if (signedIn()) {
      var on = Boolean(liked[String(track.id)]);
      nodes.push(menuItem(on ? "Remove from Liked Songs" : "Add to Liked Songs", "", function () {
        closeRowMenu();
        toggleLike(track);
      }));
    }
    var artistId = String(track.artistId || "") || artistIdFor(track.artist);
    if (artistId) {
      nodes.push(menuItem("Go to artist", track.artist || "", function () {
        closeRowMenu();
        go("artist", artistId);
      }));
    }
    nodes.push(menuItem("Go to album", (track.album && track.album.title) || "", function () {
      openAlbumFor(track);
    }));
    if (opts.playlistPl) {
      nodes.push(menuItem("Remove from this playlist", "", function () {
        removeFromPlaylist(opts.playlistPl, track, opts.playlistAfter);
      }, true));
    } else {
      nodes.push(menuItem("Add to playlist", "", function () {
        playlistPicker(track, anchor);
      }));
    }
    nodes.push(menuItem("Find other versions", "", function () {
      closeRowMenu();
      searchFor((track.title || "") + " " + (track.artist || ""));
    }));
    openMenuAt(anchor, nodes);
  }

  function flashNote(text) {
    var note = document.getElementById("mxNote");
    if (!note) {
      note = el("div", "mx-flash");
      note.id = "mxNote";
      document.body.appendChild(note);
    }
    note.textContent = text;
    note.classList.add("is-on");
    clearTimeout(note.__t);
    note.__t = setTimeout(function () {
      if (note) note.classList.remove("is-on");
    }, 2200);
  }

  var HEART_PATH = "M12 20.6 3.6 12.2a4.95 4.95 0 0 1 7-7L12 6.6l1.4-1.4a4.95 4.95 0 1 1 7 7z";

  function heartIcon() {
    var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    var path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", HEART_PATH);
    svg.appendChild(path);
    return svg;
  }

  function likeLabel(on) {
    return on ? "Remove from Liked Songs" : "Add to Liked Songs";
  }

  function paintHearts(id, on) {
    var nodes = document.querySelectorAll('[data-like="' + id + '"]');
    for (var i = 0; i < nodes.length; i += 1) {
      nodes[i].classList.toggle("is-on", on);
      nodes[i].setAttribute("aria-pressed", on ? "true" : "false");
      nodes[i].setAttribute("title", likeLabel(on));
      nodes[i].setAttribute("aria-label", likeLabel(on));
    }
  }

  function heartButton(track, cls) {
    var on = Boolean(liked[String(track.id)]);
    var btn = el("button", "mx-heart" + (on ? " is-on" : "") + (cls ? " " + cls : ""));
    btn.type = "button";
    btn.setAttribute("data-like", String(track.id));
    btn.setAttribute("aria-pressed", on ? "true" : "false");
    btn.setAttribute("title", likeLabel(on));
    btn.setAttribute("aria-label", likeLabel(on));
    btn.appendChild(heartIcon());
    btn.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      toggleLike(track);
    });
    return btn;
  }

  function loadLikes() {
    if (!signedIn()) return Promise.resolve();
    return apiGet("/music/likes").then(function (res) {
      liked = {};
      var ids = (res && res.ids) || [];
      for (var i = 0; i < ids.length; i += 1) liked[String(ids[i])] = true;
      likedPlaylistId = String((res && res.playlistId) || "");
      var nodes = document.querySelectorAll("[data-like]");
      for (var j = 0; j < nodes.length; j += 1) {
        var key = nodes[j].getAttribute("data-like");
        paintHearts(key, Boolean(liked[key]));
      }
    }).catch(function () {});
  }

  function toggleLike(track) {
    if (!track || !track.id) return;
    if (!signedIn()) {
      flashNote("Sign in to like songs");
      return;
    }
    var id = String(track.id);
    var next = !liked[id];
    if (next) liked[id] = true;
    else delete liked[id];
    paintHearts(id, next);
    apiPost("/music/like", { track: trackOf(track) }).then(function (res) {
      if (res && res.playlistId) likedPlaylistId = String(res.playlistId);
      libraryCache.at = 0;
      refreshSidebar();
      flashNote(next ? "Added to Liked Songs" : "Removed from Liked Songs");
      if (state.view === "playlist" && String(state.id) === likedPlaylistId) render();
    }).catch(function () {
      if (next) delete liked[id];
      else liked[id] = true;
      paintHearts(id, !next);
      flashNote("Couldn't save that like");
    });
  }

  function syncBarHeart() {
    var btn = document.getElementById("mbarLike");
    if (!btn) return;
    var now = null;
    try {
      now = window.hubMusic && window.hubMusic.now ? window.hubMusic.now() : null;
    } catch (e) {
      now = null;
    }
    var show = Boolean(signedIn() && now && now.id);
    if (btn.hidden !== !show) btn.hidden = !show;
    if (show) {
      var on = Boolean(liked[String(now.id)]);
      btn.classList.toggle("is-on", on);
      btn.setAttribute("data-like", String(now.id));
      btn.setAttribute("title", likeLabel(on));
      btn.setAttribute("aria-label", likeLabel(on));
    }
  }

  function mountBarHeart() {
    var left = document.querySelector("#musicBar .mbar-left");
    if (!left) {
      setTimeout(mountBarHeart, 700);
      return;
    }
    var existing = document.getElementById("mbarLike");
    if (existing) {
      if (existing.parentNode !== left) left.appendChild(existing);
      return;
    }
    var btn = el("button", "mbar-heart mx-heart mbar-like");
    btn.id = "mbarLike";
    btn.type = "button";
    btn.hidden = true;
    btn.appendChild(heartIcon());
    btn.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      var now = null;
      try {
        now = window.hubMusic && window.hubMusic.now ? window.hubMusic.now() : null;
      } catch (e) {
        now = null;
      }
      if (!now || !now.id) {
        flashNote("Nothing playing");
        return;
      }
      toggleLike(now);
      setTimeout(syncBarHeart, 60);
    });
    left.appendChild(btn);
    syncBarHeart();
  }

  function trackRow(track, index, list, opts) {
    opts = opts || {};
    remember(track);
    var row = el("div", "mx-row");
    row.setAttribute("role", "button");
    row.tabIndex = 0;
    var marker = String(index + 1);
    var num = el("span", opts.rank ? "mx-row-rank" : "mx-row-num", marker);
    row.appendChild(num);
    var art = el("span", "mx-row-art");
    if (track.cover) {
      var img = el("img");
      img.src = picUrl(track.cover);
      img.alt = "";
      img.loading = "lazy";
      img.addEventListener("error", function () { art.removeChild(img); });
      art.appendChild(img);
    }
    row.appendChild(art);
    var main = el("span", "mx-row-main");
    main.appendChild(el("span", "mx-row-title", track.title || "Untitled"));
    var sub = el("span", "mx-row-sub");
    sub.appendChild(artistLink(track.artist));
    if (opts.showAlbum && track.album && typeof track.album === "string") {
      sub.appendChild(el("span", "mx-dotsep", "•"));
      sub.appendChild(el("span", "mx-row-album", track.album));
    }
    main.appendChild(sub);
    row.appendChild(main);
    if (track.playCount || track.plays) {
      row.appendChild(el("span", "mx-row-plays", fmt(track.playCount || track.plays)));
    }
    row.appendChild(el("span", "mx-row-time", track.allowStreaming === false ? "—" : fmtDur(track.duration)));
    var acts = el("span", "mx-row-acts");
    if (signedIn()) acts.appendChild(heartButton(track));
    var dots = el("button", "mx-row-dots");
    dots.type = "button";
    dots.title = "More options";
    dots.setAttribute("aria-label", "More options for " + (track.title || "track"));
    dots.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg>';
    dots.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      openRowMenu(track, list, index, opts, dots);
    });
    acts.appendChild(dots);
    row.appendChild(acts);
    if (track.allowStreaming === false) {
      row.classList.add("is-dead");
      sub.appendChild(el("span", "mx-row-dead", "unavailable · tap for other versions"));
    }
    row.addEventListener("click", function (ev) {
      if (ev.target.closest && ev.target.closest(".mx-row-dots")) return;
      if (ev.target.closest && ev.target.closest(".mx-heart")) return;
      if (ev.target.closest && ev.target.closest(".mx-row-artist")) return;
      if (track.allowStreaming === false) {
        searchFor((track.title || "") + " " + (track.artist || ""));
        return;
      }
      playList(list, index);
    });
    row.addEventListener("keydown", function (ev) {
      if (ev.key === "Enter" || ev.key === " ") {
        ev.preventDefault();
        playList(list, index);
      }
    });
    row.addEventListener("contextmenu", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      openRowMenu(track, list, index, opts, { x: ev.clientX, y: ev.clientY, getBoundingClientRect: null });
    });
    return row;
  }

  function trackList(list, opts) {
    opts = opts || {};
    var wrap = el("div", "mx-list");
    for (var i = 0; i < list.length; i += 1) {
      wrap.appendChild(trackRow(list[i], i, list, opts));
    }
    return wrap;
  }

  function artistCard(item) {
    var card = el("button", "mx-card mx-card-artist");
    card.type = "button";
    var art = el("span", "mx-card-art mx-card-art--round");
    if (item.avatar) {
      var img = el("img");
      var triedProxy = false;
      img.addEventListener("error", function () {
        if (!triedProxy && item.avatarProxy) {
          triedProxy = true;
          img.src = picUrl(item.avatarProxy);
          return;
        }
        img.remove();
        art.appendChild(el("span", "mx-card-initial", (item.name || "?").charAt(0).toUpperCase()));
      });
      img.src = picUrl(item.avatar);
      img.alt = "";
      img.loading = "lazy";
      art.appendChild(img);
    } else {
      art.appendChild(el("span", "mx-card-initial", (item.name || "?").charAt(0).toUpperCase()));
    }
    card.appendChild(art);
    card.appendChild(el("span", "mx-card-title", item.name || "Unknown artist"));
    var sub = item.followers ? fmt(item.followers) + " followers" : item.weekPlays ? fmt(item.weekPlays) + " plays this week" : "Artist";
    card.appendChild(el("span", "mx-card-sub", sub));
    card.addEventListener("click", function () { go("artist", String(item.id)); });
    return card;
  }

  function albumCard(item) {
    var card = el("button", "mx-card");
    card.type = "button";
    var art = el("span", "mx-card-art");
    if (item.cover) {
      var img = el("img");
      img.src = picUrl(item.cover);
      img.alt = "";
      img.loading = "lazy";
      art.appendChild(img);
    }
    card.appendChild(art);
    card.appendChild(el("span", "mx-card-title", item.title || "Untitled"));
    card.appendChild(el("span", "mx-card-sub", item.artist || (item.trackCount ? item.trackCount + " tracks" : "")));
    card.addEventListener("click", function () { go("album", String(item.id)); });
    return card;
  }

  function genreTiles() {
    var grid = el("div", "mx-tiles");
    for (var i = 0; i < GENRES.length; i += 1) {
      (function (g) {
        var tile = el("button", "mx-tile");
        tile.type = "button";
        tile.style.setProperty("--tile-hue", String(g.hue));
        tile.appendChild(el("span", "mx-tile-name", g.name));
        tile.addEventListener("click", function () { go("genre", g.q); });
        grid.appendChild(tile);
      })(GENRES[i]);
    }
    return grid;
  }

  function hero(track, list, index) {
    var box = el("div", "mx-hero");
    var bg = el("div", "mx-hero-bg");
    if (track.cover) bg.style.backgroundImage = "url('" + track.cover + "')";
    box.appendChild(bg);
    box.appendChild(el("div", "mx-hero-fade"));
    var art = el("div", "mx-hero-art");
    if (track.cover) {
      var img = el("img");
      img.src = picUrl(track.cover);
      img.alt = "";
      art.appendChild(img);
    }
    box.appendChild(art);
    var meta = el("div", "mx-hero-meta");
    meta.appendChild(el("span", "mx-eyebrow", "Featured today"));
    meta.appendChild(el("h1", "mx-hero-title", track.title || "Untitled"));
    var line = el("p", "mx-hero-sub", (track.artist || "Unknown artist") + (track.playCount ? "  •  " + fmt(track.playCount) + " plays" : ""));
    meta.appendChild(line);
    var play = el("button", "mx-btn mx-btn-primary", "Play");
    play.type = "button";
    play.addEventListener("click", function () { playList(list, index); });
    meta.appendChild(play);
    box.appendChild(meta);
    return box;
  }

  function viewHome() {
    var frag = document.createDocumentFragment();
    var body = el("div", "mx-view");
    frag.appendChild(body);
    body.appendChild(spinner());

    var feedReq = apiGet("/music/home").catch(function () { return { recent: [], top: [], artists: [] }; });
    var popReq = apiGet("/music/popular").catch(function () { return { data: { items: [] } }; });

    Promise.all([feedReq, popReq]).then(function (results) {
      clear(body);
      var feed = results[0] || {};
      var popular = ((results[1] || {}).data || {}).items || [];
      var recent = feed.recent || [];
      var top = feed.top || [];
      var artists = feed.artists || [];
      var signed = Boolean(token());

      if (popular.length) {
        body.appendChild(hero(popular[0], popular, 0));
      } else if (top.length) {
        body.appendChild(hero(top[0], top, 0));
      }

      var friendsSlot = null;
      if (signed) {
        friendsSlot = el("div", "mx-slot");
        body.appendChild(friendsSlot);
      }

      if (recent.length) {
        body.appendChild(section("Jump back in"));
        body.appendChild(trackList(recent, { showAlbum: true }));
      }

      if (top.length) {
        body.appendChild(section("Top on the hub this week"));
        body.appendChild(trackList(top, { rank: true }));
      }

      if (popular.length) {
        body.appendChild(section("Popular right now"));
        body.appendChild(trackList(popular.slice(0, 20), { rank: true }));
      }

      if (artists.length) {
        body.appendChild(section("Trending artists"));
        var rail = scroller();
        for (var a = 0; a < artists.length; a += 1) rail.appendChild(artistCard(artists[a]));
        body.appendChild(rail);
      }

      body.appendChild(section("Browse by genre"));
      body.appendChild(genreTiles());

      if (signed) {
        loadLibrary(true).then(function (lib) {
          var all = (lib.playlists || []).slice();
          var likedPl = null;
          var rest = [];
          for (var q = 0; q < all.length; q += 1) {
            if (all[q].kind === "liked") likedPl = all[q];
            else rest.push(all[q]);
          }
          var ordered = [];
          if (likedPl) ordered.push(likedPl);
          for (var r = 0; r < rest.length; r += 1) ordered.push(rest[r]);
          if (ordered.length) {
            var action = el("button", "mx-link", "Browse public");
            action.type = "button";
            action.addEventListener("click", function () { go("public"); });
            body.appendChild(section("Your playlists", action));
            var plRail = scroller();
            for (var p = 0; p < ordered.length; p += 1) plRail.appendChild(playlistCard(ordered[p]));
            body.appendChild(plRail);
          }
        });

        apiGet("/music/friends").then(function (res) {
          var friends = (res && res.friends) || [];
          if (!friendsSlot) return;
          friendsMount = friendsSlot;
          paintFriends(friendsSlot, friends);
        }).catch(function () {});
      }

      apiGet("/music/published").then(function (res) {
        var list = (res && res.playlists) || [];
        if (!list.length) return;
        var action = el("button", "mx-link", "See all");
        action.type = "button";
        action.addEventListener("click", function () { go("public"); });
        body.appendChild(section("Public playlists", action));
        var rail = scroller();
        for (var i = 0; i < list.length && i < 12; i += 1) rail.appendChild(playlistCard(list[i]));
        body.appendChild(rail);
      }).catch(function () {});

      if (!signed) {
        body.appendChild(el("p", "mx-note", "Sign in to like songs, build playlists and see your own listening history."));
      }
    });

    return frag;
  }

  function paintFriends(slot, friends) {
    if (!slot) return;
    if (!friends.length) {
      clear(slot);
      slot.hidden = true;
      return;
    }
    slot.hidden = false;
    clear(slot);
    var action = el("span", "mx-section-note", "Friends only");
    slot.appendChild(section("Friends are listening", action));
    var rail = scroller();
    rail.className += " mx-rail-friends";
    for (var f = 0; f < friends.length; f += 1) rail.appendChild(friendCard(friends[f]));
    slot.appendChild(rail);
  }

  function refreshFriends() {
    if (!friendsMount || !friendsMount.isConnected) return;
    var view = document.getElementById("musicView");
    if (!view || view.hasAttribute("hidden") || document.hidden) return;
    if (state.view !== "home") return;
    if (!signedIn()) return;
    apiGet("/music/friends").then(function (res) {
      if (!friendsMount || !friendsMount.isConnected || state.view !== "home") return;
      paintFriends(friendsMount, (res && res.friends) || []);
    }).catch(function () {});
  }

  function friendCard(friend) {
    var track = friend.track || {};
    var live = Number(friend.at) > 0 && Date.now() - Number(friend.at) < 5 * 60 * 1000;
    var card = el("button", "mx-friend-card" + (live ? " is-live" : ""));
    card.type = "button";
    card.title = "Play " + (track.title || "this track");

    var art = el("span", "mx-friend-art");
    if (track.cover) {
      var cover = el("img", "mx-friend-cover");
      cover.src = picUrl(track.cover);
      cover.alt = "";
      cover.loading = "lazy";
      art.appendChild(cover);
    } else {
      art.appendChild(el("span", "mx-friend-cover mx-friend-cover--empty", String(friend.username || "?").charAt(0).toUpperCase()));
    }
    var avatar = el("span", "mx-friend-avatar");
    if (friend.avatar) {
      var av = el("img");
      av.src = picUrl(friend.avatar);
      av.alt = "";
      av.loading = "lazy";
      av.addEventListener("error", function () {
        av.remove();
        avatar.textContent = String(friend.username || "?").charAt(0).toUpperCase();
      });
      avatar.appendChild(av);
    } else {
      avatar.textContent = String(friend.username || "?").charAt(0).toUpperCase();
    }
    art.appendChild(avatar);
    card.appendChild(art);

    var info = el("span", "mx-friend-info");
    var top = el("span", "mx-friend-top");
    top.appendChild(el("span", "mx-friend-name", friend.username || "Someone"));
    var eq = el("span", "mx-eq");
    for (var b = 0; b < 4; b += 1) eq.appendChild(el("i"));
    top.appendChild(eq);
    info.appendChild(top);
    info.appendChild(el("span", "mx-friend-track", track.title || "something"));
    var meta = el("span", "mx-friend-meta");
    if (track.artist) {
      meta.appendChild(el("span", "mx-friend-sub", track.artist));
      meta.appendChild(el("span", "mx-friend-dot"));
    }
    meta.appendChild(el("span", "mx-friend-when", ago(friend.at)));
    info.appendChild(meta);
    card.appendChild(info);

    card.addEventListener("click", function () {
      if (track.id) playList([track], 0);
    });
    return card;
  }

  function ago(ms) {
    var diff = Math.max(0, Date.now() - (Number(ms) || 0));
    var mins = Math.floor(diff / 60000);
    if (mins < 1) return "listening now";
    if (mins === 1) return "1 min ago";
    if (mins < 60) return mins + " mins ago";
    var hours = Math.floor(mins / 60);
    if (hours === 1) return "1 hour ago";
    if (hours < 24) return hours + " hours ago";
    var days = Math.floor(hours / 24);
    return days === 1 ? "yesterday" : days + " days ago";
  }

  function viewArtist(id) {
    var frag = document.createDocumentFragment();
    var body = el("div", "mx-view");
    frag.appendChild(body);
    body.appendChild(spinner());

    apiGet("/music/artist/" + encodeURIComponent(id)).then(function (res) {
      var data = (res && res.data) || {};
      var artist = data.artist || {};
      var tracks = data.tracks || [];
      clear(body);

      var header = el("div", "mx-artist-head");
      var banner = el("div", "mx-artist-banner");
      var bg = artist.avatar || (tracks[0] && tracks[0].cover) || "";
      if (bg) banner.style.backgroundImage = "url('" + bg + "')";
      header.appendChild(banner);
      var inner = el("div", "mx-artist-inner");
      var av = el("div", "mx-artist-avatar");
      var initialShown = false;
      var showInitial = function () {
        if (initialShown) return;
        initialShown = true;
        var stale = av.querySelector("img");
        if (stale) stale.remove();
        av.appendChild(el("span", "mx-card-initial", (artist.name || "?").charAt(0).toUpperCase()));
      };
      var sources = [artist.avatar, artist.avatarProxy, artist.avatarBackup].filter(function (u) { return !!u; });
      if (sources.length) {
        var img = el("img");
        img.alt = "";
        var step = 0;
        img.addEventListener("error", function () {
          step += 1;
          if (step < sources.length) {
            img.src = picUrl(sources[step]);
            if (bg) banner.style.backgroundImage = "url('" + sources[step] + "')";
            return;
          }
          showInitial();
        });
        img.src = picUrl(sources[0]);
        av.appendChild(img);
      } else {
        showInitial();
      }
      inner.appendChild(av);

      var meta = el("div", "mx-artist-meta");
      var nameRow = el("div", "mx-artist-name-row");
      nameRow.appendChild(el("h1", "mx-artist-name", artist.name || "Unknown artist"));
      if (artist.verified) nameRow.appendChild(el("span", "mx-verified", "Verified"));
      meta.appendChild(nameRow);
      var stats = el("div", "mx-artist-stats");
      if (artist.followers) stats.appendChild(el("span", "mx-stat", fmt(artist.followers) + " followers"));
      var totalPlays = 0;
      for (var i = 0; i < tracks.length; i += 1) totalPlays += Number(tracks[i].playCount) || 0;
      if (totalPlays) stats.appendChild(el("span", "mx-stat", fmt(totalPlays) + " plays"));
      if (tracks.length) stats.appendChild(el("span", "mx-stat", tracks.length + " tracks here"));
      meta.appendChild(stats);
      if (artist.description) meta.appendChild(el("p", "mx-artist-bio", artist.description));

      var actions = el("div", "mx-artist-actions");
      var playBtn = el("button", "mx-btn mx-btn-primary", "Play");
      playBtn.type = "button";
      playBtn.disabled = !tracks.length;
      playBtn.addEventListener("click", function () { if (tracks.length) playList(tracks, 0); });
      actions.appendChild(playBtn);
      var shuffle = el("button", "mx-btn", "Shuffle");
      shuffle.type = "button";
      shuffle.disabled = !tracks.length;
      shuffle.addEventListener("click", function () {
        if (!tracks.length) return;
        playList(tracks, Math.floor(Math.random() * tracks.length));
      });
      actions.appendChild(shuffle);
      actions.appendChild(backButton(back));
      meta.appendChild(actions);

      inner.appendChild(meta);
      header.appendChild(inner);
      body.appendChild(header);

      if (tracks.length) {
        body.appendChild(section("Popular"));
        body.appendChild(trackList(tracks.slice(0, 12), { rank: true }));
      }

      apiGet("/music/search/all?q=" + encodeURIComponent(artist.name || "")).then(function (r2) {
        var albums = ((r2.data && r2.data.albums) || []).filter(function (al) {
          return String(al.artist || "").toLowerCase() === String(artist.name || "").toLowerCase();
        }).slice(0, 10);
        if (!albums.length) return;
        body.appendChild(section("Albums & playlists"));
        var rail = scroller();
        for (var j = 0; j < albums.length; j += 1) rail.appendChild(albumCard(albums[j]));
        body.appendChild(rail);
      }).catch(function () {});

      if (tracks.length) {
        apiGet("/music/track/" + encodeURIComponent(tracks[0].id)).then(function (r3) {
          var related = (r3.data && r3.data.related) || [];
          var seen = {};
          seen[String(artist.id)] = true;
          var others = [];
          for (var k = 0; k < related.length; k += 1) {
            var id2 = String(related[k].artistId || "");
            if (!id2 || seen[id2]) continue;
            seen[id2] = true;
            others.push({ id: id2, name: related[k].artist, avatar: related[k].artistAvatar });
          }
          if (!others.length) return;
          body.appendChild(section("Fans also like"));
          var rail2 = scroller();
          for (var m = 0; m < others.length; m += 1) rail2.appendChild(artistCard(others[m]));
          body.appendChild(rail2);
        }).catch(function () {});
      }
    }).catch(function (err) {
      clear(body);
      body.appendChild(message("Couldn't load that artist", err && err.message));
    });

    return frag;
  }

  function viewAlbum(id) {
    var frag = document.createDocumentFragment();
    var body = el("div", "mx-view");
    frag.appendChild(body);
    body.appendChild(spinner());

    apiGet("/music/album/" + encodeURIComponent(id)).then(function (res) {
      var album = (res && res.data && res.data.album) || {};
      var tracks = album.tracks || [];
      clear(body);

      var head = el("div", "mx-album-head");
      var art = el("div", "mx-album-art");
      if (album.cover) {
        var img = el("img");
        img.src = picUrl(album.cover);
        img.alt = "";
        art.appendChild(img);
      }
      head.appendChild(art);
      var meta = el("div", "mx-album-meta");
      meta.appendChild(el("span", "mx-eyebrow", album.kind === "album" ? "Album" : "Playlist"));
      meta.appendChild(el("h1", "mx-album-title", album.title || "Untitled"));
      var by = el("button", "mx-album-artist", album.artist || "Unknown artist");
      by.type = "button";
      if (album.artistId) {
        by.addEventListener("click", function () { go("artist", String(album.artistId)); });
      }
      meta.appendChild(by);
      var line = el("div", "mx-album-line");
      line.appendChild(el("span", "mx-stat", tracks.length + " tracks"));
      if (album.duration) line.appendChild(el("span", "mx-stat", fmtDur(album.duration)));
      if (album.playableCount != null) line.appendChild(el("span", "mx-stat", album.playableCount + " playable"));
      meta.appendChild(line);
      var acts = el("div", "mx-artist-actions");
      var play = el("button", "mx-btn mx-btn-primary", "Play all");
      play.type = "button";
      play.disabled = !tracks.length;
      play.addEventListener("click", function () { if (tracks.length) playList(tracks, 0); });
      acts.appendChild(play);
      acts.appendChild(backButton(back));
      meta.appendChild(acts);
      head.appendChild(meta);
      body.appendChild(head);

      if (tracks.length) body.appendChild(trackList(tracks, { showAlbum: false }));
      else body.appendChild(el("p", "mx-note", "This one came back empty."));
    }).catch(function (err) {
      clear(body);
      body.appendChild(message("Couldn't load that album", err && err.message));
    });

    return frag;
  }

  function viewGenre(q) {
    var frag = document.createDocumentFragment();
    var body = el("div", "mx-view");
    frag.appendChild(body);
    body.appendChild(spinner());
    apiGet("/music/genre?genre=" + encodeURIComponent(q) + "&q=" + encodeURIComponent(q)).then(function (res) {
      var items = (res.data && res.data.items) || [];
      clear(body);
      var head = el("div", "mx-genre-head");
      head.appendChild(backButton(back));
      var title = el("div", "mx-genre-title-wrap");
      title.appendChild(el("span", "mx-eyebrow", "Genre"));
      title.appendChild(el("h1", "mx-view-title", q));
      title.appendChild(el("p", "mx-genre-sub", items.length ? items.length + " tracks · sorted by plays" : "Nothing here yet"));
      head.appendChild(title);
      body.appendChild(head);
      if (!items.length) {
        body.appendChild(message("Nothing in that genre yet", "Try a search instead."));
        return;
      }
      var acts = el("div", "mx-artist-actions");
      var play = el("button", "mx-btn mx-btn-primary", "Play all");
      play.type = "button";
      play.addEventListener("click", function () { playList(items, 0); });
      acts.appendChild(play);
      var shuffle = el("button", "mx-btn", "Shuffle");
      shuffle.type = "button";
      shuffle.addEventListener("click", function () { playList(items, Math.floor(Math.random() * items.length)); });
      acts.appendChild(shuffle);
      body.appendChild(acts);
      body.appendChild(trackList(items, { rank: true }));
    }).catch(function (err) {
      clear(body);
      body.appendChild(message("Couldn't load that genre", err && err.message));
    });
    return frag;
  }

  function viewSearch(q) {
    var frag = document.createDocumentFragment();
    var body = el("div", "mx-view");
    frag.appendChild(body);

    var tabs = el("div", "mx-tabs");
    var scopes = [["all", "All"], ["tracks", "Tracks"], ["artists", "Artists"], ["albums", "Albums"], ["playlists", "Playlists"]];
    for (var i = 0; i < scopes.length; i += 1) {
      (function (scope) {
        var tab = el("button", "mx-tab" + (state.scope === scope[0] ? " is-active" : ""), scope[1]);
        tab.type = "button";
        tab.addEventListener("click", function () {
          if (state.scope === scope[0]) return;
          state.scope = scope[0];
          render();
        });
        tabs.appendChild(tab);
      })(scopes[i]);
    }
    body.appendChild(tabs);

    var filters = el("div", "mx-pl-tools");
    var chips = el("div", "mx-chips");
    chips.appendChild(chip("Hide sped up & nightcore", state.clean, function () {
      state.clean = !state.clean;
      render();
    }));
    chips.appendChild(chip("Under 8 min", state.order === "short", function () {
      state.order = state.order === "short" ? "relevance" : "short";
      render();
    }));
    var orders = [["relevance", "Relevance"], ["plays", "Most played"], ["fresh", "Newest"]];
    for (var o = 0; o < orders.length; o += 1) {
      (function (pair) {
        chips.appendChild(chip(pair[1], state.order === pair[0], function () {
          if (state.order === pair[0]) return;
          state.order = pair[0];
          render();
        }));
      })(orders[o]);
    }
    filters.appendChild(chips);
    body.appendChild(filters);

    var results = el("div", "mx-search-results");
    body.appendChild(results);

    if (state.scope === "playlists") {
      results.appendChild(spinner());
      apiGet("/music/published?q=" + encodeURIComponent(q)).then(function (res) {
        var list = (res && res.playlists) || [];
        clear(results);
        if (!list.length) {
          results.appendChild(message("No public playlists for “" + q + "”", "Try the Browse tab to see everything people shared."));
          return;
        }
        var grid = el("div", "mx-grid");
        for (var i2 = 0; i2 < list.length; i2 += 1) grid.appendChild(publicCard(list[i2]));
        results.appendChild(grid);
      }).catch(function (err) {
        clear(results);
        results.appendChild(message("Search failed", err && err.message));
      });
      return frag;
    }

    results.appendChild(spinner());

    apiGet("/music/search/all?q=" + encodeURIComponent(q)).then(function (res) {
      var data = (res && res.data) || {};
      var tracks = data.tracks || [];
      var artists = data.artists || [];
      var albums = data.albums || [];
      clear(results);

      if (state.clean) tracks = tracks.filter(function (t) { return !junkTrack(t); });
      if (state.order === "short") {
        tracks = tracks.filter(function (t) { return Number(t.duration) > 0 && Number(t.duration) < 480; });
      }
      if (state.order === "plays") tracks = tracks.slice().sort(function (a, b) { return (b.playCount || 0) - (a.playCount || 0); });
      else if (state.order === "fresh") tracks = tracks.slice().sort(function (a, b) { return String(b.released || "").localeCompare(String(a.released || "")); });

      if (!tracks.length && !artists.length && !albums.length) {
        results.appendChild(message(
          "Nothing found for “" + q + "”",
          state.clean || state.order === "short" ? "Try turning the filters off." : "Try the artist name, or a shorter phrase."
        ));
        return;
      }

      if ((state.scope === "all" || state.scope === "tracks") && tracks.length) {
        if (state.scope === "all") results.appendChild(section("Tracks"));
        results.appendChild(trackList(tracks.slice(0, state.scope === "all" ? 8 : 40), { rank: state.scope !== "all" }));
      }
      if ((state.scope === "all" || state.scope === "artists") && artists.length) {
        results.appendChild(section("Artists"));
        var rail = scroller();
        for (var a = 0; a < artists.length; a += 1) rail.appendChild(artistCard(artists[a]));
        results.appendChild(rail);
      }
      if ((state.scope === "all" || state.scope === "albums") && albums.length) {
        results.appendChild(section("Albums & playlists"));
        var rail2 = scroller();
        for (var b = 0; b < albums.length; b += 1) rail2.appendChild(albumCard(albums[b]));
        results.appendChild(rail2);
      }
    }).catch(function (err) {
      clear(results);
      results.appendChild(message("Search failed", err && err.message));
    });

    return frag;
  }

  var plHost = null;

  function loadLibrary(force) {
    if (!signedIn()) return Promise.resolve({ playlists: [], shared: [], likedId: "" });
    if (!force && libraryCache.at && Date.now() - libraryCache.at < 15000) return Promise.resolve(libraryCache);
    return apiGet("/music/library").then(function (res) {
      libraryCache = {
        at: Date.now(),
        playlists: (res && res.playlists) || [],
        shared: (res && res.shared) || [],
        likedId: String((res && res.likedId) || "")
      };
      if (libraryCache.likedId) likedPlaylistId = libraryCache.likedId;
      return libraryCache;
    }).catch(function () {
      return libraryCache;
    });
  }

  function loadPlaylists(force) {
    return loadLibrary(force).then(function (lib) {
      return (lib.playlists || []).concat(lib.shared || []);
    });
  }

  function myId() {
    var t = token();
    if (!t) return "";
    var parts = t.split(".");
    if (parts.length < 2) return "";
    try {
      var raw = parts[1].replace(/-/g, "+").replace(/_/g, "/");
      var data = JSON.parse(atob(raw));
      return String((data && data.id) || "");
    } catch (e) {
      return "";
    }
  }

  function mosaic(tracks) {
    var box = el("span", "mx-mosaic");
    var covers = [];
    for (var i = 0; i < (tracks || []).length && covers.length < 4; i += 1) {
      if (tracks[i] && tracks[i].cover && covers.indexOf(tracks[i].cover) < 0) covers.push(tracks[i].cover);
    }
    for (var c = 0; c < 4; c += 1) {
      var cell = el("span", "mx-mosaic-cell");
      if (covers[c]) {
        var img = el("img");
        img.src = picUrl(covers[c]);
        img.alt = "";
        img.loading = "lazy";
        cell.appendChild(img);
      }
      box.appendChild(cell);
    }
    return box;
  }

  var PHOTO_PATH = "M4.2 5h15.6a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4.2a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z";
  var PHOTO_HILL = "M3 15.6l4.4-4.2a1.6 1.6 0 0 1 2.2 0l3 2.9 2.5-2.4a1.6 1.6 0 0 1 2.2 0L21 15.3";
  var PHOTO_SUN = "M15.7 8.4h.01";

  function playlistHue(pl) {
    var seed = String((pl && (pl.id || pl.name)) || "playlist");
    var hash = 0;
    for (var i = 0; i < seed.length; i += 1) {
      hash = (hash * 31 + seed.charCodeAt(i)) % 100000;
    }
    return hash % 360;
  }

  function playlistPlaceholder(pl) {
    var hue = playlistHue(pl);
    var box = el("span", "mx-art-empty mx-art-ph");
    box.style.background = "linear-gradient(150deg, hsl(" + hue + " 38% 30%), hsl(" + hue + " 42% 18%))";
    var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    svg.style.color = "hsl(" + hue + " 62% 74%)";
    [PHOTO_PATH, PHOTO_HILL, PHOTO_SUN].forEach(function (d) {
      var path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", d);
      path.setAttribute("fill", "none");
      path.setAttribute("stroke", "currentColor");
      path.setAttribute("stroke-width", "1.7");
      path.setAttribute("stroke-linecap", "round");
      path.setAttribute("stroke-linejoin", "round");
      svg.appendChild(path);
    });
    box.appendChild(svg);
    return box;
  }

  function isLikedPlaylist(pl) {
    if (!pl) return false;
    if (String(pl.kind || "") === "liked") return true;
    return Boolean(likedPlaylistId) && String(pl.id) === String(likedPlaylistId);
  }

  function artFace(pl) {
    if (isLikedPlaylist(pl)) {
      var heart = el("span", "mx-art-empty");
      heart.appendChild(heartIcon());
      return heart;
    }
    if (pl && (pl.coverFull || pl.cover)) {
      var single = el("span", "mx-art-single");
      var img = el("img");
      img.src = picUrl(pl.cover || pl.coverFull);
      img.alt = "";
      img.loading = "lazy";
      single.appendChild(img);
      return single;
    }
    var tracks = (pl && pl.tracks) || [];
    var hasCover = false;
    for (var i = 0; i < tracks.length; i += 1) {
      if (tracks[i] && tracks[i].cover) {
        hasCover = true;
        break;
      }
    }
    if (!hasCover) return playlistPlaceholder(pl);
    return mosaic(tracks);
  }

  function playlistCard(pl) {
    var card = el("button", "mx-card");
    card.type = "button";
    var art = el("span", "mx-card-art");
    art.appendChild(artFace(pl));
    if (pl.isPublic) art.appendChild(el("span", "mx-card-badge", "Public"));
    card.appendChild(art);
    card.appendChild(el("span", "mx-card-title", pl.name || "Playlist"));
    var count = pl.count || (pl.tracks || []).length || 0;
    var sub = count + (count === 1 ? " track" : " tracks");
    if (pl.ownerName && pl.role !== "owner") sub += " · " + pl.ownerName;
    card.appendChild(el("span", "mx-card-sub", sub));
    card.addEventListener("click", function () { go("playlist", String(pl.id)); });
    return card;
  }

  function currentPl() {
    return plHost && plHost.__pl ? plHost.__pl : null;
  }

  function refreshPlaylist(pl) {
    if (!plHost || !pl) return;
    plHost.__pl = pl;
    drawPlaylist(plHost, pl);
  }

  function saveMeta(pl, patch) {
    return apiPost("/music/playlist/" + encodeURIComponent(pl.id) + "/meta", patch).then(function (res) {
      libraryCache.at = 0;
      refreshSidebar();
      if (res && res.playlist) refreshPlaylist(res.playlist);
      return res;
    }).catch(function (err) {
      flashNote(err.message || "Couldn't save that");
      return null;
    });
  }

  function saveTracks(pl, tracks) {
    return apiPost("/music/playlist/" + encodeURIComponent(pl.id) + "/tracks", { tracks: tracks }).then(function (res) {
      libraryCache.at = 0;
      refreshSidebar();
      if (res && res.playlist) refreshPlaylist(res.playlist);
      return true;
    }).catch(function (err) {
      flashNote(err.message || "Couldn't save that");
      return false;
    });
  }

  function copyLink(pl) {
    closeRowMenu();
    var url = location.origin + location.pathname + "?music=next&pl=" + encodeURIComponent(pl.id);
    var done = function () { flashNote("Link copied"); };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(url).then(done).catch(function () { window.prompt("Copy this link", url); });
    } else {
      window.prompt("Copy this link", url);
    }
  }

  function pickCoverFile(pl) {
    var input = document.createElement("input");
    input.type = "file";
    input.accept = "image/png,image/jpeg,image/webp,image/gif";
    input.addEventListener("change", function () {
      var file = input.files && input.files[0];
      if (!file) return;
      if (file.size > 5 * 1024 * 1024) {
        flashNote("That image is over 5 MB");
        return;
      }
      var form = new FormData();
      form.append("cover", file);
      flashNote("Uploading cover…");
      apiUpload("/music/playlist/" + encodeURIComponent(pl.id) + "/cover", form).then(function (res) {
        libraryCache.at = 0;
        if (res && res.playlist) refreshPlaylist(res.playlist);
        flashNote("Cover updated");
      }).catch(function (err) {
        flashNote(err.message || "Couldn't upload that");
      });
    });
    input.click();
  }

  function coverFromTracks(pl) {
    var tracks = (pl.tracks || []).filter(function (t) { return t && t.cover; }).slice(0, 30);
    var nodes = [];
    if (!tracks.length) nodes.push(menuItem("No track art to use", "", function () { closeRowMenu(); }));
    for (var i = 0; i < tracks.length; i += 1) {
      (function (t) {
        nodes.push(menuItem(t.title || "Track", t.artist || "", function () {
          closeRowMenu();
          saveMeta(pl, { cover: t.cover }).then(function () { flashNote("Cover updated"); });
        }));
      })(tracks[i]);
    }
    openMenuAt(document.querySelector(".mx-pl-art") || document.body, nodes);
  }

  function coverMenu(pl, anchor) {
    var nodes = [];
    nodes.push(menuItem("Upload a photo", "JPG, PNG or WebP up to 5 MB", function () {
      closeRowMenu();
      pickCoverFile(pl);
    }));
    nodes.push(menuItem("Use a song's artwork", "", function () {
      closeRowMenu();
      coverFromTracks(pl);
    }));
    if (pl.cover) {
      nodes.push(menuItem("Reset cover", "Back to the artwork mosaic", function () {
        closeRowMenu();
        saveMeta(pl, { cover: "" }).then(function () { flashNote("Cover reset"); });
      }, true));
    }
    openMenuAt(anchor, nodes);
  }

  function inviteCollab(pl) {
    var who = window.prompt("Invite a collaborator (username)", "");
    if (who == null) return;
    who = String(who).trim().toLowerCase();
    if (!who) return;
    apiPost("/music/playlist/" + encodeURIComponent(pl.id) + "/collab", { username: who }).then(function (res) {
      if (res && res.playlist) refreshPlaylist(res.playlist);
      flashNote("Added " + (res && res.added ? res.added : who));
    }).catch(function (err) {
      flashNote(err.message || "Couldn't add them");
    });
  }

  function removeCollabUi(pl, userId, label) {
    apiPost("/music/playlist/" + encodeURIComponent(pl.id) + "/collab/" + encodeURIComponent(userId), {}, "DELETE").then(function (res) {
      if (res && res.playlist) refreshPlaylist(res.playlist);
      flashNote("Removed " + label);
    }).catch(function (err) {
      flashNote(err.message || "Couldn't remove them");
    });
  }

  function saveCopy(pl) {
    apiPost("/music/playlist/" + encodeURIComponent(pl.id) + "/copy", {}).then(function (res) {
      libraryCache.at = 0;
      refreshSidebar();
      loadLikeCopy();
      flashNote("Saved to your library");
      if (res && res.id) go("playlist", String(res.id));
    }).catch(function (err) {
      flashNote(err.message || "Couldn't save that");
    });
  }

  function loadLikeCopy() {
    loadLibrary(true);
  }

  function deletePlaylist(pl) {
    if (!window.confirm("Delete “" + (pl.name || "this playlist") + "”? This can't be undone.")) return;
    apiPost("/music/playlist/" + encodeURIComponent(pl.id), {}, "DELETE").then(function () {
      libraryCache.at = 0;
      refreshSidebar();
      flashNote("Playlist deleted");
      go("home");
    }).catch(function (err) {
      flashNote(err.message || "Couldn't delete it");
    });
  }

  function playlistMenu(pl, anchor) {
    var nodes = [];
    nodes.push(menuItem("Copy link", "", function () { copyLink(pl); }));
    if (pl.role === "owner") {
      nodes.push(menuItem("Rename", pl.name || "", function () {
        closeRowMenu();
        var name = window.prompt("Playlist name", pl.name || "");
        if (name == null) return;
        name = String(name).trim();
        if (!name) return;
        saveMeta(pl, { name: name }).then(function () { flashNote("Renamed"); });
      }));
      nodes.push(menuItem("Edit description", "", function () {
        closeRowMenu();
        var about = window.prompt("Describe this playlist", pl.about || "");
        if (about == null) return;
        saveMeta(pl, { about: String(about) }).then(function () { flashNote("Description saved"); });
      }));
      nodes.push(menuItem("Change cover", "", function () {
        closeRowMenu();
        coverMenu(pl, document.querySelector(".mx-pl-art") || anchor);
      }));
      if (pl.kind !== "liked") {
        nodes.push(menuItem(pl.isPublic ? "Make private" : "Make public", pl.isPublic ? "Only you can open it" : "Anyone can find and play it", function () {
          closeRowMenu();
          saveMeta(pl, { isPublic: !pl.isPublic }).then(function () {
            flashNote(pl.isPublic ? "Playlist is private" : "Playlist is public");
          });
        }));
        nodes.push(menuItem("Invite a collaborator", "", function () {
          closeRowMenu();
          inviteCollab(pl);
        }));
        var people = pl.collaborators || [];
        for (var i = 0; i < people.length; i += 1) {
          (function (person) {
            nodes.push(menuItem("Remove @" + (person.username || "user"), "collaborator", function () {
              closeRowMenu();
              removeCollabUi(pl, person.id, "@" + (person.username || "user"));
            }, true));
          })(people[i]);
        }
        if (!isLikedPlaylist(pl)) {
          nodes.push(menuItem("Delete playlist", "", function () {
            closeRowMenu();
            deletePlaylist(pl);
          }, true));
        }
      }
    } else if (pl.role === "collab") {
      nodes.push(menuItem("Leave playlist", "Give up your collaborator access", function () {
        closeRowMenu();
        removeCollabUi(pl, myId(), "you");
      }, true));
    }
    if (pl.role !== "owner" && signedIn()) {
      nodes.push(menuItem("Save a copy", "Add it to your own library", function () {
        closeRowMenu();
        saveCopy(pl);
      }));
    }
    openMenuAt(anchor, nodes);
  }

  var JUNK = /(sped up|spedup|speed up|slowed|nightcore|8d audio|8d|bass boost|bassboosted|reverb|chipmunk|pitch|daycore|slowedreverb)/i;

  function junkTrack(track) {
    var blob = String((track && track.title) || "") + " " + String((track && track.artist) || "");
    return JUNK.test(blob) || (Number(track && track.duration) > 0 && Number(track.duration) < 30);
  }

  function sortTracks(list, mode) {
    var copy = (list || []).slice();
    if (mode === "added") {
      copy.sort(function (a, b) {
        var fa = Number(a.added) || 0;
        var fb = Number(b.added) || 0;
        if (fa && fb) return fb - fa;
        if (fa && !fb) return -1;
        if (!fa && fb) return 1;
        return 0;
      });
    } else if (mode === "title") {
      copy.sort(function (a, b) { return String(a.title || "").localeCompare(String(b.title || "")); });
    } else if (mode === "artist") {
      copy.sort(function (a, b) {
        var byArtist = String(a.artist || "").localeCompare(String(b.artist || ""));
        return byArtist || String(a.title || "").localeCompare(String(b.title || ""));
      });
    } else if (mode === "length") {
      copy.sort(function (a, b) { return (Number(a.duration) || 0) - (Number(b.duration) || 0); });
    }
    return copy;
  }

  function chip(label, active, onClick) {
    var btn = el("button", "mx-chip" + (active ? " is-active" : ""));
    btn.type = "button";
    btn.textContent = label;
    btn.addEventListener("click", onClick);
    return btn;
  }

  function sortBar(pl, canDrag) {
    var bar = el("div", "mx-pl-tools");
    var chips = el("div", "mx-chips");
    var options = [["custom", "Custom"], ["added", "Recently added"], ["title", "Title A–Z"], ["artist", "Artist A–Z"], ["length", "Shortest first"]];
    for (var i = 0; i < options.length; i += 1) {
      (function (pair) {
        chips.appendChild(chip(pair[1], state.plSort === pair[0], function () {
          if (state.plSort === pair[0]) return;
          state.plSort = pair[0];
          refreshPlaylist(pl);
        }));
      })(options[i]);
    }
    bar.appendChild(chips);
    if (canDrag) bar.appendChild(el("span", "mx-pl-hint", "Drag a song to reorder"));
    return bar;
  }

  function enableDrag(wrap, tracks, onDone) {
    var from = -1;
    var rows = Array.prototype.slice.call(wrap.children);
    for (var i = 0; i < rows.length; i += 1) {
      (function (row, index) {
        row.draggable = true;
        row.addEventListener("dragstart", function (ev) {
          from = index;
          row.classList.add("is-dragging");
          try {
            ev.dataTransfer.effectAllowed = "move";
            ev.dataTransfer.setData("text/plain", String(index));
          } catch (e) {}
        });
        row.addEventListener("dragend", function () {
          row.classList.remove("is-dragging");
          var kids = wrap.children;
          for (var k = 0; k < kids.length; k += 1) kids[k].classList.remove("is-drop");
        });
        row.addEventListener("dragover", function (ev) {
          ev.preventDefault();
          try { ev.dataTransfer.dropEffect = "move"; } catch (e) {}
          row.classList.add("is-drop");
        });
        row.addEventListener("dragleave", function () { row.classList.remove("is-drop"); });
        row.addEventListener("drop", function (ev) {
          ev.preventDefault();
          row.classList.remove("is-drop");
          if (from < 0 || from === index) {
            from = -1;
            return;
          }
          var next = tracks.slice();
          var moved = next.splice(from, 1)[0];
          next.splice(index, 0, moved);
          from = -1;
          onDone(next);
        });
      })(rows[i], i);
    }
  }

  function viewPlaylist(id) {
    var frag = document.createDocumentFragment();
    var body = el("div", "mx-view");
    frag.appendChild(body);
    body.appendChild(spinner());
    plHost = body;

    apiGet("/music/playlist/" + encodeURIComponent(id)).then(function (res) {
      var pl = res && res.playlist;
      clear(body);
      if (!pl) {
        body.appendChild(message("Playlist not found", "It may be private or deleted."));
        return;
      }
      drawPlaylist(body, pl);
    }).catch(function (err) {
      clear(body);
      body.appendChild(message("Couldn't open that playlist", err && err.message));
    });

    return frag;
  }

  function drawPlaylist(body, pl) {
    plHost = body;
    body.__pl = pl;
    clear(body);
    var all = (pl.tracks || []).slice();
    var isLiked = pl.kind === "liked";
    var canDrag = pl.canEdit && !isLiked && state.plSort === "custom";
    var tracks = isLiked ? all : sortTracks(all, state.plSort);

    var head = el("div", "mx-album-head");
    var canEditArt = pl.canManage && !isLiked;
    var art = el("div", "mx-album-art mx-pl-art" + (canEditArt ? " is-editable" : ""));
    art.appendChild(artFace(pl.coverFull ? { id: pl.id, kind: pl.kind, cover: pl.coverFull } : pl));
    if (canEditArt) {
      art.setAttribute("role", "button");
      art.tabIndex = 0;
      art.setAttribute("title", "Change cover");
      art.addEventListener("click", function () { coverMenu(pl, art); });
      art.addEventListener("keydown", function (ev) {
        if (ev.key === "Enter" || ev.key === " ") {
          ev.preventDefault();
          coverMenu(pl, art);
        }
      });
    }
    head.appendChild(art);

    var meta = el("div", "mx-album-meta");
    meta.appendChild(el("span", "mx-eyebrow", isLiked ? "Liked songs" : pl.isPublic ? "Public playlist" : "Playlist"));
    var titleRow = el("div", "mx-title-row");
    titleRow.appendChild(el("h1", "mx-album-title", pl.name || "Playlist"));
    if (pl.isPublic) titleRow.appendChild(el("span", "mx-verified", "Public"));
    meta.appendChild(titleRow);

    var who = pl.role === "owner" ? "Your playlist" : "by " + (pl.ownerName || "someone");
    if (pl.collabCount) who += " · " + pl.collabCount + (pl.collabCount === 1 ? " collaborator" : " collaborators");
    meta.appendChild(el("p", "mx-album-sub", who));
    if (pl.about) meta.appendChild(el("p", "mx-pl-about", pl.about));

    var line = el("div", "mx-album-line");
    line.appendChild(el("span", "mx-stat", all.length + (all.length === 1 ? " track" : " tracks")));
    if (all.length) line.appendChild(el("span", "mx-stat", fmtDur(totalDur(all))));
    if (isLiked) line.appendChild(el("span", "mx-stat", "Only you can see this"));
    meta.appendChild(line);

    var acts = el("div", "mx-artist-actions");
    var play = el("button", "mx-btn mx-btn-primary", "Play all");
    play.type = "button";
    play.disabled = !tracks.length;
    play.addEventListener("click", function () { if (tracks.length) playList(tracks, 0); });
    acts.appendChild(play);
    var shuffle = el("button", "mx-btn", "Shuffle");
    shuffle.type = "button";
    shuffle.disabled = !tracks.length;
    shuffle.addEventListener("click", function () {
      if (tracks.length) playList(tracks, Math.floor(Math.random() * tracks.length));
    });
    acts.appendChild(shuffle);
    var more = el("button", "mx-btn mx-btn-ghost", "•••");
    more.type = "button";
    more.setAttribute("aria-label", "Playlist options");
    more.addEventListener("click", function () { playlistMenu(pl, more); });
    acts.appendChild(more);
    acts.appendChild(backButton(back));
    meta.appendChild(acts);
    head.appendChild(meta);
    body.appendChild(head);

    if ((pl.collaborators || []).length) {
      var people = el("div", "mx-collabs");
      people.appendChild(el("span", "mx-collabs-label", "Collaborators"));
      for (var c = 0; c < pl.collaborators.length; c += 1) {
        people.appendChild(el("span", "mx-collab", "@" + (pl.collaborators[c].username || "user")));
      }
      body.appendChild(people);
    }

    if (tracks.length) {
      body.appendChild(sortBar(pl, pl.canEdit && !isLiked));
      var wrap = trackList(tracks, {
        playlistPl: isLiked ? null : pl,
        playlistAfter: function () { go("playlist", String(pl.id)); },
        drag: canDrag
      });
      if (canDrag) {
        enableDrag(wrap, tracks, function (next) {
          flashNote("Saving order…");
          saveTracks(pl, next);
        });
      }
      body.appendChild(wrap);
    } else {
      body.appendChild(message(
        isLiked ? "No liked songs yet" : "This playlist is empty",
        isLiked ? "Tap the heart on any song and it lands here." : "Use the menu on any song to add it."
      ));
    }
  }

  function publicCard(pl) {
    var card = el("button", "mx-card");
    card.type = "button";
    var art = el("span", "mx-card-art");
    art.appendChild(artFace(pl));
    card.appendChild(art);
    card.appendChild(el("span", "mx-card-title", pl.name || "Playlist"));
    var count = pl.count || (pl.tracks || []).length || 0;
    card.appendChild(el("span", "mx-card-sub", count + (count === 1 ? " track" : " tracks") + " · " + (pl.ownerName || "someone")));
    card.addEventListener("click", function () { go("playlist", String(pl.id)); });
    return card;
  }

  function viewPublic() {
    var frag = document.createDocumentFragment();
    var body = el("div", "mx-view");
    frag.appendChild(body);
    body.appendChild(backButton(back));

    var head = el("div", "mx-page-head");
    head.appendChild(el("h1", "mx-page-title", "Public playlists"));
    head.appendChild(el("p", "mx-page-sub", "Playlists people on the hub have shared."));
    body.appendChild(head);

    var tools = el("div", "mx-pl-tools");
    var input = el("input", "mx-input");
    input.type = "search";
    input.placeholder = "Search playlists or people";
    input.value = state.pubQ || "";
    tools.appendChild(input);
    var sorts = el("div", "mx-chips");
    var order = [["new", "Recent"], ["tracks", "Most songs"], ["name", "A–Z"]];
    for (var s = 0; s < order.length; s += 1) {
      (function (pair) {
        sorts.appendChild(chip(pair[1], state.pubSort === pair[0], function () {
          if (state.pubSort === pair[0]) return;
          state.pubSort = pair[0];
          render();
        }));
      })(order[s]);
    }
    tools.appendChild(sorts);
    body.appendChild(tools);

    var grid = el("div", "mx-grid");
    body.appendChild(grid);
    grid.appendChild(spinner());

    var timer = null;
    function load() {
      clear(grid);
      grid.appendChild(spinner());
      apiGet("/music/published?q=" + encodeURIComponent(state.pubQ || "")).then(function (res) {
        var list = (res && res.playlists) || [];
        clear(grid);
        grid.className = "mx-grid";
        if (!list.length) {
          grid.className = "mx-grid is-empty";
          grid.appendChild(message(
            state.pubQ ? "No playlists match “" + state.pubQ + "”" : "No public playlists yet",
            state.pubQ ? "Try a shorter word." : "Open a playlist and set it to public to share it."
          ));
          return;
        }
        if (state.pubSort === "tracks") list.sort(function (a, b) { return (b.count || 0) - (a.count || 0); });
        else if (state.pubSort === "name") list.sort(function (a, b) { return String(a.name || "").localeCompare(String(b.name || "")); });
        for (var i = 0; i < list.length; i += 1) grid.appendChild(publicCard(list[i]));
      }).catch(function (err) {
        clear(grid);
        grid.appendChild(message("Couldn't load public playlists", err && err.message));
      });
    }
    input.addEventListener("input", function () {
      state.pubQ = input.value;
      clearTimeout(timer);
      timer = setTimeout(load, 280);
    });
    load();
    return frag;
  }

  function message(title, detail) {
    var box = el("div", "mx-message");
    box.appendChild(el("p", "mx-message-title", title));
    if (detail) box.appendChild(el("p", "mx-message-detail", detail));
    return box;
  }

  function clear(node) {
    if (!node) return;
    while (node.firstChild) node.removeChild(node.firstChild);
  }

  function render() {
    if (!root) return;
    root.scrollTop = 0;
    clear(root);
    var view;
    if (state.view === "artist") view = viewArtist(state.id);
    else if (state.view === "album") view = viewAlbum(state.id);
    else if (state.view === "playlist") view = viewPlaylist(state.id);
    else if (state.view === "genre") view = viewGenre(state.id);
    else if (state.view === "search") view = viewSearch(state.q);
    else if (state.view === "public") view = viewPublic();
    else view = viewHome();
    root.appendChild(view);
  }

  function onSubmit(ev) {
    ev.preventDefault();
    var input = document.getElementById("musicSearch");
    var term = input ? String(input.value || "").trim() : "";
    if (!term) {
      state.scope = "all";
      go("home");
      return;
    }
    state.q = term;
    state.scope = "all";
    state.view = "search";
    state.id = "";
    render();
  }

  var importHost = null;

  function importClose() {
    if (importHost && importHost.parentNode) importHost.parentNode.removeChild(importHost);
    importHost = null;
  }

  function importOpen() {
    if (!signedIn()) {
      if (window.hubChat && window.hubChat.account) window.hubChat.account();
      return;
    }
    importClose();
    var host = el("div", "mx-import");
    host.innerHTML =
      '<div class="mx-import-card" role="dialog" aria-modal="true" aria-labelledby="mxImportTitle">' +
        '<div class="mx-import-head">' +
          '<h2 id="mxImportTitle">Import a playlist</h2>' +
          '<button class="mx-import-x" type="button" aria-label="Close" data-import-close>&times;</button>' +
        "</div>" +
        '<div class="mx-import-tabs" role="tablist">' +
          '<button class="mx-import-tab is-on" type="button" role="tab" aria-selected="true" data-import-mode="link">Paste link</button>' +
          '<button class="mx-import-tab" type="button" role="tab" aria-selected="false" data-import-mode="file">Upload file</button>' +
        "</div>" +
        '<div class="mx-import-pane" data-import-pane="link">' +
          '<p class="mx-import-hint">Paste a Spotify, Apple Music or YouTube Music playlist link. A plain list of songs, one per line, works too.</p>' +
          '<textarea class="mx-import-input" id="mxImportUrl" rows="3" spellcheck="false" placeholder="https://open.spotify.com/playlist/..."></textarea>' +
          '<p class="mx-import-note">Link import only works with <strong>public</strong> playlists, and Spotify caps a link at 100 songs. For a private or longer one, export it with Exportify and upload the file.</p>' +
          '<div class="mx-import-actions">' +
            '<button class="mx-btn mx-btn-primary" type="button" data-import-go>Import</button>' +
            '<button class="mx-btn mx-btn-ghost" type="button" data-import-close>Cancel</button>' +
          "</div>" +
        "</div>" +
        '<div class="mx-import-pane" data-import-pane="file" hidden>' +
          '<p class="mx-import-hint">Export a playlist from Spotify or Apple Music, then upload the CSV here. Works with private playlists too.</p>' +
          '<p class="mx-import-note">Use <a href="https://exportify.app/" target="_blank" rel="noopener">exportify.app</a> — paste your playlist link, export as CSV, and drop the file below.</p>' +
          '<div class="mx-import-file-row">' +
            '<label class="mx-btn mx-btn-ghost mx-import-file-btn" for="mxImportFile">Choose CSV</label>' +
            '<input class="mx-import-file" id="mxImportFile" type="file" accept=".csv,.txt,text/csv,text/plain" hidden>' +
            '<span class="mx-import-file-name" id="mxImportFileName">No file chosen</span>' +
          "</div>" +
          '<div class="mx-import-actions">' +
            '<button class="mx-btn mx-btn-primary" type="button" data-import-file-go disabled>Import file</button>' +
            '<button class="mx-btn mx-btn-ghost" type="button" data-import-close>Cancel</button>' +
          "</div>" +
        "</div>" +
        '<p class="mx-import-status" id="mxImportStatus"></p>' +
        '<div class="mx-import-bar" id="mxImportBar"><i></i></div>' +
        '<p class="mx-import-meta" id="mxImportMeta"><span id="mxImportCurrent"></span><span id="mxImportEta"></span></p>' +
      "</div>";
    document.body.appendChild(host);
    importHost = host;

    var statusEl = host.querySelector("#mxImportStatus");
    var currentEl = host.querySelector("#mxImportCurrent");
    var etaEl = host.querySelector("#mxImportEta");
    var barEl = host.querySelector("#mxImportBar");
    var fillEl = barEl ? barEl.querySelector("i") : null;
    var inputEl = host.querySelector("#mxImportUrl");
    var goBtn = host.querySelector("[data-import-go]");
    var fileGoBtn = host.querySelector("[data-import-file-go]");
    var fileEl = host.querySelector("#mxImportFile");
    var fileNameEl = host.querySelector("#mxImportFileName");
    var tabs = host.querySelectorAll("[data-import-mode]");
    var panes = host.querySelectorAll("[data-import-pane]");

    function setMode(mode) {
      for (var i = 0; i < tabs.length; i += 1) {
        var on = tabs[i].getAttribute("data-import-mode") === mode;
        tabs[i].classList.toggle("is-on", on);
        tabs[i].setAttribute("aria-selected", on ? "true" : "false");
      }
      for (var j = 0; j < panes.length; j += 1) {
        panes[j].hidden = panes[j].getAttribute("data-import-pane") !== mode;
      }
    }

    for (var t = 0; t < tabs.length; t += 1) {
      (function (tab) {
        tab.addEventListener("click", function () {
          setMode(tab.getAttribute("data-import-mode"));
        });
      })(tabs[t]);
    }

    function parseCsv(text) {
      var rows = [];
      var row = [];
      var field = "";
      var quoted = false;
      for (var i = 0; i < text.length; i += 1) {
        var ch = text[i];
        if (quoted) {
          if (ch === '"') {
            if (text[i + 1] === '"') { field += '"'; i += 1; }
            else quoted = false;
          } else field += ch;
          continue;
        }
        if (ch === '"') { quoted = true; continue; }
        if (ch === ',') { row.push(field); field = ""; continue; }
        if (ch === '\n') { row.push(field); rows.push(row); row = []; field = ""; continue; }
        if (ch === '\r') continue;
        field += ch;
      }
      if (field.length || row.length) { row.push(field); rows.push(row); }
      return rows.filter(function (r) { return r.some(function (c) { return String(c || "").trim(); }); });
    }

    function tracksFromCsv(text) {
      var rows = parseCsv(text);
      if (!rows.length) return [];
      var header = rows[0].map(function (c) { return String(c || "").trim().toLowerCase(); });
      var titleAt = -1;
      var artistAt = -1;
      var durationAt = -1;
      for (var i = 0; i < header.length; i += 1) {
        var h = header[i];
        if (titleAt < 0 && /^(track name|title|name|song)$/.test(h)) titleAt = i;
        if (artistAt < 0 && /^(artist name\(s\)|artist name|artist|artists)$/.test(h)) artistAt = i;
        if (durationAt < 0 && /^(duration \(ms\)|duration_ms|duration)$/.test(h)) durationAt = i;
      }
      var out = [];
      if (titleAt < 0) {
        for (var r = 0; r < rows.length; r += 1) {
          var line = rows[r][0] || "";
          if (!line.trim()) continue;
          var bits = line.split(" - ");
          out.push({ title: bits[0].trim(), artist: (bits[1] || "").trim() });
        }
        return out;
      }
      for (var k = 1; k < rows.length; k += 1) {
        var cells = rows[k];
        var title = String(cells[titleAt] || "").trim();
        if (!title) continue;
        var artist = artistAt >= 0 ? String(cells[artistAt] || "").trim() : "";
        var durRaw = durationAt >= 0 ? Number(String(cells[durationAt] || "").replace(/[^0-9.]/g, "")) : 0;
        var dur = 0;
        if (durRaw > 10000) dur = Math.round(durRaw / 1000);
        else if (durRaw > 0) dur = Math.round(durRaw);
        out.push({ title: title, artist: artist, duration: dur });
      }
      return out;
    }

    if (fileEl) {
      fileEl.addEventListener("change", function () {
        var file = fileEl.files && fileEl.files[0];
        var name = file ? file.name : "";
        if (fileNameEl) fileNameEl.textContent = name || "No file chosen";
        if (fileGoBtn) fileGoBtn.disabled = !file;
      });
    }

    function say(text) {
      if (statusEl) statusEl.textContent = text || "";
    }

    var matchStartedAt = 0;

    function etaLabel(done, total) {
      if (!matchStartedAt || done < 3) return "";
      var elapsed = (Date.now() - matchStartedAt) / 1000;
      if (elapsed < 1.5) return "";
      var rate = done / elapsed;
      if (!rate) return "";
      var left = (total - done) / rate;
      if (!isFinite(left) || left <= 0) return "";
      if (left < 60) return "~" + Math.max(5, Math.round(left / 5) * 5) + "s left";
      var mins = Math.round(left / 60);
      return "~" + mins + " min left";
    }

    function progress(done, total) {
      if (!barEl || !fillEl) return;
      barEl.classList.add("is-on");
      fillEl.style.width = Math.max(3, Math.round((done / Math.max(1, total)) * 100)) + "%";
      say("Matching songs — " + done + " of " + total);
      if (etaEl) etaEl.textContent = etaLabel(done, total);
    }

    function looking(track) {
      if (!currentEl) return;
      if (!track) {
        currentEl.textContent = "";
        return;
      }
      var title = String(track.title || "").slice(0, 48);
      var artist = String(track.artist || "").slice(0, 32);
      currentEl.textContent = artist ? "Looking for " + title + " — " + artist : "Looking for " + title;
    }

    function matchAll(list) {
      var out = new Array(list.length);
      var chunks = [];
      for (var i = 0; i < list.length; i += 8) chunks.push({ at: i, items: list.slice(i, i + 8) });
      var cursor = 0;
      var done = 0;
      function worker() {
        if (cursor >= chunks.length) return Promise.resolve();
        var chunk = chunks[cursor];
        cursor += 1;
        looking(chunk.items[0]);
        return apiPost("/music/import/match", { tracks: chunk.items }).then(function (res) {
          var items = (res && res.items) || [];
          for (var k = 0; k < chunk.items.length; k += 1) out[chunk.at + k] = items[k] || null;
          done += chunk.items.length;
          progress(done, list.length);
          return worker();
        });
      }
      var workers = [worker(), worker()];
      return Promise.all(workers).then(function () { return out; });
    }

    function runFile() {
      var file = fileEl && fileEl.files && fileEl.files[0];
      if (!file) return;
      if (fileGoBtn) fileGoBtn.disabled = true;
      if (goBtn) goBtn.disabled = true;
      barEl.classList.remove("is-on");
      if (fillEl) fillEl.style.width = "0%";
      matchStartedAt = 0;
      looking(null);
      if (etaEl) etaEl.textContent = "";
      say("Reading file\u2026");
      var reader = new FileReader();
      reader.onload = function () {
        var tracks = [];
        try {
          tracks = tracksFromCsv(String(reader.result || ""));
        } catch (err) {
          tracks = [];
        }
        if (!tracks.length) {
          say("That file had no songs in it.");
          if (fileGoBtn) fileGoBtn.disabled = false;
          if (goBtn) goBtn.disabled = false;
          return;
        }
        apiPost("/music/import", { tracks: tracks, name: file.name.replace(/\.[a-z0-9]+$/i, "") })
          .then(finishImport)
          .catch(function (err) {
            barEl.classList.remove("is-on");
            say((err && err.message) || "Could not read that file.");
            if (fileGoBtn) fileGoBtn.disabled = false;
            if (goBtn) goBtn.disabled = false;
          });
      };
      reader.onerror = function () {
        say("Could not read that file.");
        if (fileGoBtn) fileGoBtn.disabled = false;
        if (goBtn) goBtn.disabled = false;
      };
      reader.readAsText(file);
    }

    function finishImport(res) {
      var list = (res && res.tracks) || [];
      if (!list.length) throw new Error("That playlist had no songs in it.");
      say("Found " + list.length + " songs — matching…");
      matchStartedAt = Date.now();
      return matchAll(list).then(function (items) {
        var tracks = [];
        var seen = {};
        for (var i = 0; i < items.length; i += 1) {
          var item = items[i];
          if (!item || !item.id || seen[item.id]) continue;
          seen[item.id] = 1;
          tracks.push(trackOf(item));
        }
        if (!tracks.length) throw new Error("None of those songs matched anything we can play.");
        say("Saving " + tracks.length + " songs…");
        return apiPost("/music/playlist", {
          name: String((res && res.name) || "Imported playlist").slice(0, 80),
          tracks: tracks
        }).then(function (made) {
          var id = made && made.playlist && made.playlist.id;
          importClose();
          libraryCache.at = 0;
          loadLibrary(true).then(function () {
            loadPlaylists(true);
            flashNote("Imported " + tracks.length + (tracks.length === 1 ? " song" : " songs"));
            if (id) go("playlist", String(id));
          });
        });
      });
    }

    function run() {
      var value = inputEl ? String(inputEl.value || "").trim() : "";
      if (!value) return;
      if (goBtn) goBtn.disabled = true;
      barEl.classList.remove("is-on");
      if (fillEl) fillEl.style.width = "0%";
      matchStartedAt = 0;
      looking(null);
      if (etaEl) etaEl.textContent = "";
      say("Reading playlist…");
      apiPost("/music/import", { url: value }).then(finishImport).catch(function (err) {
        if (goBtn) goBtn.disabled = false;
        barEl.classList.remove("is-on");
        say((err && err.message) || "That import did not work.");
      });
    }

    host.addEventListener("click", function (ev) {
      if (ev.target === host || ev.target.closest("[data-import-close]")) {
        importClose();
        return;
      }
      if (ev.target.closest("[data-import-go]")) run();
      if (ev.target.closest("[data-import-file-go]")) runFile();
    });
    host.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape") importClose();
      if (ev.key === "Enter" && (ev.metaKey || ev.ctrlKey)) run();
    });
    if (inputEl) {
      inputEl.addEventListener("keydown", function (ev) {
        if (ev.key === "Enter" && !ev.shiftKey) {
          ev.preventDefault();
          run();
        }
      });
      setTimeout(function () { inputEl.focus(); }, 40);
    }
  }

  function mount() {
    browse = document.getElementById("musicBrowse");
    if (!browse) {
      setTimeout(mount, 300);
      return;
    }
    document.body.classList.add("music-next");
    root = document.getElementById("mxRoot");
    if (!root) {
      root = el("div", "mx-root");
      root.id = "mxRoot";
      browse.insertBefore(root, browse.firstChild);
    }
    var homeBtn = document.getElementById("musicBrowseBtn");
    if (homeBtn && !homeBtn.__mxHome) {
      homeBtn.__mxHome = true;
      homeBtn.classList.add("has-icon");
      homeBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9.5 21v-6h5v6"/></svg><span>Home</span>';
    }
    document.addEventListener("click", function (ev) {
      var t = ev.target;
      if (!t || !t.closest) return;
      if (!t.closest("#musicBrowseBtn")) return;
      ev.preventDefault();
      ev.stopPropagation();
      go("home");
    }, true);

    window.addEventListener("mx:artist", function (ev) {
      var name = ev && ev.detail && ev.detail.name ? String(ev.detail.name) : "";
      if (!name) return;
      var view = document.getElementById("musicView");
      if (view && view.hasAttribute("hidden")) {
        var nav = document.getElementById("navMusic");
        if (nav) nav.click();
      }
      var id = artistIdFor(name);
      if (id) go("artist", id);
      else searchFor(name);
    });

    var form = document.getElementById("musicSearchForm");
    if (form && !form.__mx) {
      var clone = form.cloneNode(true);
      clone.__mx = true;
      form.parentNode.replaceChild(clone, form);
      clone.addEventListener("submit", onSubmit);
    }
    var input = document.getElementById("musicSearch");
    if (input && !input.__mx) {
      input.__mx = true;
      input.addEventListener("search", function () {
        if (!String(input.value || "").trim()) { state.scope = "all"; go("home"); }
      });
    }
    hookPlayer();
    setTimeout(hookPlayer, 1200);

    document.addEventListener("click", function (ev) {
      var t = ev.target;
      if (!t || !t.closest) return;
      var row = t.closest("#musicPlaylists > *");
      if (!row) return;
      ev.preventDefault();
      ev.stopPropagation();
      var id = row.dataset ? row.dataset.plId : "";
      if (!id) {
        reconcileLibrary();
        return;
      }
      go("playlist", id);
    }, true);

    var addBtn = document.getElementById("musicNewPlaylist");
    if (addBtn) {
      addBtn.addEventListener("click", function () {
        setTimeout(function () { reconcileLibrary(); }, 1400);
      });
    }

    var importBtn = document.getElementById("musicImport");
    if (importBtn) importBtn.addEventListener("click", importOpen);

    loadLikes().then(function () {
      var deep = "";
      try {
        deep = new URLSearchParams(location.search).get("pl") || "";
      } catch (e) {
        deep = "";
      }
      if (deep) go("playlist", deep);
      else render();
    });

    decorateSidebarSoon();
    startLiveSync();
    mountBarHeart();
    setTimeout(syncBarHeart, 900);
    var barNode = document.getElementById("musicBar");
    if (barNode && !barNode.__mxHeart) {
      barNode.__mxHeart = true;
      var barObs = new MutationObserver(function () { syncBarHeart(); });
      barObs.observe(barNode, { attributes: true, attributeFilter: ["hidden"], childList: true, subtree: true, characterData: true });
    }
  }

  function decorateSidebarSoon() {
    var wrap = document.getElementById("musicPlaylists");
    if (!wrap) {
      setTimeout(decorateSidebarSoon, 500);
      return;
    }
    decorateSidebar(true);
    if (wrap.__mxWatch) return;
    wrap.__mxWatch = true;
    var obs = new MutationObserver(function () { decorateSidebar(true); });
    obs.observe(wrap, { childList: true });
  }

  function decorateSidebar(force) {
    if (sidebarWriting) return;
    if (!document.getElementById("musicPlaylists")) return;
    if (!signedIn()) {
      sidebarSig = "";
      return;
    }
    loadLibrary(force).then(function (lib) {
      renderSidebar(lib);
    });
  }

  function refreshSidebar() {
    if (!signedIn()) return;
    libraryCache.at = 0;
    loadLibrary(true).then(function (lib) { renderSidebar(lib); });
  }

  function sidebarRow(pl) {
    var b = el("button", "mpl");
    b.type = "button";
    b.setAttribute("role", "listitem");
    b.dataset.plId = String(pl.id);
    b.setAttribute("aria-label", "Open playlist " + (pl.name || ""));
    if (state.view === "playlist" && String(state.id) === String(pl.id)) b.className += " is-active";
    var art = el("span", "mpl-art");
    art.appendChild(artFace(pl));
    b.appendChild(art);
    var col = el("span", "mpl-col");
    col.appendChild(el("span", "mpl-name", pl.name || "Playlist"));
    var count = Number(pl.count != null ? pl.count : (pl.tracks || []).length) || 0;
    col.appendChild(el("span", "mpl-count", count + (count === 1 ? " song" : " songs")));
    b.appendChild(col);
    return b;
  }

  function renderSidebar(lib) {
    var wrap = document.getElementById("musicPlaylists");
    if (!wrap) return;
    var list = (lib.playlists || []).concat(lib.shared || []);
    var sig = list.map(function (p) {
      return p.id + "\u0001" + (p.name || "") + "\u0001" + (p.count || 0);
    }).join("\u0002");
    if (state.view === "playlist") sig += "\u0003" + state.id;
    if (sig === sidebarSig) return;
    sidebarSig = sig;
    sidebarWriting = true;
    clear(wrap);
    for (var i = 0; i < list.length; i += 1) wrap.appendChild(sidebarRow(list[i]));
    setTimeout(function () { sidebarWriting = false; }, 0);
  }

  function dropIfGone() {
    if (state.view !== "playlist" || !state.id) return Promise.resolve(false);
    var id = state.id;
    return apiGet("/music/playlist/" + encodeURIComponent(id)).then(function (res) {
      if (res && res.playlist) return false;
      if (state.view === "playlist" && String(state.id) === String(id)) {
        flashNote("That playlist is no longer available");
        go("home");
      }
      return true;
    }).catch(function () {
      return false;
    });
  }

  function reconcileLibrary() {
    if (!signedIn()) return Promise.resolve(null);
    libraryCache.at = 0;
    return loadLibrary(true).then(function (lib) {
      renderSidebar(lib);
      dropIfGone();
      return lib;
    });
  }

  function startLiveSync() {
    if (window.__mxLiveSync) return;
    window.__mxLiveSync = true;
    setInterval(function () {
      var view = document.getElementById("musicView");
      if (!view || view.hasAttribute("hidden") || document.hidden) return;
      if (!signedIn()) return;
      loadLibrary(true).then(function (lib) {
        renderSidebar(lib);
        dropIfGone();
      });
      refreshFriends();
    }, 12000);
    document.addEventListener("visibilitychange", function () {
      if (!document.hidden) { libraryCache.at = 0; refreshFriends(); }
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();
})();