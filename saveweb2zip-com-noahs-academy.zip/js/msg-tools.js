(function () {
  "use strict";

  var TOKEN_KEY = "hub_token";
  var ACT = "/api/chat/mod/act";
  var PERMS_OFF = { kick: false, ban: false, editServer: false, timeout: false };
  var MUTES = [
    { label: "1 minute", seconds: 60 },
    { label: "5 minutes", seconds: 300 },
    { label: "10 minutes", seconds: 600 },
    { label: "1 hour", seconds: 3600 },
    { label: "1 day", seconds: 86400 },
    { label: "1 week", seconds: 604800 }
  ];

  var me = { id: "", siteRole: "" };
  var servers = null;
  var channelServer = {};
  var byChannel = {};
  var activeChannel = "";
  var memberCache = {};
  var deleted = {};
  var menu = null;
  var menuAnchor = null;
  var busy = false;
  var toastNode = null;
  var toastTimer = null;
  var scheduled = false;

  function token() {
    try {
      return localStorage.getItem(TOKEN_KEY) || "";
    } catch (err) {
      return "";
    }
  }

  function noop() {}

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = text;
    return node;
  }

  function norm(value) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  }

  function param(query, key) {
    var parts = String(query || "").split("&");
    for (var i = 0; i < parts.length; i += 1) {
      var at = parts[i].indexOf("=");
      var name = at < 0 ? parts[i] : parts[i].slice(0, at);
      if (decodeURIComponent(name) !== key) continue;
      return decodeURIComponent(at < 0 ? "" : parts[i].slice(at + 1).replace(/\+/g, " "));
    }
    return "";
  }

  function api(path, body) {
    var headers = { Authorization: token() };
    var opts = { method: body ? "POST" : "GET", headers: headers };
    if (body) {
      headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
    return fetch(path, opts).then(function (res) {
      return res
        .json()
        .catch(function () {
          return {};
        })
        .then(function (data) {
          if (res.ok) return data;
          var err = new Error((data && data.message) || "Request failed.");
          err.data = data;
          throw err;
        });
    });
  }

  function findServer(serverId) {
    if (!servers || !serverId) return null;
    for (var i = 0; i < servers.length; i += 1) {
      if (servers[i] && servers[i].id === serverId) return servers[i];
    }
    return null;
  }

  function storeServers(data) {
    var list = data && Array.isArray(data.servers) ? data.servers : null;
    if (!list) return;
    servers = list;
    var map = {};
    for (var i = 0; i < list.length; i += 1) {
      var srv = list[i] || {};
      var channels = Array.isArray(srv.channels) ? srv.channels : [];
      for (var j = 0; j < channels.length; j += 1) {
        if (channels[j] && channels[j].id) map[channels[j].id] = srv.id;
      }
    }
    channelServer = map;
    for (var key in memberCache) {
      if (memberCache.hasOwnProperty(key) && memberCache[key]) memberCache[key].at = 0;
    }
  }

  function computePerms(serverId, member) {
    var out = { kick: false, ban: false, editServer: false, timeout: false };
    var srv = findServer(serverId);
    if (!srv || !member) return out;
    var ids = Array.isArray(member.roleIds) ? member.roleIds.slice() : [];
    if (member.roleId && ids.indexOf(member.roleId) < 0) ids.push(member.roleId);
    var roles = Array.isArray(srv.roles) ? srv.roles : [];
    for (var i = 0; i < ids.length; i += 1) {
      for (var j = 0; j < roles.length; j += 1) {
        if (!roles[j] || roles[j].id !== ids[i]) continue;
        var perms = roles[j].perms || {};
        if (perms.kick) out.kick = true;
        if (perms.ban) out.ban = true;
        if (perms.editServer) out.editServer = true;
        if (perms.timeout) out.timeout = true;
      }
    }
    return out;
  }

  function storeMembers(serverId, data) {
    if (!serverId) return;
    var list = data && Array.isArray(data.members) ? data.members : [];
    var byId = {};
    var byName = {};
    var mine = null;
    for (var i = 0; i < list.length; i += 1) {
      var member = list[i] || {};
      if (member.user) byId[member.user] = member;
      if (member.username) byName[String(member.username).toLowerCase()] = member;
      if (me.id && member.user === me.id) mine = member;
    }
    var owner = !!(mine && mine.role === "owner");
    memberCache[serverId] = {
      at: Date.now(),
      byId: byId,
      byName: byName,
      mine: mine,
      owner: owner,
      perms: owner ? { kick: true, ban: true, editServer: true, timeout: true } : computePerms(serverId, mine)
    };
    schedule();
  }

  function ensureMembers(serverId) {
    if (!serverId) return Promise.resolve(null);
    var hit = memberCache[serverId];
    if (hit && Date.now() - hit.at < 20000) return Promise.resolve(hit);
    return api("/api/chat/members?serverId=" + encodeURIComponent(serverId))
      .then(function (data) {
        storeMembers(serverId, data);
        return memberCache[serverId] || null;
      })
      .catch(function () {
        return null;
      });
  }

  function ensureServers() {
    if (servers) return Promise.resolve(servers);
    return api("/api/chat/servers")
      .then(function (data) {
        storeServers(data);
        return servers;
      })
      .catch(function () {
        return null;
      });
  }

  function mergeMessages(channelId, list, fresh) {
    if (!channelId || !Array.isArray(list)) return;
    if (fresh || !byChannel[channelId]) {
      byChannel[channelId] = list.slice();
      return;
    }
    var known = {};
    var current = byChannel[channelId];
    for (var i = 0; i < current.length; i += 1) {
      if (current[i] && current[i].id) known[current[i].id] = true;
    }
    for (var j = 0; j < list.length; j += 1) {
      var msg = list[j];
      if (!msg || !msg.id || known[msg.id]) continue;
      known[msg.id] = true;
      current.push(msg);
    }
  }

  function observe(url, res) {
    if (!res || !res.ok) return;
    var q = url.indexOf("?");
    var path = q < 0 ? url : url.slice(0, q);
    var query = q < 0 ? "" : url.slice(q + 1);
    if (path === "/api/chat/session") {
      res.clone().json().then(function (data) {
        if (!data) return;
        me.id = (data.user && data.user.id) || me.id;
        me.siteRole = data.siteRole || "";
        schedule();
      }).catch(noop);
      return;
    }
    if (path === "/api/chat/servers") {
      res.clone().json().then(storeServers).catch(noop);
      return;
    }
    if (path === "/api/chat/members") {
      var serverId = param(query, "serverId");
      res.clone().json().then(function (data) {
        storeMembers(serverId, data);
      }).catch(noop);
      return;
    }
    if (path === "/api/chat/messages") {
      var channelId = param(query, "channelId");
      var fresh = query.indexOf("since=") < 0;
      res.clone().json().then(function (data) {
        mergeMessages(channelId, data && data.messages, fresh);
        schedule();
        var sid = channelServer[activeChannel];
        if (sid && !memberCache[sid]) ensureMembers(sid);
      }).catch(noop);
      return;
    }
    if (path === "/api/chat/message/send" || path === "/api/chat/message/edit" || path === "/api/chat/message/upload") {
      res.clone().json().then(function (data) {
        var msg = data && data.message;
        if (!msg || !msg.id || !activeChannel) return;
        var list = byChannel[activeChannel] || (byChannel[activeChannel] = []);
        for (var i = 0; i < list.length; i += 1) {
          if (list[i] && list[i].id === msg.id) {
            list[i] = msg;
            return;
          }
        }
        list.push(msg);
      }).catch(noop);
    }
  }

  function wrapFetch() {
    if (!window.fetch || window.fetch.__msgTools) return;
    var real = window.fetch;
    var wrapped = function (input) {
      var url = "";
      try {
        url = typeof input === "string" ? input : input && input.url ? input.url : String(input);
      } catch (err) {
        url = "";
      }
      if (url.indexOf("/api/chat/messages?") === 0) {
        var id = param(url.slice(url.indexOf("?") + 1), "channelId");
        if (id) activeChannel = id;
      }
      var promise = real.apply(this, arguments);
      if (url && url.indexOf("/api/chat/") !== -1) {
        promise.then(function (res) {
          observe(url, res);
        }, noop);
      }
      return promise;
    };
    wrapped.__msgTools = true;
    window.fetch = wrapped;
  }

  function rowText(row) {
    var text = row.querySelector(".msg-text");
    if (!text) return "";
    var out = "";
    for (var i = 0; i < text.childNodes.length; i += 1) {
      var node = text.childNodes[i];
      if (node.nodeType === 3) {
        out += node.nodeValue;
      } else if (node.nodeType === 1 && !node.classList.contains("msg-edited") && !node.classList.contains("msg-attach")) {
        out += node.textContent;
      }
    }
    return norm(out);
  }

  function mapRows(channelId, rows) {
    var list = byChannel[channelId] || [];
    var out = new Array(rows.length);
    if (!list.length || !rows.length) return out;
    if (list.length === rows.length) {
      for (var i = 0; i < rows.length; i += 1) out[i] = list[i];
      return out;
    }
    var cursor = 0;
    for (var r = 0; r < rows.length; r += 1) {
      var text = rowText(rows[r]);
      if (!text) continue;
      for (var m = cursor; m < list.length; m += 1) {
        if (norm(list[m] && list[m].content) !== text) continue;
        out[r] = list[m];
        cursor = m + 1;
        break;
      }
    }
    return out;
  }

  function authorOf(rows, index) {
    for (var i = index; i >= 0; i -= 1) {
      var node = rows[i].querySelector(".msg-author");
      if (node) return norm(node.textContent);
      if (!rows[i].classList.contains("is-grouped")) return "";
    }
    return "";
  }

  function rowsOf(row) {
    var list = row && row.parentNode;
    if (!list) return null;
    return list.querySelectorAll(".msg");
  }

  function resolve(row) {
    var rows = rowsOf(row);
    if (!rows) return null;
    var index = -1;
    for (var i = 0; i < rows.length; i += 1) {
      if (rows[i] === row) {
        index = i;
        break;
      }
    }
    if (index < 0) return null;
    var map = mapRows(activeChannel, rows);
    return {
      row: row,
      message: map[index] || null,
      isMe: row.classList.contains("is-me"),
      username: authorOf(rows, index),
      channel: activeChannel
    };
  }

  function context(info) {
    var staff = me.siteRole === "admin";
    var serverId = channelServer[info.channel] || "";
    var cache = serverId ? memberCache[serverId] : null;
    var perms = cache ? cache.perms : PERMS_OFF;
    if (staff) perms = { kick: true, ban: true, editServer: true, timeout: true };
    var target = cache && info.username ? cache.byName[String(info.username).toLowerCase()] || null : null;
    var muted = false;
    if (target && target.timeoutUntil) {
      var until = Date.parse(String(target.timeoutUntil).replace(" ", "T"));
      muted = !isNaN(until) && until > Date.now();
    }
    return {
      serverId: serverId,
      staff: staff,
      perms: perms,
      target: target,
      muted: muted,
      ready: !!cache
    };
  }

  function powerFor(channel) {
    if (me.siteRole === "admin") return true;
    var serverId = channelServer[channel] || "";
    var cache = serverId ? memberCache[serverId] : null;
    if (!cache) return true;
    var perms = cache.perms || PERMS_OFF;
    return !!(perms.ban || perms.kick || perms.timeout || perms.editServer);
  }

  function markDeleted(id) {
    if (!id) return;
    deleted[id] = true;
  }

  function schedule() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(function () {
      scheduled = false;
      sync();
    }, 60);
  }

  function sync() {
    var list = document.getElementById("messageList");
    if (!list) return;
    var rows = list.querySelectorAll(".msg");
    if (!rows.length) return;
    var map = mapRows(activeChannel, rows);
    for (var i = 0; i < rows.length; i += 1) {
      var row = rows[i];
      var msg = map[i];
      if (msg && msg.id && deleted[msg.id]) {
        row.style.display = "none";
        continue;
      }
      if (row.classList.contains("msg-system")) continue;
      var own = row.classList.contains("is-me");
      if (!own && !powerFor(activeChannel)) {
        var stale = row.querySelector(".msg-tools-btn");
        if (stale) stale.parentNode.removeChild(stale);
        continue;
      }
      if (row.querySelector(".msg-tools-btn")) continue;
      var actions = row.querySelector(".msg-actions");
      if (!actions) {
        actions = el("div", "msg-actions");
        row.appendChild(actions);
      }
      actions.appendChild(makeButton());
    }
  }

  function makeButton() {
    var button = el("button", "msg-action-btn msg-tools-btn", "\u22EF");
    button.type = "button";
    button.title = "More";
    button.setAttribute("aria-label", "More actions");
    button.setAttribute("aria-haspopup", "menu");
    button.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      var row = button.closest(".msg");
      if (row) openMenu(button, row);
    });
    return button;
  }

  function menuNode() {
    if (menu) return menu;
    menu = el("div", "msg-tools-menu");
    menu.setAttribute("role", "menu");
    menu.hidden = true;
    document.body.appendChild(menu);
    return menu;
  }

  function closeMenu() {
    if (menu) menu.hidden = true;
  }

  function place(anchor) {
    var node = menuNode();
    node.style.visibility = "hidden";
    node.hidden = false;
    var box = anchor.getBoundingClientRect();
    var width = node.offsetWidth;
    var height = node.offsetHeight;
    var left = Math.max(8, Math.min(box.right - width, window.innerWidth - width - 8));
    var top = box.bottom + 6;
    if (top + height > window.innerHeight - 8) top = Math.max(8, box.top - height - 6);
    node.style.left = Math.round(left) + "px";
    node.style.top = Math.round(top) + "px";
    node.style.visibility = "";
  }

  function paint(anchor, items, note) {
    var node = menuNode();
    while (node.firstChild) node.removeChild(node.firstChild);
    if (note) node.appendChild(el("div", "msg-tools-note", note));
    for (var i = 0; i < items.length; i += 1) {
      (function (item) {
        var button = el("button", "msg-tools-item" + (item.danger ? " is-danger" : ""));
        button.type = "button";
        button.setAttribute("role", "menuitem");
        button.appendChild(el("span", "", item.label));
        if (item.hint) button.appendChild(el("small", "", item.hint));
        button.addEventListener("click", function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          closeMenu();
          item.act();
        });
        node.appendChild(button);
      })(items[i]);
    }
    place(anchor);
  }

  function openMenu(anchor, row) {
    menuAnchor = anchor;
    var info = resolve(row);
    if (!info) return;
    var ctx = context(info);
    if (!ctx.ready && ctx.serverId) {
      paint(anchor, [], "Loading…");
      ensureMembers(ctx.serverId).then(function () {
        if (menu && !menu.hidden) openMenu(anchor, row);
      });
      return;
    }
    paint(anchor, buildItems(info, ctx));
  }

  function canDelete(info, ctx) {
    if (!info.message || !info.message.id) return false;
    if (info.isMe) return true;
    if (ctx.staff) return true;
    return !!(ctx.perms.ban || ctx.perms.kick || ctx.perms.timeout || ctx.perms.editServer);
  }

  function buildItems(info, ctx) {
    var items = [];
    if (canDelete(info, ctx)) {
      items.push({
        label: "Delete message",
        danger: true,
        act: function () {
          doAction("delete", info, ctx, { messageId: info.message.id });
        }
      });
    }
    if (!info.isMe && ctx.target) {
      var name = ctx.target.username || info.username || "this member";
      if (ctx.perms.ban) {
        items.push({
          label: "Ban " + name,
          danger: true,
          act: function () {
            confirmAction(ctx.target.username || name, "Ban", "They can't rejoin until unbanned.", function () {
              doAction("ban", info, ctx, { userId: ctx.target.user });
            });
          }
        });
      }
      if (ctx.perms.kick) {
        items.push({
          label: "Kick " + name,
          act: function () {
            confirmAction(ctx.target.username || name, "Kick", "They can rejoin with a new invite.", function () {
              doAction("kick", info, ctx, { userId: ctx.target.user });
            });
          }
        });
      }
      if (ctx.perms.timeout) {
        if (ctx.muted) {
          items.push({
            label: "Unmute " + name,
            act: function () {
              doAction("untimeout", info, ctx, { userId: ctx.target.user });
            }
          });
        } else {
          items.push({
            label: "Mute " + name,
            act: function () {
              muteMenu(ctx.target.username || name, ctx.target.user, info, ctx);
            }
          });
        }
      }
    }
    if (!items.length) {
      items.push({ label: "No actions available", act: closeMenu });
    }
    return items;
  }

  function confirmAction(name, verb, detail, onYes) {
    var node = menuNode();
    while (node.firstChild) node.removeChild(node.firstChild);
    node.appendChild(el("div", "msg-tools-note", verb + " " + name + "? " + detail));
    var yes = el("button", "msg-tools-item is-danger", verb);
    yes.type = "button";
    yes.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      closeMenu();
      onYes();
    });
    var no = el("button", "msg-tools-item", "Cancel");
    no.type = "button";
    no.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      closeMenu();
    });
    node.appendChild(yes);
    node.appendChild(no);
    place(menuAnchor || document.body);
  }

  function muteMenu(name, userId, info, ctx) {
    var node = menuNode();
    while (node.firstChild) node.removeChild(node.firstChild);
    node.appendChild(el("div", "msg-tools-note", "Mute " + name + " for"));
    for (var i = 0; i < MUTES.length; i += 1) {
      (function (option) {
        var button = el("button", "msg-tools-item");
        button.type = "button";
        button.appendChild(el("span", "", option.label));
        button.addEventListener("click", function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          closeMenu();
          doAction("timeout", info, ctx, { userId: userId, seconds: option.seconds });
        });
        node.appendChild(button);
      })(MUTES[i]);
    }
    place(menuAnchor || document.body);
  }

  function doAction(action, info, ctx, extra) {
    if (busy) return;
    busy = true;
    var payload = { action: action };
    if (ctx.serverId) payload.serverId = ctx.serverId;
    for (var key in extra) {
      if (extra.hasOwnProperty(key)) payload[key] = extra[key];
    }
    api(ACT, payload)
      .then(function () {
        busy = false;
        if (action === "delete") {
          markDeleted(payload.messageId);
          if (info.row) info.row.style.display = "none";
          toast("Message deleted");
          return;
        }
        if (ctx.serverId) memberCache[ctx.serverId] = null;
        var name = (ctx.target && ctx.target.username) || info.username || "Member";
        if (action === "ban") toast("Banned " + name);
        else if (action === "unban") toast("Unbanned " + name);
        else if (action === "kick") toast("Kicked " + name);
        else if (action === "timeout") toast("Muted " + name);
        else if (action === "untimeout") toast("Unmuted " + name);
        schedule();
      })
      .catch(function (err) {
        busy = false;
        toast((err && err.message) || "That didn't work.", true);
      });
  }

  function toast(text, isErr) {
    if (!toastNode) {
      toastNode = el("div", "msg-toast");
      document.body.appendChild(toastNode);
    }
    toastNode.textContent = text;
    toastNode.classList.toggle("is-err", !!isErr);
    toastNode.classList.add("is-on");
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toastTimer = null;
      if (toastNode) toastNode.classList.remove("is-on");
    }, 2600);
  }

  function onDocClick(ev) {
    if (!menu || menu.hidden) return;
    var target = ev.target;
    if (target && menu.contains(target)) return;
    if (target && target.classList && target.classList.contains("msg-tools-btn")) return;
    closeMenu();
  }

  function onKey(ev) {
    if (ev.key === "Escape" && menu && !menu.hidden) {
      ev.stopPropagation();
      closeMenu();
    }
  }

  function onScroll(ev) {
    if (!menu || menu.hidden) return;
    if (ev && ev.target === menu) return;
    closeMenu();
  }

  function attach() {
    var list = document.getElementById("messageList");
    if (!list) {
      setTimeout(attach, 400);
      return;
    }
    var observer = new MutationObserver(function () {
      schedule();
    });
    observer.observe(list, { childList: true, subtree: true });
    var scroller = document.getElementById("messageScroll");
    if (scroller) scroller.addEventListener("scroll", onScroll, true);
    document.addEventListener("click", onDocClick, true);
    document.addEventListener("keydown", onKey, true);
    window.addEventListener("resize", closeMenu);
    window.addEventListener("hub:auth", function () {
      if (servers) storeServers({ servers: servers });
      schedule();
    });
    schedule();
  }

  wrapFetch();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", attach);
  } else {
    attach();
  }
})();
