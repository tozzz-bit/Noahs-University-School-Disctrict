(function () {
  "use strict";

  var KEY = "hub_bg";
  var KEY_MOTION = "hub_bg_motion";
  var KEY_QUALITY = "hub_bg_quality";

  var OPTIONS = [
    { id: "amber", name: "Amber", note: "Embers rising" },
    { id: "aurora", name: "Aurora", note: "Slow veils" },
    { id: "ribbons", name: "Ribbons", note: "Flowing bands" },
    { id: "silk", name: "Silk", note: "Soft fabric" },
    { id: "contour", name: "Contour", note: "Topographic lines" },
    { id: "flow", name: "Flow field", note: "Drifting particles" }
  ];

  var DEFAULT_ID = "amber";

  function read(key) {
    try {
      return localStorage.getItem(key);
    } catch (error) {
      return null;
    }
  }

  function write(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch (error) {}
  }

  function currentBackground() {
    var value = read(KEY);
    for (var index = 0; index < OPTIONS.length; index += 1) {
      if (OPTIONS[index].id === value) return value;
    }
    return DEFAULT_ID;
  }

  function motionEnabled() {
    var value = read(KEY_MOTION);
    if (value === "0") return false;
    if (value === "1") return true;
    return !(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  }

  function lowQuality() {
    var value = read(KEY_QUALITY);
    if (value === "high") return false;
    if (value === "low") return true;
    var memory = navigator.deviceMemory || 4;
    var cores = navigator.hardwareConcurrency || 4;
    return memory <= 2 || cores <= 2;
  }

  function apply(id) {
    if (window.hubBackground && window.hubBackground.set) {
      window.hubBackground.set(id);
    } else {
      write(KEY, id);
      document.dispatchEvent(new CustomEvent("hub:bg", { detail: { background: id } }));
    }
  }

  function remount() {
    document.dispatchEvent(new CustomEvent("hub:bg", { detail: { background: currentBackground() } }));
    if (window.hubBackground && window.hubBackground.set) {
      window.hubBackground.set(currentBackground());
    }
  }

  function build() {
    var anchor = document.getElementById("themeChoices");
    if (!anchor) return;
    var card = anchor.closest("fieldset");
    if (!card) return;
    if (document.getElementById("bgSettingsCard")) return;

    var grid = card.parentNode;

    var fieldset = document.createElement("fieldset");
    fieldset.className = "site-settings-card bg-settings-card";
    fieldset.id = "bgSettingsCard";
    fieldset.innerHTML =
      '<legend>Background effect</legend>' +
      '<div class="bg-grid" id="bgChoices" role="group" aria-label="Background effect"></div>' +
      '<div class="bg-toggles">' +
      '  <label class="bg-toggle">' +
      '    <span class="bg-toggle-copy"><strong>Animate background</strong><small>Turn off to freeze the background. Static backgrounds cost no CPU and save battery.</small></span>' +
      '    <input type="checkbox" id="bgMotionToggle" class="bg-switch" aria-label="Animate background">' +
      "  </label>" +
      '  <label class="bg-toggle">' +
      '    <span class="bg-toggle-copy"><strong>Performance mode</strong><small>Lower resolution and fewer particles for older laptops and Chromebooks.</small></span>' +
      '    <input type="checkbox" id="bgQualityToggle" class="bg-switch" aria-label="Performance mode">' +
      "  </label>" +
      "</div>" +
      '<p class="bg-note" id="bgNote"></p>';

    grid.appendChild(fieldset);

    var list = document.getElementById("bgChoices");
    for (var index = 0; index < OPTIONS.length; index += 1) {
      var option = OPTIONS[index];
      var tile = document.createElement("button");
      tile.type = "button";
      tile.className = "bg-tile";
      tile.dataset.bg = option.id;
      tile.setAttribute("aria-pressed", "false");
      tile.innerHTML =
        '<span class="bg-tile-shot"><img src="images/bg/' + option.id + '.jpg" alt="" loading="lazy" decoding="async" width="960" height="540"></span>' +
        '<span class="bg-tile-copy"><strong>' + option.name + "</strong><small>" + option.note + "</small></span>" +
        '<span class="bg-tile-tick" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></span>';
      tile.addEventListener("click", function (event) {
        apply(event.currentTarget.dataset.bg);
        sync();
      });
      list.appendChild(tile);
    }

    document.getElementById("bgMotionToggle").addEventListener("change", function (event) {
      write(KEY_MOTION, event.target.checked ? "1" : "0");
      remount();
      sync();
    });

    document.getElementById("bgQualityToggle").addEventListener("change", function (event) {
      write(KEY_QUALITY, event.target.checked ? "low" : "high");
      remount();
      sync();
      document.dispatchEvent(new CustomEvent("hub:quality", { detail: { quality: event.target.checked ? "low" : "high" } }));
    });

    document.addEventListener("hub:bgchange", sync);
    sync();
  }

  function sync() {
    var active = currentBackground();
    var tiles = document.querySelectorAll("#bgChoices .bg-tile");
    for (var index = 0; index < tiles.length; index += 1) {
      var isActive = tiles[index].dataset.bg === active;
      tiles[index].classList.toggle("is-active", isActive);
      tiles[index].setAttribute("aria-pressed", isActive ? "true" : "false");
    }

    var motion = document.getElementById("bgMotionToggle");
    if (motion) motion.checked = motionEnabled();

    var quality = document.getElementById("bgQualityToggle");
    if (quality) quality.checked = lowQuality();

    var note = document.getElementById("bgNote");
    if (!note) return;
    var name = OPTIONS[0].name;
    for (var index2 = 0; index2 < OPTIONS.length; index2 += 1) {
      if (OPTIONS[index2].id === active) name = OPTIONS[index2].name;
    }
    var parts = ["<strong>" + name + "</strong>"];
    if (!motionEnabled()) parts.push(read(KEY_MOTION) === "0" ? "animation off" : "reduced motion respected");
    if (lowQuality()) parts.push("performance mode");
    var loggedIn = !!read("hub_token");
    note.innerHTML = parts.join(" &middot; ") + (loggedIn ? ". Saved to your account." : ". Saved on this device &mdash; log in to sync it.");
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", build);
  } else {
    build();
  }
})();
