!function(){"use strict";

  var STYLE_KEY="hub_tabstyle_v1";
  var ICONS=location.origin+"/img/tabstyle/";
  var PRESETS=[
    {id:"clever",name:"Clever",title:"Clever | Portal",icon:"clever.png"},
    {id:"classroom",name:"Google Classroom",title:"Google Classroom",icon:"classroom.png"},
    {id:"google",name:"Google",title:"Google",icon:"google.png"},
    {id:"schoology",name:"Schoology",title:"Home | Schoology",icon:"schoology.png"},
    {id:"desmos",name:"Desmos",title:"Desmos | Graphing Calculator",icon:"desmos.png"},
    {id:"ixl",name:"IXL",title:"IXL | Math, Language Arts, Science, Social Studies, and Spanish",icon:"ixl.png"},
    {id:"khan",name:"Khan Academy",title:"Khan Academy",icon:"khan.png"},
    {id:"quizlet",name:"Quizlet",title:"Quizlet",icon:"quizlet.png"},
    {id:"kahoot",name:"Kahoot!",title:"Kahoot! | Learning games | Make learning awesome!",icon:"kahoot.png"},
    {id:"edpuzzle",name:"Edpuzzle",title:"Edpuzzle",icon:"edpuzzle.png"},
    {id:"brainpop",name:"BrainPOP",title:"BrainPOP",icon:"brainpop.png"},
    {id:"nearpod",name:"Nearpod",title:"Nearpod: Foster a love of learning in every student",icon:"nearpod.png"},
    {id:"deltamath",name:"DeltaMath",title:"DeltaMath",icon:"deltamath.png"},
    {id:"docs",name:"Google Docs",title:"Google Docs",icon:"docs.png"},
    {id:"drive",name:"Google Drive",title:"Google Drive",icon:"drive.png"},
    {id:"gmail",name:"Gmail",title:"Gmail",icon:"gmail.png"},
    {id:"powerschool",name:"PowerSchool",title:"Home | PowerSchool",icon:"powerschool.png"},
    {id:"campus",name:"Infinite Campus",title:"Infinite Campus",icon:"campus.png"},
    {id:"prodigy",name:"Prodigy",title:"Prodigy Math | Boost Student Learning & Love of Math",icon:"prodigy.png"},
    {id:"noredink",name:"NoRedInk",title:"Unlock Every Writer's Potential | NoRedInk",icon:"noredink.png"},
    {id:"typing",name:"Typing.com",title:"Learn to Type | Type Better | Type Faster - Typing.com",icon:"typing.png"},
    {id:"blooket",name:"Blooket",title:"Blooket – Fun, Free, Educational Games for Everyone",icon:"blooket.png"},
    {id:"gimkit",name:"Gimkit",title:"Gimkit - live learning game show",icon:"gimkit.png"},
    {id:"padlet",name:"Padlet",title:"Padlet - Visual Collaboration for Creative Work and Education",icon:"padlet.png"},
    {id:"canvas",name:"Canvas",title:"Canvas",icon:"canvas.png"}
  ];

  var state=loadStyle();
  var realTitle=document.title;
  var realFavicon=(document.querySelector("link[rel~=icon]")||{}).href||"";
  var coverActive=false;

  function loadStyle(){
    try{
      var d=JSON.parse(localStorage.getItem(STYLE_KEY)||"{}");
      return{enabled:!!d.enabled,title:d.title||"",favicon:d.favicon||""};
    }
    catch(e){return{enabled:false,title:"",favicon:""};}
  }

  function save(){try{localStorage.setItem(STYLE_KEY,JSON.stringify(state));}catch(e){}}

  function applyCover(){
    if(!state.enabled||coverActive)return;
    coverActive=true;
    if(document.title)realTitle=document.title;
    var live=document.querySelector("link[rel~=icon]");
    if(live&&live.href)realFavicon=live.href;
    if(state.title)document.title=state.title;
    setFavicon(state.favicon||"data:,");
  }

  function removeCover(){
    if(!coverActive)return;
    coverActive=false;
    document.title=realTitle;
    setFavicon(realFavicon);
  }

  function setFavicon(href){
    var link=document.querySelector("link[rel~=icon]");
    if(!link){link=document.createElement("link");link.rel="icon";document.head.appendChild(link);}
    link.href=href;
  }

  document.addEventListener("visibilitychange",function(){document.hidden?applyCover():removeCover();});
  window.addEventListener("blur",applyCover);
  window.addEventListener("focus",removeCover);

  function updateSwatch(sw,fav){
    if(!sw)return;
    if(fav){sw.style.backgroundImage="url("+fav+")";sw.style.backgroundColor="";}
    else{sw.style.backgroundImage="";sw.style.backgroundColor="var(--surface-3)";}
  }

  function presetById(id){
    for(var i=0;i<PRESETS.length;i++)if(PRESETS[i].id===id)return PRESETS[i];
    return null;
  }

  function presetForState(){
    for(var i=0;i<PRESETS.length;i++){
      var p=PRESETS[i];
      if(state.title===p.title&&state.favicon===ICONS+p.icon)return p;
    }
    return null;
  }

  function fillPresetSelect(sel){
    if(!sel)return;
    var custom=document.createElement("option");
    custom.value="";
    custom.textContent="Custom";
    sel.appendChild(custom);
    for(var i=0;i<PRESETS.length;i++){
      var opt=document.createElement("option");
      opt.value=PRESETS[i].id;
      opt.textContent=PRESETS[i].name;
      sel.appendChild(opt);
    }
  }

  function reapply(){
    if(!state.enabled)return;
    coverActive=false;
    if(document.hidden||!document.hasFocus())applyCover();
  }

  function reflectUI(){
    var tog=document.getElementById("tabStyleEnabled");
    var fields=document.getElementById("tabStyleFields");
    var titleIn=document.getElementById("tabStyleTitle");
    var urlIn=document.getElementById("tabStyleFaviconUrl");
    var sw=document.getElementById("tabStyleFaviconPreview");
    if(tog)tog.checked=state.enabled;
    if(fields)fields.hidden=!state.enabled;
    if(titleIn)titleIn.value=state.title;
    if(urlIn&&state.favicon&&state.favicon.indexOf("data:")<0)urlIn.value=state.favicon;
    updateSwatch(sw,state.favicon);
    var presetSel=document.getElementById("tabStylePreset");
    if(presetSel){var match=presetForState();presetSel.value=match?match.id:"";}
  }

  function escHtml(s){return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;");}

  document.addEventListener("DOMContentLoaded",function(){
    reflectUI();
    var tog=document.getElementById("tabStyleEnabled");
    var fields=document.getElementById("tabStyleFields");
    var titleIn=document.getElementById("tabStyleTitle");
    var urlIn=document.getElementById("tabStyleFaviconUrl");
    var fileIn=document.getElementById("tabStyleFaviconFile");
    var sw=document.getElementById("tabStyleFaviconPreview");
    var blankBtn=document.getElementById("tabStyleBlankBtn");
    var blobBtn=document.getElementById("tabStyleBlobBtn");

    if(tog){tog.addEventListener("change",function(){state.enabled=tog.checked;if(fields)fields.hidden=!state.enabled;if(!state.enabled)removeCover();save();});}
    if(titleIn){titleIn.addEventListener("input",function(){state.title=titleIn.value;var ps=document.getElementById("tabStylePreset");if(ps)ps.value="";save();});}
    if(urlIn){urlIn.addEventListener("input",function(){var v=urlIn.value.trim();state.favicon=v;updateSwatch(sw,v);var ps=document.getElementById("tabStylePreset");if(ps)ps.value="";save();});}
    if(fileIn){
      fileIn.addEventListener("change",function(){
        var file=fileIn.files&&fileIn.files[0]; if(!file)return;
        var reader=new FileReader();
        reader.onload=function(e){state.favicon=e.target.result;updateSwatch(sw,e.target.result);if(urlIn)urlIn.value="";var ps=document.getElementById("tabStylePreset");if(ps)ps.value="";save();};
        reader.readAsDataURL(file);
        fileIn.value="";
      });
    }
    if(blankBtn){
      blankBtn.addEventListener("click",function(){
        var url=window.location.href;
        var ct=state.title||document.title;
        var cf=state.favicon||realFavicon;
        var w=window.open("about:blank","_blank");
        if(!w){alert("Pop-up blocked! Allow pop-ups for this site and try again.");return;}
        try{w.opener=null;}catch(e){}
        var fTag=cf?"<link rel=\"icon\" href=\""+escHtml(cf)+"\">":"";
        w.document.write("<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><title>"+escHtml(ct)+"</title>"+fTag+"<style>*{margin:0;padding:0;box-sizing:border-box}html,body{width:100%;height:100%;overflow:hidden}iframe{display:block;width:100%;height:100%;border:none}</style></head><body><iframe src=\""+escHtml(url)+"\" allow=\"autoplay;fullscreen;clipboard-write\"></iframe></body></html>");
        w.document.close();
      });
    }
    if(blobBtn){
      blobBtn.addEventListener("click",function(){
        var ct=state.title||document.title;
        var cf=state.favicon||realFavicon;
        var fTag=cf?"<link rel=\"icon\" href=\""+escHtml(cf)+"\">":"";
        var html="<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><title>"+escHtml(ct)+"</title>"+fTag+"<style>*{margin:0;padding:0;box-sizing:border-box}html,body{width:100%;height:100%;overflow:hidden}iframe{display:block;width:100%;height:100%;border:none}</style></head><body><iframe src=\""+escHtml(window.location.href)+"\" allow=\"autoplay;fullscreen;clipboard-write\"></iframe></body></html>";
        var blob=new Blob([html],{type:"text/html"});
        var blobUrl=URL.createObjectURL(blob);
        var w=window.open(blobUrl,"_blank");
        if(!w)alert("Pop-up blocked! Allow pop-ups for this site and try again.");
      });
    }
    var presetSelect=document.getElementById("tabStylePreset");
    if(presetSelect){
      fillPresetSelect(presetSelect);
      var picked=presetForState();
      presetSelect.value=picked?picked.id:"";
      presetSelect.addEventListener("change",function(){
        var p=presetById(presetSelect.value);
        if(!p)return;
        state.title=p.title;
        state.favicon=ICONS+p.icon;
        if(titleIn)titleIn.value=p.title;
        if(urlIn)urlIn.value=state.favicon;
        updateSwatch(sw,state.favicon);
        save();
        reapply();
      });
    }
  });

}();
