(function () {
  "use strict";

  var DEFAULT_KEY = "a684e603a8e2a274413d8cc6f32935a5";
  var KEY_STORE = "hub_movies_tmdb";
  var FAV_STORE = "hub_movies_favs";
  var PROG_STORE = "hub_movies_progress";
  var IMG = "https://image.tmdb.org/t/p/";
  var SOURCES = ["tik", "rock", "meridian", "lil"];
  var LOCK_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="10.5" width="16" height="10.5" rx="2.4"/><path d="M8 10.5V7.6a4 4 0 0 1 8 0v2.9"/></svg>';
  var lockedOut = false;

  var s = { view: "home", progress: {}, lastKey: null, chipId: "", items: {}, genre: "", year: "", sort: "popularity.desc", favs: {}, playing: null, tried: {}, hls: null, season: 1, playSeason: 1, playEpisode: 1, sheetKey: null, epCount: 0, epsSeason: 1, upNext: null, upNextOff: false, subs: [], ccIndex: -1, qual: null, source: "" };

  var epCache = {};

  function seasonsOf(showId) {
    var key = "s:" + showId;
    if (epCache[key]) return Promise.resolve(epCache[key]);
    return api("/tv/" + showId).then(function (show) {
      epCache[key] = (show.seasons || []).filter(function (x) { return x.season_number > 0; });
      return epCache[key];
    });
  }

  function episodesOf(showId, season) {
    var key = showId + ":" + season;
    if (epCache[key]) return Promise.resolve(epCache[key]);
    return api("/tv/" + showId + "/season/" + season).then(function (d) {
      epCache[key] = d.episodes || [];
      return epCache[key];
    });
  }

  function currentIndex() {
    var key = s.playing && s.playing.item.id;
    var list = epCache[key + ":" + s.playSeason] || [];
    for (var i = 0; i < list.length; i++) {
      if (list[i].episode_number === s.playEpisode) return { list: list, at: i };
    }
    return { list: list, at: -1 };
  }

  function nextEpisode() {
    if (!s.playing || s.playing.kind !== "tv") return null;
    var here = currentIndex();
    if (here.at >= 0 && here.at + 1 < here.list.length) {
      var n = here.list[here.at + 1];
      return { season: s.playSeason, episode: n.episode_number, name: n.name, still: n.still_path };
    }
    var seasons = epCache["s:" + s.playing.item.id] || [];
    for (var i = 0; i < seasons.length; i++) {
      if (seasons[i].season_number !== s.playSeason) continue;
      if (i + 1 >= seasons.length) return null;
      return { season: seasons[i + 1].season_number, episode: 1, name: "Episode 1", still: null, nextSeason: true };
    }
    return null;
  }

  function hideUpNext() {
    var card = document.getElementById("mvUpNext");
    if (card) card.classList.remove("open");
  }

  function paintUpNext() {
    var card = document.getElementById("mvUpNext");
    if (!card) return;
    var n = s.upNextOff ? null : nextEpisode();
    if (!n) { card.classList.remove("open"); return; }
    s.upNext = n;
    document.getElementById("mvUpNextTitle").textContent =
      "S" + n.season + " E" + n.episode + (n.name ? " \u00b7 " + n.name : "");
    document.getElementById("mvUpNextSub").textContent = n.nextSeason ? "Next season" : "Next episode";
    var img = document.getElementById("mvUpNextImg");
    img.style.backgroundImage = n.still
      ? "url('/api/movies/img?p=" + encodeURIComponent(n.still) + "&s=w300')" : "none";
    card.classList.add("open");
  }

  function markPlayerEpisodes() {
    Array.prototype.forEach.call(document.querySelectorAll("#mvEpsList [data-pep]"), function (n) {
      n.classList.toggle("on", Number(n.getAttribute("data-pep")) === s.playEpisode);
    });
    Array.prototype.forEach.call(document.querySelectorAll("#mvEpsPop [data-pseason]"), function (n) {
      n.classList.toggle("on", Number(n.getAttribute("data-pseason")) === s.epsSeason);
    });
  }

  function paintPlayerEpisodes(season) {
    if (!s.playing || s.playing.kind !== "tv") return;
    s.epsSeason = season || s.playSeason;
    var showId = s.playing.item.id;
    var chips = document.getElementById("mvEpsSeasons");
    var list = document.getElementById("mvEpsList");
    if (!chips || !list) return;
    seasonsOf(showId).then(function (seasons) {
      chips.innerHTML = seasons.map(function (x) {
        return '<button class="mv-epchip' + (x.season_number === s.epsSeason ? " on" : "") +
          '" type="button" data-pseason="' + x.season_number + '">S' + x.season_number + "</button>";
      }).join("");
    }).catch(function () {});
    list.innerHTML = '<div class="mv-epp-i">Loading episodes…</div>';
    episodesOf(showId, s.epsSeason).then(function (eps) {
      list.innerHTML = eps.map(function (x) {
        var img = x.still_path ? "/api/movies/img?p=" + encodeURIComponent(x.still_path) + "&s=w300" : "";
        var now = x.episode_number === s.playEpisode;
        return '<button class="mv-epp-i' + (now ? " on" : "") + '" type="button" data-pep="' + x.episode_number + '">' +
          (img ? '<img loading="lazy" src="' + esc(img) + '" alt="">' : "") +
          '<span class="mv-epp-n">' + x.episode_number + "</span>" +
          '<span class="mv-epp-t"><b>' + esc(x.name || "Episode " + x.episode_number) + "</b><span>" +
          (now ? "Now playing" : esc(x.air_date || "")) + "</span></span></button>";
      }).join("") || '<div class="mv-epp-i">No episodes listed.</div>';
      markPlayerEpisodes();
    }).catch(function () {
      list.innerHTML = '<div class="mv-epp-i">Could not load episodes.</div>';
    });
  }

  function episodeLabel(showId, season, episode) {
    var list = epCache[showId + ":" + season] || [];
    for (var i = 0; i < list.length; i++) {
      if (list[i].episode_number !== episode) continue;
      var name = list[i].name;
      return "Season " + season + " \u00b7 Episode " + episode + (name ? " \u00b7 " + name : "");
    }
    return "Season " + season + " \u00b7 Episode " + episode;
  }

  function paintSub(entry) {
    var e = entry || s.playing;
    if (!e) return;
    if (e.kind !== "tv") { plSub.textContent = yr(dt(e.item)); return; }
    plSub.textContent = episodeLabel(e.item.id, s.playSeason, s.playEpisode);
    var shown = s.playSeason + ":" + s.playEpisode;
    episodesOf(e.item.id, s.playSeason).then(function () {
      if (!s.playing || s.playing.kind !== "tv") return;
      if (s.playSeason + ":" + s.playEpisode !== shown) return;
      plSub.textContent = episodeLabel(e.item.id, s.playSeason, s.playEpisode);
    }).catch(function () {});
  }

  function playEpisode(season, episode) {
    if (!s.playing || s.playing.kind !== "tv") return;
    s.playSeason = season;
    s.playEpisode = episode;
    s.season = season;
    s.tried = {};
    s.retries = 0;
    s.resumeAt = 0;
    s.upNextOff = false;
    s.upNext = null;
    s.switchSeen = false;
    s.switchAt = Date.now();
    hideUpNext();
    paintSub(s.playing);
    spin.classList.add("on");
    err.classList.remove("on");
    playEntry(s.playing, null);
    markPlayerEpisodes();
  }

  function key() { try { return localStorage.getItem(KEY_STORE) || DEFAULT_KEY; } catch (e) { return DEFAULT_KEY; } }
  function loadFavs() { try { s.favs = JSON.parse(localStorage.getItem(FAV_STORE) || "{}") || {}; } catch (e) { s.favs = {}; } }
  function saveFavs() { try { localStorage.setItem(FAV_STORE, JSON.stringify(s.favs)); } catch (e) {} }
  function authToken() { try { return localStorage.getItem("hub_token") || ""; } catch (e) { return ""; } }

  function writeProgressLocal() {
    try {
      var keys = Object.keys(s.progress);
      if (keys.length > 40) {
        keys.sort(function (a, b) { return (s.progress[a].at || 0) - (s.progress[b].at || 0); });
        while (keys.length > 40) delete s.progress[keys.shift()];
      }
      localStorage.setItem(PROG_STORE, JSON.stringify(s.progress));
    } catch (e) {}
  }

  function loadProgress() {
    try { s.progress = JSON.parse(localStorage.getItem(PROG_STORE) || "{}") || {}; } catch (e) { s.progress = {}; }
    pullProgress();
  }

  function saveProgress() {
    writeProgressLocal();
    pushProgress();
  }

  var progressPushTimer = null;
  var progressLastPushed = "";

  function pushProgress() {
    if (!authToken()) return;
    if (progressPushTimer) clearTimeout(progressPushTimer);
    progressPushTimer = setTimeout(function () {
      progressPushTimer = null;
      var t = authToken();
      if (!t) return;
      var payload = JSON.stringify({ progress: s.progress });
      if (payload === progressLastPushed) return;
      progressLastPushed = payload;
      fetch("/api/watch-progress", {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: t },
        body: payload
      }).catch(function () { progressLastPushed = ""; });
    }, 4000);
  }

  function pullProgress() {
    var t = authToken();
    if (!t) return;
    fetch("/api/watch-progress", { headers: { Authorization: t } }).then(function (r) {
      return r.ok ? r.json() : null;
    }).then(function (data) {
      var remote = data && data.progress;
      if (!remote || typeof remote !== "object") return;
      var changed = false;
      Object.keys(remote).forEach(function (k) {
        var incoming = remote[k];
        if (!incoming) return;
        var mine = s.progress[k];
        if (!mine || (Number(incoming.at) || 0) > (Number(mine.at) || 0)) {
          s.progress[k] = incoming;
          changed = true;
        }
      });
      if (!changed) return;
      writeProgressLocal();
      progressLastPushed = "";
      if (root && !root.hidden && s.view === "home") renderHome();
    }).catch(function () {});
  }

  function recordProgress(key, time, duration) {
    if (!key || !duration || !isFinite(duration) || time < 15) return;
    var entry = s.items[key];
    if (!entry) return;
    var pct = time / duration;
    var tv = entry.kind === "tv";
    var thumb = { id: entry.item.id, title: entry.item.title, name: entry.item.name,
      poster_path: entry.item.poster_path, release_date: entry.item.release_date,
      first_air_date: entry.item.first_air_date, vote_average: entry.item.vote_average };
    if (pct > 0.96) {
      var seen = s.progress[key];
      if (!tv) { delete s.progress[key]; saveProgress(); return; }
      if (seen && seen.season === s.playSeason
        && (seen.episode > s.playEpisode || seen.done)) return;
      var last = s.epCount && s.playEpisode >= s.epCount;
      s.progress[key] = {
        id: entry.item.id, kind: "tv", t: 0, d: Math.floor(duration), pct: 0, at: Date.now(),
        season: s.playSeason, episode: last ? s.playEpisode : s.playEpisode + 1,
        done: !!last, item: thumb
      };
      saveProgress();
      return;
    }
    s.progress[key] = {
      id: entry.item.id, kind: entry.kind, t: Math.floor(time), d: Math.floor(duration),
      pct: pct, at: Date.now(),
      season: tv ? s.playSeason : undefined, episode: tv ? s.playEpisode : undefined,
      item: thumb
    };
    saveProgress();
  }
  function esc(v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function yr(v) { return v ? String(v).slice(0, 4) : ""; }
  function nm(i) { return i.title || i.name || "Untitled"; }
  function dt(i) { return i.release_date || i.first_air_date || ""; }
  function art(i) { return i.poster_path ? "/api/movies/img?p=" + encodeURIComponent(i.poster_path) + "&s=w342" : ""; }
  function back(i) { return i.backdrop_path ? "/api/movies/img?p=" + encodeURIComponent(i.backdrop_path) + "&s=w1280" : ""; }
  function fmt(t) {
    t = Math.max(0, Math.floor(t || 0));
    var h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), x = t % 60;
    return (h ? h + ":" + String(m).padStart(2, "0") : String(m)) + ":" + String(x).padStart(2, "0");
  }
  function api(path, params) {
    var q = new URLSearchParams();
    q.set("path", path);
    Object.keys(params || {}).forEach(function (p) { q.set(p, params[p]); });
    return fetch("/api/movies/tmdb?" + q.toString()).then(function (r) {
      if (!r.ok) throw new Error("tmdb " + r.status);
      return r.json();
    });
  }
  function remember(kind, list) { list.forEach(function (i) { s.items[kind + ":" + i.id] = { item: i, kind: kind }; }); }

  function card(item, kind) {
    var k = kind + ":" + item.id;
    var src = art(item);
    return '<button class="mv-card" type="button" data-open="' + esc(k) + '">' +
      '<div class="mv-poster">' +
      (src ? '<img loading="lazy" src="' + esc(src) + '" alt="">' : '<span style="position:absolute;inset:0;display:grid;place-items:center;padding:10px;text-align:center;font-size:.72rem;color:var(--text-faint)">' + esc(nm(item)) + "</span>") +
      (item.vote_average ? '<span class="mv-score">' + item.vote_average.toFixed(1) + "</span>" : "") +
      '<span class="mv-heart' + (s.favs[k] ? " on" : "") + '" data-fav="' + esc(k) + '" role="button">' +
      '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 21s-7.5-4.6-9.7-9A5.6 5.6 0 0 1 12 5.5 5.6 5.6 0 0 1 21.7 12C19.5 16.4 12 21 12 21z"/></svg></span>' +
      "</div><div class=\"mv-cap\"><span class=\"mv-t\">" + esc(nm(item)) + "</span><span class=\"mv-y\">" + esc(yr(dt(item))) + "</span></div></button>";
  }

  function row(label, items, kind, more) {
    if (!items || !items.length) return "";
    remember(kind, items);
    var link = more ? '<button class="mv-more" type="button" data-more="' + esc(more + "|" + kind + "|" + label) + '">See all</button>' : "";
    return '<section class="mv-row"><div class="mv-row-h"><h2>' + esc(label) + "</h2>" + link + '</div><div class="mv-rail">' +
      items.slice(0, 22).map(function (i) { return card(i, kind); }).join("") + "</div></section>";
  }

  function continueRow() {
    var list = Object.keys(s.progress).map(function (k) { return { key: k, e: s.progress[k] }; })
      .filter(function (x) { return x.e && x.e.item; })
      .sort(function (a, b) { return b.e.at - a.e.at; })
      .slice(0, 12);
    if (!list.length) return "";
    return '<section class="mv-row"><div class="mv-row-h"><h2>Continue watching</h2></div><div class="mv-rail">' +
      list.map(function (x) {
        var it = x.e.item;
        s.items[x.key] = { item: it, kind: x.e.kind };
        var left = Math.max(1, Math.round((x.e.d - x.e.t) / 60));
        var sub = x.e.kind === "tv"
          ? "S" + (x.e.season || 1) + " E" + (x.e.episode || 1) + " \u00b7 " + (x.e.t ? left + " min left" : "up next")
          : left + " min left";
        return '<button class="mv-card" type="button" data-open="' + esc(x.key) + '">' +
          '<div class="mv-poster">' + (art(it) ? '<img loading="lazy" src="' + esc(art(it)) + '" alt="">' : "") +
          '<span class="mv-prog"><i style="width:' + Math.round(x.e.pct * 100) + '%"></i></span></div>' +
          '<div class="mv-cap"><span class="mv-t">' + esc(nm(it)) + '</span><span class="mv-y">' + esc(sub) + '</span></div></button>';
      }).join("") + "</div></section>";
  }

  function suggestRow(trending) {
    var last = null;
    var keys = Object.keys(s.progress);
    if (keys.length) {
      keys.sort(function (a, b) { return (s.progress[b].at || 0) - (s.progress[a].at || 0); });
      last = s.progress[keys[0]];
    }
    if (!last || !last.id) return "";
    var box = '<section class="mv-row" id="mvSuggest"><div class="mv-row-h"><h2>Because you watched ' + esc(nm(last.item)) + '</h2></div><div class="mv-rail" id="mvSuggestRail">' + new Array(7).join('<div class="mv-skel"></div>') + "</div></section>";
    api("/" + last.kind + "/" + last.id + "/recommendations").then(function (d) {
      var rail = document.getElementById("mvSuggestRail");
      if (!rail) return;
      var items = (d.results || []).slice(0, 20);
      remember(last.kind, items);
      rail.innerHTML = items.map(function (i) { return card(i, last.kind); }).join("");
    }).catch(function () {
      var box2 = document.getElementById("mvSuggest");
      if (box2) box2.remove();
    });
    return box;
  }

  function grid(items, kind) {
    remember(kind, items);
    return '<div class="mv-grid">' + items.map(function (i) { return card(i, kind); }).join("") + "</div>";
  }

  function skel() {
    var one = '<div class="mv-rail">' + new Array(9).join('<div class="mv-skel"></div>') + "</div>";
    return '<section class="mv-row"><div class="mv-row-h"><h2></h2></div>' + one + "</section><section class=\"mv-row\">" + one + "</section>";
  }

  var MOVIE_CHIPS = [
    { id: "", label: "All", p: {} },
    { id: "28", label: "Action", p: { with_genres: "28" } },
    { id: "35", label: "Comedy", p: { with_genres: "35" } },
    { id: "18", label: "Drama", p: { with_genres: "18" } },
    { id: "27", label: "Horror", p: { with_genres: "27" } },
    { id: "878", label: "Sci-Fi", p: { with_genres: "878" } },
    { id: "53", label: "Thriller", p: { with_genres: "53" } },
    { id: "16", label: "Animation", p: { with_genres: "16" } },
    { id: "10749", label: "Romance", p: { with_genres: "10749" } },
    { id: "80", label: "Crime", p: { with_genres: "80" } }
  ];

  var TV_CHIPS = [
    { id: "", label: "All", p: {} },
    { id: "anime", label: "Anime", p: { with_genres: "16", with_origin_country: "JP" } },
    { id: "adult-anim", label: "Adult animation", p: { with_genres: "16", without_genres: "10762,10751" } },
    { id: "kid-anim", label: "Kids animation", p: { with_genres: "16,10762" } },
    { id: "10759", label: "Action & Adventure", p: { with_genres: "10759" } },
    { id: "35", label: "Comedy", p: { with_genres: "35" } },
    { id: "80", label: "Crime", p: { with_genres: "80" } },
    { id: "99", label: "Documentary", p: { with_genres: "99" } },
    { id: "18", label: "Drama", p: { with_genres: "18" } },
    { id: "9648", label: "Mystery", p: { with_genres: "9648" } },
    { id: "10764", label: "Reality", p: { with_genres: "10764" } },
    { id: "10765", label: "Sci-Fi & Fantasy", p: { with_genres: "10765" } },
    { id: "10767", label: "Talk", p: { with_genres: "10767" } }
  ];

  function chipList(kind) { return kind === "tv" ? TV_CHIPS : MOVIE_CHIPS; }

  function activeChip(kind) {
    var list = chipList(kind);
    for (var i = 0; i < list.length; i += 1) if (list[i].id === s.chipId) return list[i];
    return list[0];
  }

  function chips() {
    var kind = s.view === "tv" ? "tv" : "movie";
    var list = chipList(kind);
    var y = [["", "Any year"], ["2026", "2026"], ["2025", "2025"], ["2024", "2024"], ["2015", "2015–19"], ["2005", "2005–14"], ["1995", "1995–04"]];
    var so = kind === "tv"
      ? [["popularity.desc", "Popular"], ["vote_average.desc", "Top rated"], ["first_air_date.desc", "Newest"], ["vote_count.desc", "Most watched"]]
      : [["popularity.desc", "Popular"], ["vote_average.desc", "Top rated"], ["primary_release_date.desc", "Newest"], ["vote_count.desc", "Most watched"]];
    return '<div class="mv-chips">' + list.map(function (x) {
      return '<button class="mv-chip' + (s.chipId === x.id ? " on" : "") + '" type="button" data-genre="' + x.id + '">' + x.label + "</button>";
    }).join("") +
      '<select class="mv-sel mv-sel-first" id="mvYear">' + y.map(function (x) { return '<option value="' + x[0] + '"' + (s.year === x[0] ? " selected" : "") + ">" + x[1] + "</option>"; }).join("") + "</select>" +
      '<select class="mv-sel" id="mvSort">' + so.map(function (x) { return '<option value="' + x[0] + '"' + (s.sort === x[0] ? " selected" : "") + ">" + x[1] + "</option>"; }).join("") + "</select></div>";
  }

  function shell(inner) {
    root.innerHTML =
      '<div class="mv">' +
      '<div class="mv-bar">' +
      '<h1 class="mv-title">Movies</h1>' +
      '<div class="mv-nav" id="mvNav">' +
      ["home:Home", "movie:Movies", "tv:TV Shows", "favs:Favorites"].map(function (p) {
        var parts = p.split(":");
        return '<button type="button" data-view="' + parts[0] + '"' + (s.view === parts[0] ? ' class="on"' : "") + ">" + parts[1] + "</button>";
      }).join("") +
      "</div>" +
      '<form class="mv-search" id="mvSearch">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3-3"/></svg>' +
      '<input id="mvQ" type="search" placeholder="Search movies and shows" autocomplete="off"></form>' +
      "</div>" + inner + "</div>";
    if (lockedOut) lockMovies();
  }

  function signedIn() {
    try { return Boolean(localStorage.getItem("hub_token")); } catch (e) { return false; }
  }

  function openSignin() {
    if (window.hubChat && window.hubChat.account) { window.hubChat.account(); return; }
    var nav = document.getElementById("navChat");
    if (nav) nav.click();
  }

  function lockMovies() {
    var gate = document.createElement("div");
    gate.className = "mv-lock";
    gate.innerHTML = '<div class="mv-lock-card">' +
      '<span class="mv-lock-ico">' + LOCK_ICON + "</span>" +
      "<h2>Movies are for members</h2>" +
      "<p>To access the movies you need to be signed in.</p>" +
      '<button class="mv-btn primary" type="button" data-mv-signin>Sign in</button>' +
      "</div>";
    var btn = gate.querySelector("[data-mv-signin]");
    if (btn) btn.addEventListener("click", openSignin);
    root.appendChild(gate);
  }

  function renderHome() {
    shell(skel());
    Promise.all([
      api("/trending/all/week"), api("/movie/now_playing"), api("/movie/popular"),
      api("/movie/top_rated"), api("/movie/upcoming"), api("/tv/popular")
    ]).then(function (r) {
      var mixed = (r[0].results || []).filter(function (i) { return i.media_type !== "person"; });
      mixed.forEach(function (i) { s.items[(i.media_type || "movie") + ":" + i.id] = { item: i, kind: i.media_type || "movie" }; });
      var html = '<div class="mv-chips"></div>';
      html += continueRow();
      html += '<section class="mv-row"><div class="mv-row-h"><h2>Trending this week</h2></div><div class="mv-rail">' +
        mixed.slice(0, 22).map(function (i) { return card(i, i.media_type || "movie"); }).join("") + "</div></section>";
      html += suggestRow(mixed);
      html += row("In cinemas", r[1].results, "movie", "/movie/now_playing") +
        row("Popular movies", r[2].results, "movie", "/movie/popular") +
        row("Top rated", r[3].results, "movie", "/movie/top_rated") +
        row("Coming soon", r[4].results, "movie", "/movie/upcoming") +
        row("Popular shows", r[5].results, "tv", "/tv/popular");
      shell(html);
    }).catch(function (e) { shell('<div class="mv-empty">Could not load titles (' + esc(e.message) + ").</div>"); });
  }

  function renderBrowse(kind) {
    if (kind === "tv" && s.sort === "primary_release_date.desc") s.sort = "first_air_date.desc";
    if (kind !== "tv" && s.sort === "first_air_date.desc") s.sort = "primary_release_date.desc";
    var p = { sort_by: s.sort, page: 1, "vote_count.gte": kind === "tv" ? 20 : 40 };
    var chip = activeChip(kind);
    Object.keys(chip.p).forEach(function (k2) { if (chip.p[k2]) p[k2] = chip.p[k2]; });
    if (s.year) {
      var y0 = parseInt(s.year, 10), y1 = s.year.length === 4 ? y0 : y0 + 9;
      if (kind === "tv") { p["first_air_date.gte"] = y0 + "-01-01"; p["first_air_date.lte"] = y1 + "-12-31"; }
      else { p["primary_release_date.gte"] = y0 + "-01-01"; p["primary_release_date.lte"] = y1 + "-12-31"; }
    }
    shell(skel());
    api("/discover/" + kind, p).then(function (r) {
      var items = r.results || [];
      shell(chips() + (items.length
        ? '<section class="mv-row"><div class="mv-row-h"><h2>' + (kind === "tv" ? "TV shows" : "Movies") + "</h2></div>" + grid(items, kind) + "</section>"
        : '<div class="mv-empty">Nothing matches those filters.</div>'));
    }).catch(function () { shell('<div class="mv-empty">Could not load.</div>'); });
  }

  function renderFavs() {
    var list = Object.keys(s.favs).map(function (k) {
      var p = k.split(":");
      return { kind: p[0], item: s.favs[k] };
    }).filter(function (e) { return e.item; });
    list.forEach(function (e) { s.items[e.kind + ":" + e.item.id] = e; });
    shell(list.length
      ? '<section class="mv-row"><div class="mv-row-h"><h2>Favorites</h2></div><div class="mv-grid">' + list.map(function (e) { return card(e.item, e.kind); }).join("") + "</div></section>"
      : '<div class="mv-empty">No favorites yet — hover a poster and tap the heart.</div>');
  }

  function expandCollection(label, path, kind) {
    shell('<div class="mv-col-head"><button class="mv-back" type="button" data-back="1">←</button><h2>' + esc(label) + '</h2></div>' + skel());
    var pages = [1, 2, 3];
    Promise.all(pages.map(function (p) {
      return api(path, { page: p }).then(function (r) { return r.results || []; }).catch(function () { return []; });
    })).then(function (groups) {
      var seen = {};
      var items = [];
      groups.forEach(function (g) {
        g.forEach(function (i) { if (!seen[i.id]) { seen[i.id] = 1; items.push(i); } });
      });
      shell('<div class="mv-col-head"><button class="mv-back" type="button" data-back="1">←</button><h2>' + esc(label) +
        '</h2><span class="mv-count">' + items.length + '</span></div>' +
        (items.length ? grid(items, kind) : '<div class="mv-empty">Nothing here yet.</div>'));
    }).catch(function () { shell('<div class="mv-empty">Could not load.</div>'); });
  }

  function renderSearch(term) {
    shell(skel());
    api("/search/multi", { query: term, include_adult: "false" }).then(function (r) {
      var list = (r.results || []).filter(function (x) { return x.media_type === "movie" || x.media_type === "tv"; });
      if (!list.length) { shell('<div class="mv-empty">Nothing found for “' + esc(term) + '”.</div>'); return; }
      var mv = list.filter(function (x) { return x.media_type === "movie"; });
      var tv = list.filter(function (x) { return x.media_type === "tv"; });
      var html = "";
      if (mv.length) html += '<section class="mv-row"><div class="mv-row-h"><h2>Movies</h2></div>' + grid(mv, "movie") + "</section>";
      if (tv.length) html += '<section class="mv-row"><div class="mv-row-h"><h2>TV shows</h2></div>' + grid(tv, "tv") + "</section>";
      shell(html);
    }).catch(function () { shell('<div class="mv-empty">Search failed.</div>'); });
  }

  function wireRails() {
    Array.prototype.forEach.call(document.querySelectorAll("#moviesView .mv-row"), function (sec) {
      var rail = sec.querySelector(".mv-rail");
      if (!rail || sec.querySelector(".mv-arrow")) return;
      sec.classList.add("has-rail");
      [["left", "‹"], ["right", "›"]].forEach(function (p) {
        var b = document.createElement("button");
        b.className = "mv-arrow " + p[0];
        b.type = "button";
        b.setAttribute("aria-label", p[0] === "left" ? "Scroll left" : "Scroll right");
        b.textContent = p[1];
        b.addEventListener("click", function () {
          var step = rail.clientWidth * 0.82;
          rail.scrollBy({ left: p[0] === "left" ? -step : step, behavior: "smooth" });
        });
        sec.appendChild(b);
      });
    });
  }

  function setView(v) {
    if (v !== s.view) s.chipId = "";
    s.view = v;
    if (v === "home") renderHome();
    else if (v === "favs") renderFavs();
    else renderBrowse(v);
  }

  function detail(k) {
    var e = s.items[k];
    if (!e) return;
    var i = e.item;
    var isFav = !!s.favs[k];
    sheetHero.style.backgroundImage = back(i) ? "url('" + back(i) + "')" : "none";
    sheetBody.innerHTML =
      "<h2>" + esc(nm(i)) + "</h2>" +
      '<div class="mv-meta"><span class="mv-pill">' + (e.kind === "tv" ? "Series" : "Film") + "</span>" +
      (yr(dt(i)) ? "<span>" + esc(yr(dt(i))) + "</span>" : "") +
      (i.vote_average ? "<span>★ " + i.vote_average.toFixed(1) + "</span>" : "") +
      (i.number_of_seasons ? "<span>" + i.number_of_seasons + " seasons</span>" : "") + "</div>" +
      '<p class="mv-ov">' + esc(i.overview || "No description available.") + "</p>" +
      '<div class="mv-actions">' +
      '<button class="mv-btn primary" type="button" data-play="' + esc(k) + '">' + esc(playLabel(k)) + '</button>' +
      '<button class="mv-btn" type="button" data-fav-btn="' + esc(k) + '">' + (isFav ? "♥ Favorited" : "♡ Favorite") + "</button></div>" +
      '<div id="mvSeasons"></div>';
    sheet.classList.add("open");
    s.sheetKey = k;
    if (e.kind === "tv") loadSeasons(i.id);
  }

  function playLabel(k) {
    var saved = s.progress[k];
    if (!saved) return "▶ Play";
    if (saved.kind === "tv") {
      return saved.t ? "▶ Resume S" + (saved.season || 1) + " E" + (saved.episode || 1) : "▶ Play";
    }
    return "▶ Resume";
  }

  function loadSeasons(id) {
    api("/tv/" + id).then(function (show) {
      var box = document.getElementById("mvSeasons");
      if (!box) return;
      var seasons = (show.seasons || []).filter(function (x) { return x.season_number > 0; });
      var saved = s.progress[s.sheetKey];
      var want = saved && saved.kind === "tv" ? saved.season : 0;
      var pick = seasons.length ? seasons[0].season_number : 1;
      if (want && seasons.some(function (x) { return x.season_number === want; })) pick = want;
      s.season = pick;
      box.innerHTML = '<div class="mv-seasons">' + seasons.map(function (x) {
        return '<button class="mv-chip' + (x.season_number === s.season ? " on" : "") + '" type="button" data-season="' + x.season_number + '">Season ' + x.season_number + "</button>";
      }).join("") + '</div><div class="mv-eps" id="mvEps"></div>';
      loadEps(id);
    }).catch(function () {});
  }

  function loadEps(id) {
    var box = document.getElementById("mvEps");
    if (!box) return;
    box.innerHTML = '<div class="mv-empty" style="padding:16px">Loading episodes…</div>';
    var saved = s.progress[s.sheetKey];
    var mark = saved && saved.kind === "tv" && saved.season === s.season ? saved.episode : 0;
    api("/tv/" + id + "/season/" + s.season).then(function (d) {
      s.epCount = (d.episodes || []).length;
      box.innerHTML = (d.episodes || []).map(function (x) {
        var img = x.still_path ? IMG + "w300" + x.still_path : "";
        return '<button class="mv-ep' + (x.episode_number === mark ? " on" : "") + '" type="button" data-ep="' + x.episode_number + '"><span class="mv-ep-n">' + x.episode_number + "</span>" +
          (img ? '<img loading="lazy" src="' + esc(img) + '" alt="">' : "") +
          '<span class="mv-ep-t"><b>' + esc(x.name || "Episode " + x.episode_number) + "</b><span>" + esc(x.air_date || "") + "</span></span></button>";
      }).join("") || '<div class="mv-empty" style="padding:16px">No episodes.</div>';
    }).catch(function () { box.innerHTML = '<div class="mv-empty" style="padding:16px">No episodes.</div>'; });
  }

  function setFav(k) {
    var e = s.items[k];
    if (!e) return;
    if (s.favs[k]) delete s.favs[k];
    else s.favs[k] = { id: e.item.id, title: e.item.title, name: e.item.name, poster_path: e.item.poster_path, release_date: e.item.release_date, first_air_date: e.item.first_air_date, vote_average: e.item.vote_average, media_type: e.kind };
    saveFavs();
    document.querySelectorAll('[data-fav="' + k + '"]').forEach(function (n) { n.classList.toggle("on", !!s.favs[k]); });
  }

  function playEntry(e, source) {
    if (lockedOut) { openSignin(); return; }
    s.playing = e;
    var mine = (s.attempt = (s.attempt || 0) + 1);
    var kind = e.kind === "tv" ? "tv" : "movie";
    var url = "/api/movies/resolve?tmdb=" + encodeURIComponent(e.item.id) + "&type=" + kind +
      (source ? "&src=" + source : "") +
      (kind === "tv" ? "&season=" + s.playSeason + "&episode=" + s.playEpisode : "");
    spin.classList.add("on");
    err.classList.remove("on");
    fetch(url).then(function (r) { return r.json(); }).then(function (d) {
      if (mine !== s.attempt) return;
      if (!d || !d.url) return nextSource();
      attach(d.url, d.source, d.subtitles);
    }).catch(function () {
      if (mine === s.attempt) nextSource();
    });
  }

  function nextSource() {
    var n = SOURCES.filter(function (x) { return !s.tried[x]; })[0];
    if (!n) {
      if ((s.retries || 0) < 1) {
        s.retries = (s.retries || 0) + 1;
        s.tried = {};
        setTimeout(function () { playEntry(s.playing, null); }, 1500);
        return;
      }
      s.attempt = (s.attempt || 0) + 1;
      spin.classList.remove("on");
      var line = err && err.querySelector("p");
      if (line) line.textContent = unplayable();
      err.classList.add("on");
      return;
    }
    s.tried[n] = true;
    playEntry(s.playing, n);
  }

  function unplayable() {
    var e = s.playing;
    if (!e) return "This title could not be played. Try another.";
    if (e.kind === "tv") {
      return "Season " + s.playSeason + " episode " + s.playEpisode
        + " is not available from any source right now. Try a different episode.";
    }
    return "This title is not available from any source right now. Try another.";
  }

  function attach(url, source, subtitles) {
    var token = authToken();
    var proxied = "/api/movies/stream?src=" + encodeURIComponent(source) + "&u=" + encodeURIComponent(url) +
      (token ? "&t=" + encodeURIComponent(token) : "");
    s.source = source;
    s.subs = Array.isArray(subtitles) ? subtitles : [];
    s.ccIndex = -1;
    s.qual = null;
    paintCC();
    paintQuals();
    if (s.hls) { try { s.hls.destroy(); } catch (e) {} s.hls = null; }
    err.classList.remove("on");
    var line = err && err.querySelector("p");
    if (line) line.textContent = "Every source failed. Try again in a moment.";
    spin.classList.add("on");
    clearTimeout(s.attachTimer);
    var attachToken = s.attempt;
    s.attachTimer = setTimeout(function () {
      if (s.attempt !== attachToken) return;
      if (video.currentTime > 1 || video.readyState >= 3) return;
      nextSource();
    }, 18000);
    if (window.Hls && window.Hls.isSupported()) {
      s.hls = new window.Hls({
        maxBufferLength: 60,
        maxMaxBufferLength: 180,
        maxBufferSize: 120 * 1000 * 1000,
        backBufferLength: 90,
        enableWorker: true,
        lowLatencyMode: false,
        manifestLoadingTimeOut: 20000,
        manifestLoadingMaxRetry: 4,
        levelLoadingTimeOut: 20000,
        fragLoadingTimeOut: 45000,
        fragLoadingMaxRetry: 8,
        startLevel: 0
      });
      s.hls.loadSource(proxied);
      s.hls.attachMedia(video);
      s.hls.on(window.Hls.Events.ERROR, function (a, d) { if (d && d.fatal) nextSource(); });
      s.hls.on(window.Hls.Events.AUDIO_TRACKS_UPDATED, paintAudio);
      s.hls.on(window.Hls.Events.AUDIO_TRACK_SWITCHED, paintAudio);
      s.hls.on(window.Hls.Events.MANIFEST_PARSED, function () {
        clearTimeout(s.attachTimer);
        paintQuals();
        paintAudio();
        var opened = Date.now();
        var watch = setInterval(function () {
          var ahead = 0;
          try {
            if (video.buffered.length) {
              ahead = video.buffered.end(video.buffered.length - 1) - (video.currentTime || 0);
            }
          } catch (e) {}
          if (ahead < 20 && Date.now() - opened < 25000) {
            spin.classList.add("on");
            return;
          }
          clearInterval(watch);
          spin.classList.remove("on");
          if (s.resumeAt) { try { video.currentTime = s.resumeAt; } catch (e) {} s.resumeAt = 0; }
          video.play().catch(function () {});
        }, 400);
      });
    } else {
      video.src = proxied;
      video.play().catch(function () {});
      setTimeout(function () { spin.classList.remove("on"); }, 800);
    }
    document.querySelectorAll("#mvSources .mv-pop-i").forEach(function (n) { n.classList.toggle("on", n.dataset.source === source); });
    paintAudio();
  }

  function paintAudio() {
    var wrap = document.getElementById("mvAudioWrap");
    var box = document.getElementById("mvAudio");
    if (!wrap || !box) return;
    var tracks = (s.hls && s.hls.audioTracks) || [];
    if (tracks.length < 2) {
      wrap.style.display = "none";
      box.innerHTML = "";
      return;
    }
    wrap.style.display = "";
    var current = s.hls.audioTrack;
    box.innerHTML = tracks.map(function (track, i) {
      var name = track.name || track.lang || track.language || ("Audio " + (i + 1));
      return '<button class="mv-pop-i' + (i === current ? " on" : "") + '" type="button" data-audio="' + i + '">' + esc(name) + "</button>";
    }).join("");
  }

  function paintQuals() {
    var box = document.getElementById("mvQuals");
    var note = document.getElementById("mvQualNote");
    if (!box || !note) return;
    var levels = (s.hls && s.hls.levels) || [];
    var seen = {};
    var heights = [];
    levels.forEach(function (lv) {
      var h = Math.round(lv.height || 0);
      if (!h || seen[h]) return;
      seen[h] = 1;
      heights.push(h);
    });
    heights.sort(function (a, b) { return b - a; });
    var html = '<button class="mv-pop-i' + (s.qual == null ? " on" : "") + '" type="button" data-qual="auto">Auto</button>';
    html += heights.map(function (h) {
      return '<button class="mv-pop-i' + (s.qual === h ? " on" : "") + '" type="button" data-qual="' + h + '">' + h + "p</button>";
    }).join("");
    box.innerHTML = html;
    var top = heights.length ? heights[0] : 0;
    note.textContent = top && top < 1080 ? "1080p is a Plus feature." : "";
    note.style.display = note.textContent ? "" : "none";
  }

  function applyQual(value) {
    var hls = s.hls;
    if (!hls || !hls.levels || !hls.levels.length) return;
    if (value === "auto") {
      s.qual = null;
      hls.autoLevelCapping = -1;
      hls.currentLevel = -1;
      paintQuals();
      return;
    }
    var want = Number(value);
    var best = -1;
    var height = 0;
    hls.levels.forEach(function (lv, i) {
      var h = Math.round(lv.height || 0);
      if (!h || h > want || h <= height) return;
      height = h;
      best = i;
    });
    if (best < 0) return;
    s.qual = height;
    hls.autoLevelCapping = -1;
    hls.currentLevel = best;
    paintQuals();
  }

  function paintCC() {
    var btn = document.getElementById("mvCC");
    var box = document.getElementById("mvCCTracks");
    if (!btn || !box) return;
    btn.style.display = s.subs.length ? "" : "none";
    var pop = document.getElementById("mvCCPop");
    if (!s.subs.length) {
      if (pop) pop.classList.remove("open");
      box.innerHTML = "";
      return;
    }
    var html = '<button class="mv-pop-i' + (s.ccIndex < 0 ? " on" : "") + '" type="button" data-cc="-1">Off</button>';
    html += s.subs.map(function (track, i) {
      return '<button class="mv-pop-i' + (s.ccIndex === i ? " on" : "") + '" type="button" data-cc="' + i + '">' + esc(track.language) + "</button>";
    }).join("");
    box.innerHTML = html;
  }

  function pickCC(index) {
    var old = video.querySelectorAll("track[data-mvsub]");
    for (var i = 0; i < old.length; i += 1) old[i].remove();
    s.ccIndex = index;
    var track = index >= 0 ? s.subs[index] : null;
    if (track) {
      var node = document.createElement("track");
      node.kind = "subtitles";
      node.label = track.language;
      node.srclang = String(track.language || "").slice(0, 2).toLowerCase();
      node.setAttribute("data-mvsub", "1");
      node.src = "/api/movies/sub?src=" + encodeURIComponent(s.source || "meridian") + "&u=" + encodeURIComponent(track.url);
      node.default = true;
      video.appendChild(node);
      window.setTimeout(function () {
        var list = video.textTracks;
        for (var k = 0; k < list.length; k += 1) list[k].mode = "showing";
      }, 150);
    }
    paintCC();
  }

  function openPlayer(k, ep, season) {
    var e = s.items[k];
    if (!e) return;
    sheet.classList.remove("open");
    s.tried = {};
    s.retries = 0;
    var saved = s.progress[k];
    if (e.kind === "tv") {
      var wantSeason = season || (ep && s.season) || (saved && saved.season) || s.season || 1;
      var wantEpisode = ep || (saved && saved.season === wantSeason ? saved.episode : 0) || 1;
      s.playSeason = wantSeason;
      s.playEpisode = wantEpisode;
      s.season = wantSeason;
    }
    plTitle.textContent = nm(e.item);
    paintSub(e);
    document.getElementById("mvSources").innerHTML = SOURCES.map(function (x) {
      return '<button class="mv-pop-i" type="button" data-source="' + x + '">' + x + '<span style="margin-left:auto;width:6px;height:6px;border-radius:50%;background:var(--accent);opacity:0" class="dot"></span></button>';
    }).join("");
    player.classList.add("open");
    player.classList.remove("hide");
    s.playingKey = k;
    s.upNextOff = false;
    s.upNext = null;
    s.switchSeen = false;
    s.switchAt = Date.now();
    hideUpNext();
    var epsBtn = document.getElementById("mvEpsBtn");
    var epsPop = document.getElementById("mvEpsPop");
    if (epsPop) epsPop.classList.remove("open");
    if (epsBtn) epsBtn.style.display = e.kind === "tv" ? "" : "none";
    if (e.kind === "tv") {
      paintPlayerEpisodes(s.playSeason);
      seasonsOf(e.item.id).catch(function () {});
      episodesOf(e.item.id, s.playSeason).catch(function () {});
    }
    var same = !saved || e.kind !== "tv" || (saved.season === s.playSeason && saved.episode === s.playEpisode);
    s.resumeAt = saved && same && saved.t > 20 ? saved.t : 0;
    playEntry(e, null);
  }

  function closePlayer() {
    hideUpNext();
    s.subs = [];
    s.ccIndex = -1;
    s.qual = null;
    paintCC();
    var pop = document.getElementById("mvEpsPop");
    if (pop) pop.classList.remove("open");
    var ccPop = document.getElementById("mvCCPop");
    if (ccPop) ccPop.classList.remove("open");
    if (s.hls) { try { s.hls.destroy(); } catch (e) {} s.hls = null; }
    var tracks = video.querySelectorAll("track[data-mvsub]");
    for (var t = 0; t < tracks.length; t += 1) tracks[t].remove();
    try { video.pause(); } catch (e) {}
    video.removeAttribute("src");
    video.load();
    player.classList.remove("open");
    if (document.fullscreenElement) document.exitFullscreen().catch(function () {});
  }


  var ICONS = {
    play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>',
    pause: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>',
    back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg>',
    fwd: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v5h-5"/></svg>',
    vol: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>',
    gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
    full: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M8 21H5a2 2 0 0 1-2-2v-3M16 21h3a2 2 0 0 0 2-2v-3"/></svg>',
    list: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h9M4 12h9M4 17h9M18 7v10l-3-2z"/></svg>',
    mute: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4z"/><path d="M16 9l5 6M21 9l-5 6"/></svg>',
    cc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 11a2.2 2.2 0 1 0 0 2"/><path d="M16.5 11a2.2 2.2 0 1 0 0 2"/></svg>'
  };

  var root, sheet, sheetHero, sheetBody, player, video, spin, err, plTitle, plSub;

  function build() {
    root = document.createElement("section");
    root.id = "moviesView";
    root.hidden = true;
    root.setAttribute("aria-label", "Movies");
    document.querySelector("main").appendChild(root);

    sheet = document.createElement("div");
    sheet.className = "mv-sheet";
    sheet.innerHTML = '<div class="mv-sheet-in"><div class="mv-hero" id="mvHero"><button class="icon-btn" style="position:absolute;top:12px;right:12px;z-index:3" data-close-sheet type="button">✕</button></div><div class="mv-body" id="mvBody"></div></div>';
    document.body.appendChild(sheet);
    sheetHero = document.getElementById("mvHero");
    sheetBody = document.getElementById("mvBody");

    player = document.createElement("div");
    player.className = "mv-player";
    player.innerHTML =
      '<video id="mvVideo" playsinline preload="metadata"></video>' +
      '<div class="mv-spin" id="mvSpin"><i></i></div>' +
      '<div class="mv-err" id="mvErr"><div><h3>Couldn\'t play this one</h3><p>Every source failed. Try again in a moment.</p><button class="mv-btn primary" type="button" data-retry>Try again</button></div></div>' +
      '<div class="mv-upnext" id="mvUpNext"><div class="mv-upnext-img" id="mvUpNextImg"></div>' +
        '<div class="mv-upnext-b"><span class="mv-upnext-k">Up next</span><b id="mvUpNextTitle"></b><span id="mvUpNextSub"></span></div>' +
        '<button class="mv-btn primary" type="button" id="mvUpNextGo">Play</button>' +
        '<button class="mv-upnext-x" type="button" id="mvUpNextNo">\u2715</button></div>' +
      '<div class="mv-pl-top"><div style="min-width:0"><div class="mv-pl-title" id="mvPlTitle"></div><div class="mv-pl-sub" id="mvPlSub"></div></div>' +
      '<button class="mv-pl-x" id="mvClose" type="button">✕</button></div>' +
      '<div class="mv-pl-bottom"><div class="mv-seek" id="mvSeek"><div class="mv-seek-track"><div class="mv-seek-buf" id="mvBuf"></div><div class="mv-seek-fill" id="mvFill"></div></div></div>' +
      '<div class="mv-pl-row"><button class="mv-pbtn big" id="mvPlay" type="button">' + ICONS.play + '</button>' +
      '<button class="mv-pbtn" id="mvBack" type="button">' + ICONS.back + '</button><button class="mv-pbtn" id="mvFwd" type="button">' + ICONS.fwd + '</button>' +
      '<div class="mv-vol"><button class="mv-pbtn" id="mvMute" type="button">' + ICONS.vol + '</button><input id="mvVol" type="range" min="0" max="1" step="0.05" value="1"></div>' +
      '<span class="mv-ptime" id="mvTime">0:00 / 0:00</span><div class="mv-pspace"></div>' +
      '<button class="mv-pbtn wide" id="mvEpsBtn" type="button">' + ICONS.list + '<span>Episodes</span></button>' +
      '<button class="mv-pbtn" id="mvCC" type="button" style="display:none">' + ICONS.cc + '</button>' +
      '<button class="mv-pbtn" id="mvSet" type="button">' + ICONS.gear + '</button><button class="mv-pbtn" id="mvFull" type="button">' + ICONS.full + '</button></div>' +
      '<div class="mv-pop mv-eps-pop" id="mvEpsPop"><h4>Episodes</h4><div class="mv-eps-pop-seasons" id="mvEpsSeasons"></div><div class="mv-eps-pop-list" id="mvEpsList"></div></div>' +
      '<div class="mv-pop mv-cc-pop" id="mvCCPop"><h4>Captions</h4><div id="mvCCTracks"></div></div>' +
      '<div class="mv-pop" id="mvPop"><div id="mvAudioWrap" style="display:none"><h4>Audio</h4><div id="mvAudio"></div></div><h4>Quality</h4><div id="mvQuals"></div><p class="mv-pop-note" id="mvQualNote"></p><h4>Source</h4><div id="mvSources"></div><h4>Speed</h4><div id="mvSpeeds">' +
      [0.75, 1, 1.25, 1.5, 2].map(function (x) { return '<button class="mv-pop-i' + (x === 1 ? " on" : "") + '" type="button" data-speed="' + x + '">' + x + "×</button>"; }).join("") +
      "</div></div></div>";
    document.body.appendChild(player);

    video = document.getElementById("mvVideo");
    spin = document.getElementById("mvSpin");
    err = document.getElementById("mvErr");
    plTitle = document.getElementById("mvPlTitle");
    plSub = document.getElementById("mvPlSub");

    new MutationObserver(function () { wireRails(); }).observe(root, { childList: true, subtree: true });
    document.addEventListener("click", onDocClick);
    document.addEventListener("keydown", onKey);
    document.addEventListener("change", function (ev) {
      var t = ev.target;
      if (!t || !t.id) return;
      if (t.id === "mvYear") s.year = t.value;
      else if (t.id === "mvSort") s.sort = t.value;
      else return;
      if (s.view === "movie" || s.view === "tv") renderBrowse(s.view);
    });
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("play", function () { document.getElementById("mvPlay").innerHTML = ICONS.pause; });
    video.addEventListener("playing", function () { s.switchSeen = true; clearTimeout(s.attachTimer); });

    var volInput = document.getElementById("mvVol");
    function syncVolume() {
      var silent = video.muted || video.volume === 0;
      if (volInput) volInput.value = String(silent ? 0 : video.volume);
      var muteBtn = document.getElementById("mvMute");
      if (muteBtn) muteBtn.innerHTML = silent ? ICONS.mute : ICONS.vol;
    }
    if (volInput) {
      volInput.addEventListener("input", function () {
        var next = parseFloat(volInput.value);
        if (!isFinite(next)) return;
        next = Math.max(0, Math.min(1, next));
        video.volume = next;
        video.muted = next === 0;
      });
    }
    video.addEventListener("volumechange", syncVolume);
    syncVolume();
    video.addEventListener("pause", function () { document.getElementById("mvPlay").innerHTML = ICONS.play; });
    video.addEventListener("ended", function () {
      if (!s.playing || s.playing.kind !== "tv") return;
      var n = nextEpisode();
      if (n && !s.upNextOff) playEpisode(n.season, n.episode);
    });
  }

  function onKey(ev) {
    if (!player || !player.classList.contains("open")) return;
    var node = ev.target;
    var tag = node && node.tagName ? String(node.tagName).toLowerCase() : "";
    if (tag === "input" || tag === "textarea" || tag === "select" || (node && node.isContentEditable)) return;
    if (ev.key === " " || ev.key === "Spacebar" || ev.code === "Space") {
      ev.preventDefault();
      if (video.paused) video.play().catch(function () {});
      else video.pause();
      return;
    }
    if (ev.key === "ArrowRight") {
      ev.preventDefault();
      var next = video.currentTime + 10;
      video.currentTime = video.duration ? Math.min(video.duration - 0.5, next) : next;
      return;
    }
    if (ev.key === "ArrowLeft") {
      ev.preventDefault();
      video.currentTime = Math.max(0, video.currentTime - 10);
    }
  }

  function onTime() {
    var p = video.duration ? video.currentTime / video.duration : 0;
    if (s.playing && s.playing.kind === "tv") {
      var card = document.getElementById("mvUpNext");
      var ready = s.switchSeen && video.duration > 0 && video.currentTime > 3;
      if (card && ready) {
        var left = video.duration - video.currentTime;
        if (left < 45 && left > 1 && !s.upNextOff) paintUpNext();
        else if (left > 50 && card.classList.contains("open")) card.classList.remove("open");
      }
    }
    if (s.playingKey && Math.floor(video.currentTime) % 5 === 0) recordProgress(s.playingKey, video.currentTime, video.duration);
    document.getElementById("mvFill").style.transform = "scaleX(" + p + ")";
    document.getElementById("mvTime").textContent = fmt(video.currentTime) + " / " + fmt(video.duration);
    if (video.buffered.length) {
      document.getElementById("mvBuf").style.transform = "scaleX(" + (video.buffered.end(video.buffered.length - 1) / (video.duration || 1)) + ")";
    }
  }

  function onDocClick(ev) {
    if (!root) return;
    var fav = ev.target.closest("[data-fav]");
    if (fav) { ev.preventDefault(); ev.stopPropagation(); setFav(fav.dataset.fav); return; }
    var more = ev.target.closest("[data-more]");
    if (more) {
      var parts = more.dataset.more.split("|");
      expandCollection(parts[2], parts[0], parts[1]);
      return;
    }
    if (ev.target.closest("[data-back]")) { setView(s.view); return; }
    var g = ev.target.closest("[data-genre]");
    if (g) { s.chipId = g.dataset.genre; setView(s.view === "home" ? "movie" : s.view); return; }
    var navBtn = ev.target.closest("#mvNav button");
    if (navBtn) { setView(navBtn.dataset.view); return; }
    var open = ev.target.closest("[data-open]");
    if (open) { detail(open.dataset.open); return; }
    var play = ev.target.closest("[data-play]");
    if (play) { openPlayer(play.dataset.play); return; }
    var fb = ev.target.closest("[data-fav-btn]");
    if (fb) { setFav(fb.dataset.favBtn); fb.textContent = s.favs[fb.dataset.favBtn] ? "♥ Favorited" : "♡ Favorite"; return; }
    var season = ev.target.closest("[data-season]");
    if (season) {
      s.season = parseInt(season.dataset.season, 10);
      document.querySelectorAll("[data-season]").forEach(function (n) { n.classList.toggle("on", n === season); });
      var pb = sheetBody.querySelector("[data-play]");
      if (pb) loadEps(pb.dataset.play.split(":")[1]);
      return;
    }
    var ep = ev.target.closest("[data-ep]");
    if (ep) {
      var pb2 = sheetBody.querySelector("[data-play]");
      if (pb2) openPlayer(pb2.dataset.play, parseInt(ep.dataset.ep, 10), s.season);
      return;
    }
    if (ev.target.closest("[data-close-sheet]") || ev.target === sheet) { sheet.classList.remove("open"); return; }
    var src = ev.target.closest("#mvSources .mv-pop-i");
    if (src) { s.tried = {}; s.tried[src.dataset.source] = true; playEntry(s.playing, src.dataset.source); return; }
    var sp = ev.target.closest("[data-speed]");
    if (sp) { video.playbackRate = parseFloat(sp.dataset.speed); document.querySelectorAll("[data-speed]").forEach(function (n) { n.classList.toggle("on", n === sp); }); return; }
    if (ev.target.closest("#mvClose")) { closePlayer(); return; }
    if (ev.target.closest("[data-retry]")) { s.tried = {}; playEntry(s.playing, null); return; }
    if (ev.target.closest("#mvEpsBtn")) {
      if (!s.playing || s.playing.kind !== "tv") return;
      var eps = document.getElementById("mvEpsPop");
      var open = !eps.classList.contains("open");
      document.getElementById("mvPop").classList.remove("open");
      eps.classList.toggle("open", open);
      if (open) paintPlayerEpisodes(s.epsSeason || s.playSeason);
      return;
    }
    var pSeason = ev.target.closest("[data-pseason]");
    if (pSeason) { paintPlayerEpisodes(Number(pSeason.getAttribute("data-pseason"))); return; }
    var pEp = ev.target.closest("[data-pep]");
    if (pEp) {
      playEpisode(s.epsSeason, Number(pEp.getAttribute("data-pep")));
      document.getElementById("mvEpsPop").classList.remove("open");
      return;
    }
    if (ev.target.closest("#mvUpNextGo")) {
      var up = s.upNext || nextEpisode();
      if (up) playEpisode(up.season, up.episode);
      return;
    }
    if (ev.target.closest("#mvUpNextNo")) { s.upNextOff = true; hideUpNext(); return; }
    var aBtn = ev.target.closest("[data-audio]");
    if (aBtn && s.hls) {
      var trackIndex = Number(aBtn.getAttribute("data-audio"));
      if (isFinite(trackIndex)) {
        s.hls.audioTrack = trackIndex;
        paintAudio();
      }
      return;
    }
    var qBtn = ev.target.closest("[data-qual]");
    if (qBtn) { applyQual(qBtn.dataset.qual); return; }
    if (ev.target.closest("#mvCC")) {
      var ccPop = document.getElementById("mvCCPop");
      var ccOpen = !ccPop.classList.contains("open");
      document.getElementById("mvPop").classList.remove("open");
      document.getElementById("mvEpsPop").classList.remove("open");
      ccPop.classList.toggle("open", ccOpen);
      return;
    }
    var ccPick = ev.target.closest("[data-cc]");
    if (ccPick) { pickCC(Number(ccPick.getAttribute("data-cc"))); return; }
    if (ev.target.closest("#mvSet")) { document.getElementById("mvPop").classList.toggle("open"); return; }
    if (!ev.target.closest("#mvPop")) document.getElementById("mvPop").classList.remove("open");
    if (!ev.target.closest("#mvCCPop") && !ev.target.closest("#mvCC")) {
      var ccBox = document.getElementById("mvCCPop");
      if (ccBox) ccBox.classList.remove("open");
    }
    if (!ev.target.closest("#mvEpsPop") && !ev.target.closest("#mvEpsBtn")) {
      var ep = document.getElementById("mvEpsPop");
      if (ep) ep.classList.remove("open");
    }
    if (ev.target.closest("#mvPlay")) { video.paused ? video.play() : video.pause(); return; }
    if (ev.target.closest("#mvBack")) { video.currentTime -= 10; return; }
    if (ev.target.closest("#mvFwd")) { video.currentTime += 10; return; }
    if (ev.target.closest("#mvMute")) {
      if (video.muted || video.volume === 0) {
        video.muted = false;
        if (video.volume === 0) video.volume = 1;
      } else {
        video.muted = true;
      }
      return;
    }
    if (ev.target.closest("#mvFull")) { if (!document.fullscreenElement) player.requestFullscreen().catch(function () {}); else document.exitFullscreen().catch(function () {}); return; }
    if (ev.target.closest("#mvSeek")) {
      var r = document.getElementById("mvSeek").getBoundingClientRect();
      var p = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width));
      if (video.duration) video.currentTime = p * video.duration;
      return;
    }
    if (ev.target.closest("[data-view]")) { setView(ev.target.closest("[data-view]").dataset.view); return; }
  }

  function mount() {
    if (root) return;
    lockedOut = !signedIn();
    build();
    Array.prototype.forEach.call(document.querySelectorAll('main > *'), function (n) {
      if (n.id === 'moviesView') return;
      var t = (n.textContent || '').trim();
      if (/^ADVERTISEMENT/i.test(t) && t.length < 500) n.style.display = 'none';
    });
    document.querySelectorAll("main > section[id$='View']").forEach(function (n) { n.hidden = true; });
    root.hidden = false;
    if (lockedOut) root.classList.add("mv-locked");
    loadFavs();
    loadProgress();
    renderHome();
    Array.prototype.forEach.call(document.querySelectorAll(".rail-btn"), function (b) {
      if (b.id !== "navMovies") { b.classList.remove("is-active"); b.removeAttribute("aria-current"); }
    });
    var navBtn = document.getElementById("navMovies");
    if (navBtn) { navBtn.classList.add("is-active"); navBtn.setAttribute("aria-current", "page"); }
  }

  document.addEventListener("submit", function (ev) {
    var form = ev.target;
    if (!form || form.id !== "mvSearch") return;
    ev.preventDefault();
    var input = document.getElementById("mvQ");
    var term = input ? input.value.trim() : "";
    if (term) renderSearch(term);
    else setView(s.view);
  });

  function hideMovies() {
    if (!root) return;
    root.hidden = true;
    var nav = document.getElementById("navMovies");
    if (nav) { nav.classList.remove("is-active"); nav.removeAttribute("aria-current"); }
    setTimeout(function () {
      document.querySelectorAll("#moviesView .mv-arrow").forEach(function (n) { n.remove(); });
    }, 0);
  }

  function showMovies() {
    if (!root) { mount(); return; }
    Array.prototype.forEach.call(document.querySelectorAll("main > section[id$='View']"), function (n) {
      if (n.id !== "moviesView") n.hidden = true;
    });
    root.hidden = false;
    Array.prototype.forEach.call(document.querySelectorAll(".rail-btn"), function (b) {
      if (b.id !== "navMovies") { b.classList.remove("is-active"); b.removeAttribute("aria-current"); }
    });
    var nav = document.getElementById("navMovies");
    if (nav) { nav.classList.add("is-active"); nav.setAttribute("aria-current", "page"); }
    if (!s.items || !Object.keys(s.items).length) renderHome();
  }

  document.addEventListener("click", function (ev) {
    if (ev.target.closest("#navMovies")) { setTimeout(showMovies, 0); return; }
    var other = ev.target.closest(".rail-btn");
    if (other && other.id !== "navMovies") setTimeout(hideMovies, 0);
  });

  window.addEventListener("hub:auth", function () {
    if (!root) return;
    var nowLocked = !signedIn();
    if (nowLocked !== lockedOut) {
      lockedOut = nowLocked;
      if (lockedOut) {
        if (!root.querySelector(".mv-lock")) lockMovies();
        root.classList.add("mv-locked");
      } else {
        var gate = root.querySelector(".mv-lock");
        if (gate) gate.remove();
        root.classList.remove("mv-locked");
        renderHome();
      }
    }
    progressLastPushed = "";
    pullProgress();
  });

  var params = new URLSearchParams(location.search);
  var boot = function () {
    if (params.get("view") === "movies") mount();
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  window.hubMovies = { mount: mount };
})();
