(function () {
  "use strict";

  var SHUFFLE_KEY = "hub_music_shuffle";
  var REPEAT_KEY = "hub_music_repeat";

  var ICON_SHUFFLE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 18h1.4c1.3 0 2.5-.6 3.3-1.7l6.1-8.6c.8-1.1 2-1.7 3.3-1.7H22"/><path d="m18 2 4 4-4 4"/><path d="M2 6h1.9c1.5 0 2.9.9 3.6 2.2"/><path d="M22 18h-5.9c-1.3 0-2.6-.7-3.3-1.8l-.5-.8"/><path d="m18 14 4 4-4 4"/></svg>';
  var ICON_REPEAT = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/></svg>';
  var BADGE = '<span class="mbar-badge" aria-hidden="true">1</span>';

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = text;
    return node;
  }

  function read(key) {
    try { return localStorage.getItem(key) || ""; } catch (e) { return ""; }
  }

  function write(key, value) {
    try {
      if (value) localStorage.setItem(key, value);
      else localStorage.removeItem(key);
    } catch (e) {}
  }

  function shuffleOn() {
    return read(SHUFFLE_KEY) === "1";
  }

  function repeatMode() {
    return read(REPEAT_KEY);
  }

  function music() {
    return window.hubMusic || null;
  }

  function audioEl() {
    return document.querySelector("audio");
  }

  function shuffleList(list) {
    for (var i = list.length - 1; i > 0; i -= 1) {
      var j = Math.floor(Math.random() * (i + 1));
      var tmp = list[i];
      list[i] = list[j];
      list[j] = tmp;
    }
    return list;
  }

  function applyLoop() {
    var a = audioEl();
    if (!a) return;
    var one = repeatMode() === "one";
    if (a.loop !== one) a.loop = one;
  }

  function paint() {
    var shuffleBtn = document.getElementById("musicShuffle");
    var repeatBtn = document.getElementById("musicRepeat");
    var playing = false;
    try {
      playing = Boolean(music() && music().now && music().now());
    } catch (e) {
      playing = false;
    }
    if (shuffleBtn) {
      var on = shuffleOn();
      shuffleBtn.classList.toggle("is-on", on);
      shuffleBtn.setAttribute("aria-pressed", on ? "true" : "false");
      shuffleBtn.setAttribute("aria-label", on ? "Shuffle on" : "Shuffle off");
      shuffleBtn.title = on ? "Shuffle on" : "Shuffle off";
      shuffleBtn.classList.toggle("is-idle", !on && !playing);
    }
    if (repeatBtn) {
      var mode = repeatMode();
      repeatBtn.classList.toggle("is-on", mode !== "");
      repeatBtn.setAttribute("data-mode", mode || "off");
      repeatBtn.setAttribute("aria-pressed", mode !== "" ? "true" : "false");
      repeatBtn.setAttribute("aria-label", mode === "one" ? "Repeat this song" : mode === "all" ? "Repeat the queue" : "Repeat off");
      repeatBtn.title = mode === "one" ? "Repeating this song" : mode === "all" ? "Repeating the queue" : "Repeat off";
      repeatBtn.classList.toggle("is-idle", mode === "" && !playing);
    }
    applyLoop();
  }

  function toggleShuffle() {
    var next = !shuffleOn();
    write(SHUFFLE_KEY, next ? "1" : "");
    var api = music();
    if (next && api && api.queueState && api.setQueue) {
      var state = api.queueState();
      if (state.list.length > 1) {
        var current = state.list[state.index] || null;
        var rest = [];
        for (var i = 0; i < state.list.length; i += 1) {
          if (i !== state.index) rest.push(state.list[i]);
        }
        shuffleList(rest);
        api.setQueue(current ? [current].concat(rest) : rest, 0);
      }
    }
    paint();
  }

  function cycleRepeat() {
    var mode = repeatMode();
    var next = mode === "" ? "all" : mode === "all" ? "one" : "";
    write(REPEAT_KEY, next);
    paint();
  }

  function watchEnd() {
    var a = audioEl();
    if (!a || a.__hubRepeat) return;
    a.__hubRepeat = true;
    a.addEventListener("ended", function () {
      applyLoop();
      if (repeatMode() !== "all") return;
      setTimeout(function () {
        var api = music();
        if (!api || !api.queueState || !api.play) return;
        var state = api.queueState();
        if (!state.list.length) return;
        if (state.index < state.list.length - 1) return;
        api.play(state.list, 0);
      }, 80);
    });
  }

  function wrapPlay() {
    var api = music();
    if (!api || api.__modes) return false;
    var original = api.play;
    if (typeof original !== "function") return false;
    api.play = function (list, index) {
      var items = Array.isArray(list) ? list.slice() : [];
      var at = Math.max(0, Number(index) || 0);
      if (shuffleOn() && items.length > 1) {
        if (at > 0 && items[at]) {
          var keep = items[at];
          var rest = [];
          for (var i = 0; i < items.length; i += 1) {
            if (i !== at) rest.push(items[i]);
          }
          shuffleList(rest);
          items = [keep].concat(rest);
        } else {
          shuffleList(items);
        }
        at = 0;
      }
      original.call(api, items, at);
      applyLoop();
    };
    api.__modes = true;
    return true;
  }

  function build(id, icon, label, handler) {
    var btn = el("button", "mbar-mode");
    btn.id = id;
    btn.type = "button";
    btn.title = label;
    btn.setAttribute("aria-label", label);
    btn.setAttribute("aria-pressed", "false");
    btn.innerHTML = icon;
    btn.addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      handler();
    });
    return btn;
  }

  function mount() {
    var transport = document.querySelector("#musicBar .mbar-transport");
    if (!transport) {
      setTimeout(mount, 500);
      return;
    }
    if (!document.getElementById("musicShuffle")) {
      transport.insertBefore(build("musicShuffle", ICON_SHUFFLE, "Shuffle off", toggleShuffle), transport.firstChild);
    }
    if (!document.getElementById("musicRepeat")) {
      var repeatBtn = build("musicRepeat", ICON_REPEAT + BADGE, "Repeat off", cycleRepeat);
      transport.appendChild(repeatBtn);
    }
    ensure();
  }

  function ensure() {
    wrapPlay();
    watchEnd();
    applyLoop();
    paint();
  }

  function boot() {
    mount();
    setTimeout(mount, 1200);
    setInterval(function () {
      if (!document.getElementById("musicShuffle") || !document.getElementById("musicRepeat")) mount();
      else ensure();
    }, 2000);
    var bar = document.getElementById("musicBar");
    if (bar) {
      var obs = new MutationObserver(function () { paint(); });
      obs.observe(bar, { attributes: true, attributeFilter: ["hidden"], childList: true, subtree: true });
    }
    document.addEventListener("click", function (ev) {
      var t = ev.target;
      if (!t || !t.closest) return;
      if (t.closest("#musicPrev") || t.closest("#musicNext") || t.closest("#musicBarToggle")) {
        setTimeout(paint, 120);
      }
    }, true);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
