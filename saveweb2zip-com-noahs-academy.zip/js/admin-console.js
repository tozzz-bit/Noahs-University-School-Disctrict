(function () {
  "use strict";

  var API = "/api/chat";
  var state = { account: null, busy: false, standing: null, mode: "full", names: { full: "", limited: "" } };

  function token() {
    try { return localStorage.getItem("hub_token") || ""; } catch (e) { return ""; }
  }

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = text;
    return node;
  }

  function api(path, body, method) {
    var headers = { "Content-Type": "application/json" };
    var t = token();
    if (t) headers.Authorization = t;
    return fetch(API + path, {
      method: method || (body ? "POST" : "GET"),
      headers: headers,
      body: body ? JSON.stringify(body) : undefined
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) {
        if (!res.ok) throw new Error((data && data.message) || "Something went wrong.");
        return data;
      });
    });
  }

  function note(text, bad) {
    var box = document.getElementById("acNote");
    if (!box) {
      box = el("div", "ac-note");
      box.id = "acNote";
      document.body.appendChild(box);
    }
    box.textContent = text;
    box.classList.toggle("is-bad", Boolean(bad));
    box.classList.add("is-on");
    clearTimeout(box.__t);
    box.__t = setTimeout(function () { box.classList.remove("is-on"); }, 2600);
  }

  function when(value) {
    var at = Date.parse(String(value || "").replace(" ", "T"));
    if (!Number.isFinite(at)) return "";
    return new Date(at).toLocaleString();
  }

  function left(value) {
    var at = Date.parse(String(value || "").replace(" ", "T"));
    if (!Number.isFinite(at)) return "";
    var diff = at - Date.now();
    if (diff <= 0) return "expired";
    var mins = Math.ceil(diff / 60000);
    if (mins < 60) return mins + " min left";
    var hours = Math.ceil(mins / 60);
    if (hours < 48) return hours + " h left";
    return Math.ceil(hours / 24) + " d left";
  }

  function initials(name) {
    return String(name || "?").charAt(0).toUpperCase();
  }

  function avatar(user) {
    var box = el("span", "ac-avatar");
    if (user && user.avatar) {
      var img = el("img");
      img.src = user.avatar;
      img.alt = "";
      img.addEventListener("error", function () {
        img.remove();
        box.textContent = initials(user.username);
      });
      box.appendChild(img);
    } else {
      box.textContent = initials(user && user.username);
    }
    return box;
  }

  function chip(label, tone) {
    return el("span", "ac-chip" + (tone ? " ac-chip-" + tone : ""), label);
  }

  function actionButton(label, cls, onClick) {
    var btn = el("button", "ac-btn" + (cls ? " " + cls : ""), label);
    btn.type = "button";
    btn.addEventListener("click", onClick);
    return btn;
  }

  function scoped(host, id) {
    return host ? host.querySelector("#" + id) : null;
  }

  function mountInto(host, mode) {
    if (!host) return;
    state.mode = mode === "limited" ? "limited" : "full";
    if (host.querySelector(".ac-wrap")) {
      loadLog(host);
      return;
    }
    var limited = state.mode === "limited";
    if (limited) buildModTabs(host);
    var wrap = el("div", "ac-wrap");
    wrap.appendChild(el("h2", "ac-h", "Account moderation"));
    wrap.appendChild(el("p", "ac-lead", limited
      ? "Look up an account and action it. As a mod you can warn, mute up to 24 hours, and ban up to 7 days. Everything is logged and shown to the person."
      : "Look up any account and action it. Owners only — every action is logged and shown to the person."));

    var search = el("form", "ac-search");
    var input = el("input", "ac-input");
    input.type = "text";
    input.placeholder = "username";
    input.autocomplete = "off";
    input.spellcheck = false;
    search.appendChild(input);
    var go = el("button", "ac-btn ac-btn-primary", "Look up");
    go.type = "submit";
    search.appendChild(go);
    search.addEventListener("submit", function (ev) {
      ev.preventDefault();
      var name = String(input.value || "").trim();
      if (!name) return;
      lookup(name, host);
    });
    wrap.appendChild(search);

    var result = el("div", "ac-result");
    result.id = "acResult";
    result.__acHost = host;
    wrap.appendChild(result);

    var logCard = el("section", "ac-card");
    logCard.appendChild(el("h3", "ac-card-h", "Recent actions"));
    var log = el("div", "ac-log");
    log.id = "acLog";
    log.__acHost = host;
    logCard.appendChild(log);
    wrap.appendChild(logCard);

    host.appendChild(wrap);
    var remembered = state.names[state.mode] || "";
    if (remembered) {
      input.value = remembered;
      lookup(remembered, host);
    }
    loadLog(host);
  }

  function buildModTabs(host) {
    if (!host) return;
    host.classList.add("ac-tabbed");
    var nav = host.querySelector(".ac-nav");
    if (!nav) {
      nav = el("div", "ac-nav");
      var inbox = el("button", "ac-nav-btn is-active", "Inbox");
      inbox.type = "button";
      var mods = el("button", "ac-nav-btn", "Moderation");
      mods.type = "button";
      inbox.addEventListener("click", function () { setModTab(host, "inbox"); });
      mods.addEventListener("click", function () { setModTab(host, "mods"); });
      nav.appendChild(inbox);
      nav.appendChild(mods);
      host.insertBefore(nav, host.firstChild);
    }
    setModTab(host, host.classList.contains("mod-tab-mods") ? "mods" : "inbox");
  }

  function setModTab(host, tab) {
    if (!host) return;
    var mods = tab === "mods";
    host.classList.toggle("mod-tab-mods", mods);
    host.classList.toggle("mod-tab-inbox", !mods);
    var nav = host.querySelector(".ac-nav");
    if (!nav) return;
    var buttons = nav.querySelectorAll(".ac-nav-btn");
    for (var i = 0; i < buttons.length; i += 1) {
      var isMods = buttons[i].textContent === "Moderation";
      buttons[i].classList.toggle("is-active", isMods === mods);
    }
    if (mods) loadLog(host);
  }

  function lookup(name, host) {
    var result = scoped(host, "acResult");
    if (!result) return;
    state.names[host && host.id === "modInner" ? "limited" : "full"] = name;
    result.textContent = "Looking up…";
    api("/mod/account?username=" + encodeURIComponent(name)).then(function (data) {
      state.account = data || null;
      paintAccount(result, data || {});
    }).catch(function (err) {
      result.textContent = "";
      var box = el("div", "ac-card ac-miss");
      box.appendChild(el("p", "ac-lead", err.message || "No account with that username."));
      result.appendChild(box);
    });
  }

  function paintAccount(result, data) {
    var user = data.user || {};
    var list = data.penalties || [];
    var host = result.__acHost || null;
    result.textContent = "";

    var card = el("section", "ac-card ac-account");
    var head = el("div", "ac-account-head");
    head.appendChild(avatar(user));
    var meta = el("div", "ac-account-meta");
    var title = el("div", "ac-account-title");
    title.appendChild(el("strong", "ac-account-name", user.username || "unknown"));
    if (user.tag) title.appendChild(el("span", "ac-tag", "#" + user.tag));
    if (user.role) title.appendChild(chip(user.role === "admin" ? "owner" : "mod", user.role === "admin" ? "owner" : "mod"));
    meta.appendChild(title);
    var bits = [];
    if (user.joinedAt) bits.push("joined " + when(user.joinedAt));
    if (user.lastSeenAt) bits.push("seen " + when(user.lastSeenAt));
    meta.appendChild(el("span", "ac-sub", bits.join(" · ") || "no activity recorded"));
    var flags = el("div", "ac-flags");
    if (user.banned) flags.appendChild(chip("banned", "bad"));
    if (user.muted) flags.appendChild(chip("muted " + left(user.muteUntil), "warn"));
    if (list.length) flags.appendChild(chip(list.length + (list.length === 1 ? " action" : " actions"), "muted"));
    if (!flags.children.length) flags.appendChild(chip("in good standing", "good"));
    meta.appendChild(flags);
    head.appendChild(meta);
    card.appendChild(head);

    if (user.role) {
      card.appendChild(el("p", "ac-warn-line", "This account is staff. You cannot action it."));
      result.appendChild(card);
      return;
    }

    var limited = state.mode === "limited";
    var reason = el("textarea", "ac-reason");
    reason.placeholder = "Reason (shown to them on the ban screen and in their penalties list)";
    reason.rows = 2;
    reason.maxLength = 400;
    card.appendChild(reason);

    var grid = el("div", "ac-actions");

    grid.appendChild(actionButton("Warn", "", function () {
      run(host, "/mod/action", { userId: user.id, kind: "warn", reason: reason.value }, "Warning sent");
    }));

    if (!limited) {
      grid.appendChild(actionButton("Clear warnings", "ac-btn-ghost", function () {
        run(host, "/mod/action", { userId: user.id, kind: "clearwarn" }, "Warnings cleared");
      }));
    }

    var muteRow = el("div", "ac-group");
    muteRow.appendChild(el("span", "ac-group-label", "Mute chat"));
    var muteSel = el("select", "ac-select");
    var muteOptions = limited
      ? [["600", "10 min"], ["3600", "1 hour"], ["21600", "6 hours"], ["86400", "24 hours"]]
      : [["600", "10 min"], ["3600", "1 hour"], ["21600", "6 hours"], ["86400", "24 hours"], ["604800", "7 days"]];
    muteOptions.forEach(function (pair) {
      var opt = el("option", "", pair[1]);
      opt.value = pair[0];
      muteSel.appendChild(opt);
    });
    muteRow.appendChild(muteSel);
    muteRow.appendChild(actionButton("Mute", "", function () {
      run(host, "/mod/action", { userId: user.id, kind: "mute", seconds: Number(muteSel.value), reason: reason.value }, "Chat muted");
    }));
    grid.appendChild(muteRow);

    if (user.muted) {
      grid.appendChild(actionButton("Unmute", "ac-btn-ghost", function () {
        run(host, "/mod/action", { userId: user.id, kind: "unmute" }, "Mute lifted");
      }));
    }

    var banRow = el("div", "ac-group");
    banRow.appendChild(el("span", "ac-group-label", "Ban account"));
    var banSel = el("select", "ac-select");
    var banOptions = limited
      ? [["3600", "1 hour"], ["86400", "1 day"], ["604800", "7 days"]]
      : [["3600", "1 hour"], ["86400", "1 day"], ["604800", "7 days"], ["2592000", "30 days"], ["0", "Permanent"]];
    banOptions.forEach(function (pair) {
      var opt = el("option", "", pair[1]);
      opt.value = pair[0];
      banSel.appendChild(opt);
    });
    banRow.appendChild(banSel);
    banRow.appendChild(actionButton("Ban", "ac-btn-danger", function () {
      if (!window.confirm("Ban " + (user.username || "this account") + " for " + banSel.options[banSel.selectedIndex].textContent + "?")) return;
      run(host, "/mod/action", { userId: user.id, kind: "ban", seconds: Number(banSel.value), reason: reason.value }, "Account banned");
    }));
    grid.appendChild(banRow);

    if (user.banned) {
      grid.appendChild(actionButton("Lift ban", "ac-btn-ghost", function () {
        run(host, "/mod/action", { userId: user.id, kind: "unban" }, "Ban lifted");
      }));
    }

    card.appendChild(grid);

    if (limited) {
      card.appendChild(el("p", "ac-lead", "Mods can warn, mute up to 24 hours, and ban up to 7 days. Profile changes and terminations are owner-only."));
      appendHistory(card, list);
      result.appendChild(card);
      return;
    }

    card.appendChild(el("h4", "ac-sub-h", "Profile"));

    var nameRow = el("div", "ac-inline");
    var nameInput = el("input", "ac-input");
    nameInput.type = "text";
    nameInput.maxLength = 16;
    nameInput.placeholder = "new username";
    nameInput.value = "";
    nameRow.appendChild(nameInput);
    nameRow.appendChild(actionButton("Rename", "", function () {
      var name = String(nameInput.value || "").trim();
      if (!name) {
        note("Type a new username first", true);
        return;
      }
      run(host, "/mod/profile", { userId: user.id, action: "rename", value: name }, "Username changed");
    }));
    nameRow.appendChild(actionButton("Reset username", "ac-btn-ghost", function () {
      if (!window.confirm("Reset their username to a random one? Their current name becomes free.")) return;
      run(host, "/mod/profile", { userId: user.id, action: "clear-username" }, "Username reset");
    }));
    card.appendChild(nameRow);

    var profileRow = el("div", "ac-inline");
    profileRow.appendChild(actionButton("Clear photo", "ac-btn-ghost", function () {
      run(host, "/mod/profile", { userId: user.id, action: "clear-avatar" }, "Profile picture cleared");
    }));
    profileRow.appendChild(actionButton("Clear description", "ac-btn-ghost", function () {
      run(host, "/mod/profile", { userId: user.id, action: "clear-bio" }, "Description cleared");
    }));
    profileRow.appendChild(actionButton("Clear status", "ac-btn-ghost", function () {
      run(host, "/mod/profile", { userId: user.id, action: "clear-status" }, "Status cleared");
    }));
    card.appendChild(profileRow);

    if (user.bio) card.appendChild(el("p", "ac-quote", "“" + user.bio + "”"));

    var danger = el("div", "ac-danger");
    danger.appendChild(el("h4", "ac-sub-h", "Danger zone"));
    var confirmRow = el("div", "ac-inline");
    var confirmInput = el("input", "ac-input");
    confirmInput.type = "text";
    confirmInput.placeholder = "type " + (user.username || "username") + " to confirm";
    confirmRow.appendChild(confirmInput);
    confirmRow.appendChild(actionButton("Terminate account", "ac-btn-danger", function () {
      var typed = String(confirmInput.value || "").trim().toLowerCase();
      if (typed !== String(user.username || "").toLowerCase()) {
        note("Type the username exactly to confirm", true);
        return;
      }
      if (!window.confirm("Permanently delete " + user.username + "? This cannot be undone.")) return;
      api("/mod/terminate", { userId: user.id, confirm: typed, reason: reason.value }).then(function () {
        note("Account terminated");
        if (result) result.textContent = "";
        loadLog(host);
      }).catch(function (err) {
        note(err.message || "Couldn't terminate that account", true);
      });
    }));
    danger.appendChild(confirmRow);
    card.appendChild(danger);

    if (list.length) {
      card.appendChild(el("h4", "ac-sub-h", "History"));
      var hist = el("div", "ac-log");
      list.forEach(function (item) {
        hist.appendChild(logRow(item));
      });
      card.appendChild(hist);
    }

    result.appendChild(card);
  }

  function appendHistory(card, list) {
    if (!list.length) return;
    card.appendChild(el("h4", "ac-sub-h", "History"));
    var hist = el("div", "ac-log");
    for (var i = 0; i < list.length; i += 1) hist.appendChild(logRow(list[i]));
    card.appendChild(hist);
  }

  function logRow(item) {
    var row = el("div", "ac-log-row" + (item.active ? " is-active" : ""));
    var head = el("div", "ac-log-head");
    head.appendChild(el("span", "ac-log-kind ac-kind-" + (item.kind || "note"), item.kind || "action"));
    head.appendChild(el("span", "ac-log-who", item.username ? "@" + item.username : ""));
    head.appendChild(el("span", "ac-log-date", when(item.created)));
    row.appendChild(head);
    if (item.reason) row.appendChild(el("span", "ac-log-reason", item.reason));
    var tail = [];
    if (item.until) tail.push("until " + when(item.until) + " (" + left(item.until) + ")");
    if (item.byName) tail.push("by @" + item.byName);
    if (item.active) tail.push("active");
    if (tail.length) row.appendChild(el("span", "ac-log-meta", tail.join(" · ")));
    return row;
  }

  function run(host, path, body, okText) {
    note("Working…");
    api(path, body).then(function (data) {
      note(okText);
      if (data && data.user) {
        state.account = { user: data.user, penalties: (state.account && state.account.penalties) || [] };
        lookup(data.user.username, host);
      } else if (data && data.ok && !data.user) {
        var name = state.account && state.account.user ? state.account.user.username : "";
        if (name) lookup(name, host);
      }
      loadLog(host);
    }).catch(function (err) {
      note(err.message || "That failed", true);
    });
  }

  function loadLog(host) {
    var box = scoped(host, "acLog");
    if (!box || !host) return;
    api("/mod/log").then(function (data) {
      box.textContent = "";
      var list = (data && data.log) || [];
      if (!list.length) {
        box.appendChild(el("p", "ac-lead", "Nothing yet."));
        return;
      }
      list.forEach(function (item) {
        box.appendChild(logRow(item));
      });
    }).catch(function () {
      box.textContent = "";
      box.appendChild(el("p", "ac-lead", "Could not load the log."));
    });
  }

  function wrapRender() {
    var staff = window.hubStaff;
    if (!staff || typeof staff.render !== "function") return false;
    if (staff.__acWrapped) return true;
    staff.__acWrapped = true;
    var original = staff.render;
    staff.render = function (kind) {
      var out = original.apply(this, arguments);
      if (kind === "admin") {
        var host = document.getElementById("adminInner");
        if (host) setTimeout(function () { mountInto(host, "full"); }, 30);
      }
      if (kind === "mod") {
        var modHost = document.getElementById("modInner");
        if (modHost) setTimeout(function () { mountInto(modHost, "limited"); }, 30);
      }
      return out;
    };
    return true;
  }

  var BAN_STYLE = "position:fixed;inset:0;z-index:120;display:flex;align-items:center;justify-content:center;padding:22px;background:#0a0a0c;";

  function banScreen(info) {
    if (document.getElementById("acBanned")) return;
    var wrap = el("div", "ac-banned");
    wrap.id = "acBanned";
    wrap.setAttribute("style", BAN_STYLE);

    var card = el("div", "ac-banned-card");
    var badge = el("span", "ac-banned-badge", info.permanent ? "Account suspended" : "Account suspended");
    card.appendChild(badge);
    card.appendChild(el("h1", "ac-banned-title", info.permanent ? "This account is permanently suspended" : "This account is suspended"));
    card.appendChild(el("p", "ac-banned-msg", info.message || "Your account has been suspended."));
    if (info.reason) {
      var why = el("div", "ac-banned-reason");
      why.appendChild(el("span", "ac-banned-reason-label", "Reason"));
      why.appendChild(el("p", "ac-banned-reason-text", info.reason));
      card.appendChild(why);
    }
    var facts = [];
    if (info.by) facts.push("Actioned by @" + info.by);
    facts.push("Your account ID stays on record. Contact noahhubofficial@gmail.com to appeal.");
    var list = el("ul", "ac-banned-facts");
    facts.forEach(function (fact) {
      list.appendChild(el("li", "", fact));
    });
    card.appendChild(list);

    var row = el("div", "ac-banned-actions");
    var out = el("button", "ac-btn", "Sign out");
    out.type = "button";
    out.addEventListener("click", function () {
      try {
        localStorage.removeItem("hub_token");
        localStorage.removeItem("hub_user");
      } catch (e) {}
      location.reload();
    });
    row.appendChild(out);
    var mail = el("a", "ac-btn ac-btn-primary", "Contact support");
    mail.href = "mailto:noahhubofficial@gmail.com";
    row.appendChild(mail);
    card.appendChild(row);

    wrap.appendChild(card);
    document.body.appendChild(wrap);
    document.body.style.overflow = "hidden";
  }

  function hookFetch() {
    if (window.__acFetch) return;
    window.__acFetch = true;
    var original = window.fetch;
    window.fetch = function () {
      return original.apply(this, arguments).then(function (res) {
        try {
          if (res && res.status === 403 && res.headers) {
            var type = res.headers.get("content-type") || "";
            if (type.indexOf("application/json") >= 0) {
              res.clone().json().then(function (data) {
                if (data && data.code === "ACCOUNT_BANNED") {
                  banScreen({
                    message: data.message,
                    reason: data.reason,
                    until: data.until,
                    by: data.by,
                    permanent: !data.until
                  });
                }
              }).catch(function () {});
            }
          }
        } catch (e) {}
        return res;
      });
    };
  }

  function standing() {
    if (!token()) return;
    api("/mod/penalties").then(function (data) {
      if (!data) return;
      if (data.banned) {
        banScreen({ message: "Your account is suspended.", permanent: true });
        return;
      }
      var list = data.penalties || [];
      state.standing = { list: list, data: data };
      paintBubble(list);
      if (data.muted) muteBanner(data.muteUntil, list);
      decorateAccountView();
    }).catch(function () {});
  }

  function seenStamp() {
    try {
      return localStorage.getItem("hub_mod_seen") || "";
    } catch (e) {
      return "";
    }
  }

  function unseenCount(list) {
    var seen = seenStamp();
    var seenAt = seen ? Date.parse(seen) : 0;
    if (!Number.isFinite(seenAt)) seenAt = 0;
    var count = 0;
    for (var i = 0; i < (list || []).length; i += 1) {
      var at = Date.parse(String(list[i].created || "").replace(" ", "T"));
      if (!Number.isFinite(at)) continue;
      if (!seenAt || at > seenAt) count += 1;
    }
    return count;
  }

  function markSeen(list) {
    var newest = "";
    for (var i = 0; i < (list || []).length; i += 1) {
      var raw = String(list[i].created || "");
      if (raw > newest) newest = raw;
    }
    try {
      localStorage.setItem("hub_mod_seen", newest || new Date().toISOString());
    } catch (e) {}
    paintBubble(list);
  }

  function paintBubble(list) {
    var btn = document.getElementById("railAccount");
    if (!btn) return;
    var dot = document.getElementById("acRailDot");
    if (!dot) {
      dot = el("span", "rail-dot");
      dot.id = "acRailDot";
      dot.setAttribute("aria-hidden", "true");
      btn.appendChild(dot);
    }
    var n = unseenCount(list || []);
    dot.textContent = n > 9 ? "9+" : String(n);
    dot.hidden = !n;
    btn.classList.toggle("has-penalties", Boolean(n));
  }

  function decorateAccountView() {
    var view = document.getElementById("accountView");
    if (!view || view.hasAttribute("hidden")) return;
    if (!view.__stWatch) {
      view.__stWatch = true;
      new MutationObserver(function () { decorateAccountView(); })
        .observe(view, { childList: true, subtree: true });
    }
    var tabs = view.querySelector(".acct-pop-tabs");
    var body = view.querySelector(".acct-pop-body");
    if (!tabs || !body) return;
    var bar = view.querySelector(".ac-modal-link");
    if (bar) bar.remove();
    if (tabs.querySelector(".acct-pop-tab.is-standing")) return;
    var tab = el("button", "acct-pop-tab is-standing", "Standing");
    tab.type = "button";
    tab.addEventListener("click", function () { showStandingTab(tab, body); });
    tabs.appendChild(tab);
    var all = tabs.querySelectorAll(".acct-pop-tab");
    for (var i = 0; i < all.length; i += 1) {
      if (all[i] === tab || all[i].__stClear) continue;
      all[i].__stClear = true;
      all[i].addEventListener("click", function () {
        tab.classList.remove("is-active");
        var dot = tab.querySelector(".st-tab-dot");
        if (dot) dot.remove();
      });
    }
    var unseen = unseenCount(state.standing ? state.standing.list : []);
    if (unseen && !tab.querySelector(".st-tab-dot")) {
      tab.appendChild(el("span", "st-tab-dot"));
    }
  }

  function showStandingTab(tab, body) {
    var tabs = tab.parentNode.querySelectorAll(".acct-pop-tab");
    for (var i = 0; i < tabs.length; i += 1) tabs[i].classList.remove("is-active");
    tab.classList.add("is-active");
    var dot = tab.querySelector(".st-tab-dot");
    if (dot) dot.remove();
    body.textContent = "";
    body.appendChild(el("p", "settings-hint", "Loading…"));
    api("/mod/penalties").then(function (data) {
      var list = (data && data.penalties) || [];
      state.standing = { list: list, data: data || {} };
      markSeen(list);
      renderStanding(body, data || {});
    }).catch(function (err) {
      body.textContent = "";
      body.appendChild(el("p", "settings-hint", (err && err.message) || "Could not load your standing."));
    });
  }

  function renderStanding(host, data) {
    var list = data.penalties || [];
    host.textContent = "";
    var wrap = el("div", "st-wrap");
    wrap.appendChild(el("h2", "acct-page-title", "Standing"));
    wrap.appendChild(el("p", "settings-hint", "Warnings, mutes and bans on your account. Only you and the owners can see this."));

    var counts = { warn: 0, mute: 0, ban: 0 };
    for (var i = 0; i < list.length; i += 1) {
      if (!list[i].active) continue;
      if (counts[list[i].kind] !== undefined) counts[list[i].kind] += 1;
    }
    var stats = el("div", "st-stats");
    stats.appendChild(statCard("Warning", "Warnings", counts.warn, "warn"));
    stats.appendChild(statCard("Mute", "Mutes", counts.mute, "warn"));
    stats.appendChild(statCard("Ban", "Bans", counts.ban, "bad"));
    wrap.appendChild(stats);

    if (data.muted) {
      wrap.appendChild(el("p", "st-notice", "You are muted in chat until " + when(data.muteUntil) + " (" + left(data.muteUntil) + "). You can read, but not send."));
    }

    if (!list.length) {
      wrap.appendChild(el("div", "st-empty", "Nothing on your record. You're all good."));
    } else {
      var rows = el("div", "st-list");
      for (var j = 0; j < list.length; j += 1) rows.appendChild(standingRow(list[j]));
      wrap.appendChild(rows);
    }
    host.appendChild(wrap);
  }

  function statCard(singular, plural, value, tone) {
    var card = el("div", "st-stat" + (value && tone ? " is-" + tone : ""));
    card.appendChild(el("span", "st-stat-num", String(value)));
    card.appendChild(el("span", "st-stat-label", value === 1 ? singular : plural));
    return card;
  }

  function standingRow(item) {
    var row = el("div", "st-item is-" + (item.kind || "note"));
    var head = el("div", "st-item-head");
    head.appendChild(el("span", "st-kind", item.kind || "action"));
    head.appendChild(el("span", "st-date", when(item.created)));
    row.appendChild(head);
    if (item.reason) row.appendChild(el("p", "st-reason", item.reason));
    var meta = [];
    if (item.until) meta.push("ends " + when(item.until) + " (" + left(item.until) + ")");
    if (item.byName) meta.push("by @" + item.byName);
    meta.push(item.active ? "active" : "expired");
    row.appendChild(el("span", "st-meta", meta.join(" · ")));
    return row;
  }

  function watchAccountView() {
    if (watchAccountView.done) return;
    watchAccountView.done = true;
    var rail = document.getElementById("railAccount");
    if (rail) {
      rail.addEventListener("click", function () {
        setTimeout(decorateAccountView, 250);
        setTimeout(decorateAccountView, 900);
      });
    }

    decorateAccountView();
  }

  function muteBanner(until, list) {
    if (document.getElementById("acMuteBanner")) return;
    var host = document.getElementById("chatShell") || document.getElementById("chatApp");
    if (!host) return;
    var reason = "";
    for (var i = 0; i < (list || []).length; i += 1) {
      if (list[i].kind === "mute" && list[i].active) {
        reason = list[i].reason || "";
        break;
      }
    }
    var bar = el("div", "ac-mute-banner");
    bar.id = "acMuteBanner";
    bar.appendChild(el("span", "ac-mute-dot"));
    bar.appendChild(el("span", "ac-mute-text", "You're muted in chat until " + when(until) + (reason ? " — " + reason : "")));
    host.appendChild(bar);
  }

  function boot() {
    hookFetch();
    wrapRender();
    setTimeout(wrapRender, 1500);
    setTimeout(wrapRender, 5000);
    setTimeout(standing, 2500);
    setTimeout(standing, 9000);
    setInterval(function () {
      watchAccountView();
    }, 5000);
    document.addEventListener("click", function (ev) {
      var t = ev.target;
      if (!t || !t.closest) return;
      if (t.closest("#navAdmin")) {
        var host = document.getElementById("adminInner");
        if (host) setTimeout(function () { mountInto(host, "full"); }, 40);
        setTimeout(function () { mountInto(document.getElementById("adminInner"), "full"); }, 400);
      }
      if (t.closest("#navMod")) {
        var modHost = document.getElementById("modInner");
        if (modHost) setTimeout(function () { mountInto(modHost, "limited"); }, 40);
        setTimeout(function () { mountInto(document.getElementById("modInner"), "limited"); }, 400);
      }
      if (t.closest("#railAccount")) setTimeout(decorateAccountView, 300);
    }, true);
    watchAccountView();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
