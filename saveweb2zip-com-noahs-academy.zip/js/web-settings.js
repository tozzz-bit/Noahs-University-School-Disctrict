(function () {
  "use strict";

  var ENGINE_KEY = "hub_web_engine";
  var HOME_KEY = "hub_web_home";
  var KEYS_KEY = "hub_web_keys";

  var ENGINES = [
    { id: "bing", name: "Bing (strict)", url: "https://www.bing.com/search?adlt=strict&q=" },
    { id: "ddg", name: "DuckDuckGo", url: "https://duckduckgo.com/?kp=1&q=" },
    { id: "brave", name: "Brave (strict)", url: "https://search.brave.com/search?safesearch=strict&q=" },
    { id: "google", name: "Google (safe)", url: "https://www.google.com/search?safe=active&q=" },
    { id: "startpage", name: "Startpage", url: "https://www.startpage.com/sp/search?query=" }
  ];

  function read(key, fallback) {
    try {
      var value = localStorage.getItem(key);
      return value == null ? fallback : value;
    } catch (e) {
      return fallback;
    }
  }

  function write(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch (e) {}
  }

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = text;
    return node;
  }

  function engine() {
    var id = read(ENGINE_KEY, "bing");
    for (var i = 0; i < ENGINES.length; i += 1) {
      if (ENGINES[i].id === id) return ENGINES[i];
    }
    return ENGINES[0];
  }

  function searchUrl(term) {
    return engine().url + encodeURIComponent(String(term || ""));
  }

  function homeUrl() {
    var value = String(read(HOME_KEY, "")).trim();
    if (!value) return "";
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(value)) value = "https://" + value;
    return value;
  }

  function keysOn() {
    return read(KEYS_KEY, "on") !== "off";
  }

  function row(label, hint, control) {
    var wrap = el("div", "wset-row");
    var text = el("div", "wset-copy");
    text.appendChild(el("span", "wset-label", label));
    if (hint) text.appendChild(el("span", "wset-hint", hint));
    wrap.appendChild(text);
    var box = el("div", "wset-control");
    box.appendChild(control);
    wrap.appendChild(box);
    return wrap;
  }

  function section(title, note) {
    var card = el("section", "wset-card");
    var head = el("div", "wset-card-head");
    head.appendChild(el("h2", "wset-card-title", title));
    if (note) head.appendChild(el("p", "wset-card-note", note));
    card.appendChild(head);
    return card;
  }

  function button(label, cls, handler) {
    var btn = el("button", "wset-btn" + (cls ? " " + cls : ""), label);
    btn.type = "button";
    btn.addEventListener("click", handler);
    return btn;
  }

  function saveBar(host) {
    var note = host.querySelector(".wset-saved");
    if (!note) return;
    note.classList.add("is-on");
    clearTimeout(note.__t);
    note.__t = setTimeout(function () {
      note.classList.remove("is-on");
    }, 1600);
  }

  function render(host) {
    if (!host) return;
    while (host.firstChild) host.removeChild(host.firstChild);

    var wrap = el("div", "wset");
    var top = el("header", "wset-top");
    top.appendChild(el("h1", "wset-title", "Settings"));
    top.appendChild(el("p", "wset-sub", "Everything here is saved on this device and applies to the built-in browser."));
    wrap.appendChild(top);

    var saved = el("span", "wset-saved", "Saved");
    top.appendChild(saved);

    var search = section("Search", "Used when what you type in the address bar is not a web address. Safe search stays on.");
    var select = el("select", "wset-select");
    for (var i = 0; i < ENGINES.length; i += 1) {
      var option = el("option", "", ENGINES[i].name);
      option.value = ENGINES[i].id;
      if (ENGINES[i].id === engine().id) option.selected = true;
      select.appendChild(option);
    }
    select.addEventListener("change", function () {
      write(ENGINE_KEY, select.value);
      saveBar(host);
    });
    search.appendChild(row("Search engine", "Applies to the next search you run.", select));
    wrap.appendChild(search);

    var start = section("Start page", "Where the home button takes you. Leave empty to open a blank tab with your bookmarks.");
    var input = el("input", "wset-input");
    input.type = "text";
    input.placeholder = "https://example.com";
    input.value = read(HOME_KEY, "");
    input.spellcheck = false;
    input.addEventListener("change", function () {
      write(HOME_KEY, input.value.trim());
      saveBar(host);
    });
    start.appendChild(row("Home address", "Type a site address, or clear it for the new tab page.", input));
    var preset = el("div", "wset-chips");
    [["New tab", ""], ["Google", "google.com"], ["YouTube", "youtube.com"], ["Wikipedia", "wikipedia.org"]].forEach(function (pair) {
      var chip = el("button", "wset-chip", pair[0]);
      chip.type = "button";
      chip.addEventListener("click", function () {
        input.value = pair[1];
        write(HOME_KEY, pair[1]);
        saveBar(host);
      });
      preset.appendChild(chip);
    });
    start.appendChild(preset);
    wrap.appendChild(start);

    var keys = section("Keyboard", "Shortcuts only run while the browser is open.");
    var toggle = el("button", "wset-toggle" + (keysOn() ? " is-on" : ""));
    toggle.type = "button";
    toggle.setAttribute("aria-pressed", keysOn() ? "true" : "false");
    toggle.appendChild(el("span", "wset-toggle-dot"));
    toggle.appendChild(el("span", "wset-toggle-label", keysOn() ? "On" : "Off"));
    toggle.addEventListener("click", function () {
      var next = !keysOn();
      write(KEYS_KEY, next ? "on" : "off");
      toggle.classList.toggle("is-on", next);
      toggle.setAttribute("aria-pressed", next ? "true" : "false");
      toggle.querySelector(".wset-toggle-label").textContent = next ? "On" : "Off";
      saveBar(host);
    });
    keys.appendChild(row("Shortcuts", "Ctrl+L address bar · Ctrl+T new tab · Ctrl+W close tab · Ctrl+R reload", toggle));
    wrap.appendChild(keys);

    var privacy = section("Storage", "Clears cached site files and tabs. Your chat sign-in is never touched.");
    var actions = el("div", "wset-actions");
    var wiped = el("span", "wset-hint");
    actions.appendChild(button("Clear cache", "wset-btn-ghost", function () {
      var jobs = [];
      try {
        if (window.caches) {
          jobs.push(caches.keys().then(function (names) {
            return Promise.all(names.map(function (name) { return caches.delete(name); }));
          }));
        }
      } catch (e) {}
      try {
        sessionStorage.clear();
      } catch (e) {}
      Promise.all(jobs).then(function () {
        wiped.textContent = "Cache cleared";
        setTimeout(function () { wiped.textContent = ""; }, 2000);
      });
    }));
    actions.appendChild(button("Reset preferences", "wset-btn-ghost", function () {
      try {
        localStorage.removeItem(ENGINE_KEY);
        localStorage.removeItem(HOME_KEY);
        localStorage.removeItem(KEYS_KEY);
      } catch (e) {}
      render(host);
    }));
    actions.appendChild(wiped);
    privacy.appendChild(actions);
    wrap.appendChild(privacy);

    var about = section("Connection");
    var info = el("div", "wset-facts");
    var ready = false;
    try {
      ready = Boolean(window.hubProxy && window.hubProxy.isReady && window.hubProxy.isReady());
    } catch (e) {
      ready = false;
    }
    [["Status", ready ? "Connected" : "Not connected"], ["Engine", "Scramjet"], ["Transport", "Hub relay (Wisp)"]].forEach(function (pair) {
      var fact = el("div", "wset-fact");
      fact.appendChild(el("span", "wset-fact-label", pair[0]));
      fact.appendChild(el("span", "wset-fact-value", pair[1]));
      info.appendChild(fact);
    });
    about.appendChild(info);
    var conn = el("div", "wset-actions");
    conn.appendChild(button("Reconnect", "", function () {
      try {
        if (window.hubProxy && window.hubProxy.start) window.hubProxy.start();
      } catch (e) {}
    }));
    about.appendChild(conn);
    wrap.appendChild(about);

    host.appendChild(wrap);
  }

  function shortcut(ev) {
    if (!keysOn()) return;
    if (!ev.ctrlKey && !ev.metaKey) return;
    if (ev.altKey) return;
    var view = document.getElementById("webView");
    if (!view || view.hasAttribute("hidden")) return;
    var key = String(ev.key || "").toLowerCase();
    var target = null;
    if (key === "l") {
      target = document.getElementById("webOmni");
      if (target) {
        ev.preventDefault();
        target.focus();
        target.select();
      }
      return;
    }
    if (key === "t") target = document.getElementById("webNewTab");
    else if (key === "r") target = document.getElementById("webReload");
    else if (key === "w") {
      var close = document.querySelector(".web-tab.is-active .web-tab-close");
      if (close) {
        ev.preventDefault();
        close.click();
      }
      return;
    }
    if (target) {
      ev.preventDefault();
      target.click();
    }
  }

  document.addEventListener("keydown", shortcut, true);

  window.hubWebSettings = {
    render: render,
    searchUrl: searchUrl,
    homeUrl: homeUrl,
    engine: engine
  };
})();
