(function () {
  "use strict";

  var SEEN_KEY = "hub_web_settings_seen";

  function userId() {
    try {
      var token = localStorage.getItem("hub_token") || "";
      var part = token.split(".")[1];
      if (!part) return "";
      var json = JSON.parse(atob(part.replace(/-/g, "+").replace(/_/g, "/")));
      return String(json.id || json.sub || "");
    } catch (e) {
      return "";
    }
  }

  function seen(uid) {
    try {
      return Boolean(uid) && localStorage.getItem(SEEN_KEY) === uid;
    } catch (e) {
      return false;
    }
  }

  function markSeen(uid) {
    try {
      localStorage.setItem(SEEN_KEY, uid);
    } catch (e) {}
  }

  function clearBadge(button) {
    if (button) button.classList.remove("has-dot");
  }

  function mount() {
    var button = document.getElementById("webSettings");
    var uid = userId();
    if (!button || !uid) return;

    if (!seen(uid)) button.classList.add("has-dot");

    button.addEventListener("click", function () {
      markSeen(uid);
      clearBadge(button);
    });

    var internal = document.getElementById("webInternal");
    if (internal && !internal.__settingsWatch) {
      internal.__settingsWatch = true;
      new MutationObserver(function () {
        if (internal.querySelector(".wset")) {
          markSeen(uid);
          clearBadge(button);
        }
      }).observe(internal, { childList: true });
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mount);
  } else {
    mount();
  }

  window.hubWebSettingsBadge = { mount: mount };
})();
